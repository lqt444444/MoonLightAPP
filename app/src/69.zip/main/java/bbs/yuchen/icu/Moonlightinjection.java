package bbs.yuchen.icu;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.text.InputType;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.PathInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Moonlightinjection {

    // SharedPreferences keys for caching settings
    private static final String _PREF_A_ = "Key1";
    // 缓存配置内容
    private static final String _PREF_B_ = "Key2";
    // 配置版本
    private static final String _PREF_E_ = "Key5";
    // 强制更新链接
    private static final String _PREF_F_ = "Key6";
    // 强制更新是否需要
    private static final String _PREF_G_ = "Key7";
    // 签名SHA1列表
    private static final String _PREF_H_ = "Key8";
    // 启用签名验证
    private static final String _PREF_I_ = "Key9";
    // 启用夜间模式
    private static final String _PREF_J_ = "Key10";
    // 启用Monet动态取色
    private static final String _PREF_K_ = "Key11";
    // 启用内置Monet
    private static final String _PREF_L_ = "Key12";
    // Monet主题色
    private static final String _PREF_M_ = "Key13";
    // 是否大屏幕
    private static final String _PREF_N_ = "Key14";
    // DPI适配是否已检查
    private static final String _PREF_O_ = "Key15";
    // 启用DPI适配
    private static final String _PREF_P_ = "Key16";
    // 弹窗显示控制 (Package-specific main dialog visibility) - NEW
    private static final String _PREF_Q_ = "Key17";
    // 包名版本配置
    private static final String _PREF_R_ = "Key18";
    // 启用远程通知
    private static final String _PREF_S_ = "Key19";
    // 通知内容
    private static final String _PREF_T_ = "Key20";
    // 通知渠道ID
    private static final String _PREF_U_ = "Key21";
    // 通知渠道名称
    private static final String _PREF_V_ = "Key22";
    // 包名内容映射
    private static final String _PREF_W_ = "Key23";
    // 设备卡密映射
    private static final String _PREF_X_ = "Key24_";
    // 设备卡密绑定验证状态
    private static final String _PREF_Y_ = "Key25";
    // 启用设备ID检查
    private static final String _PREF_Z_ = "Key26";
    // 允许的设备ID列表
    private static final String _PREF_AA_ = "Key27";
    // 设备ID卡密链接

    // Keys for switch type config items
    private static final String _PREF_BB_ = "Key28";
    // 开关配置字符串
    private static final String _PREF_CC_ = "Key29";
    // 文本配置字符串

    // New SharedPreferences keys for additional configurations
    private static final String _PREF_DD_ = "Key30";
    // 显示Moonlight图标
    private static final String _PREF_EE_ = "Key31";
    // 启用设备卡密检查
    private static final String _PREF_FF_ = "Key32";
    // 启用不再提示倒计时
    private static final String _PREF_GG_ = "Key33";
    // 包名锁定映射
    private static final String _PREF_HH_ = "Key34";
    // 包名锁定内容
    private static final String _PREF_II_ = "Key35";
    // 包名锁定链接
    private static final String _PREF_JJ_ = "Key36";
    // 强制更新弹窗显示关闭按钮
    private static final String _PREF_KK_ = "Key37";
    // 包名锁定弹窗显示关闭按钮
    private static final String _PREF_LL_ = "Key38";
    // 强制使用国内URL
    private static final String _PREF_MM_ = "Key39";
    // 强制使用国际URL
    private static final String _PREF_NN_ = "Key40";
    // 启用用户自定义URL
    private static final String _PREF_OO_ = "Key41";
    // 用户自定义URL列表
    private static final String _PREF_PP_ = "Key42";
    // 弹窗版本
    private static final String _PREF_QQ_ = "Key43";
    // 配置加载超时时间
    private static final String _PREF_RR_ = "Key44";
    // 启用配置文件语法检查
    private static final String _PREF_SS_ = "Key45";
    // 启用更丰富的设备信息收集

    private static final String _PREF_NEW_DYNAMIC_TEXT_COLORS_ = "Key46";
    // 启用弹窗背景改变文字颜色按钮颜色
    private static final String _PREF_NEUTRAL_BTN_SWITCH_ = "Key47";
    // 中立按钮是否显示 - NEW
    private static final String _PREF_NEUTRAL_BTN_CONTENT_ = "Key48";
    // 中立按钮内容/动作 - NEW
    private static final String _PREF_NEW_NORMAL_POPUP_CONTROL_ = "Key49";
    // 普通弹窗显示控制 (Package-specific normal popup visibility) - NEW

    // Cloud Inject SharedPreferences keys
    public static final String CI_PREF_NAME = "cloudinject_config";
    public static final String CI_KEY_SECRET = "saved_secret";
    public static final String CI_KEY_LAST_NOTICE_HASH = "last_notice_hash";
    public static final String CI_KEY_CONFIG_CACHE = "config_cache";
    private static final String CI_TAG = "CloudInject";

    private static final int _DONT_SHOW_AGAIN_CD_ = 7000;
    // 不再提示倒计时时间 (7秒)
    private static final int _CARD_KEY_CD_ = 15000;
    // 卡密倒计时时间 (15秒)
    private static final int _DEV_ID_CRASH_CD_ = 15;
    // 设备ID限制对话框崩溃倒计时 (15秒)
    private static final int _DEF_CONFIG_LOAD_TIMEOUT_ = 8000;
    // 默认配置加载超时时间 (8秒)
    private static final float _MAX_LANDSCAPE_DIALOG_HEIGHT_PERCENT_ = 0.8f;
    // 横屏模式下对话框的最大高度百分比

    private static final List<String> _DEF_SIG_LIST_ = Arrays.asList( // 默认签名SHA1列表
            "12:34:56:78:90:AB:CD:EF:12:34:56:78:90:AB:CD:EF:12:34:56:78"
    );
    // Configurable Fields
    private static int _dialog_version_ = 2;
    // 弹窗版本, 1 = Simple Style, 2 = Themed Style
    private static String _dyn_content_ = "Content1";
    // 动态内容
    private static String _eng_content_ = "Content2";
    // 英文内容
    private static String _force_upd_link_ = "";
    // 强制更新链接
    private static String _tg_channel_link_ = "https://t.me/channel";
    // Telegram频道链接
    private static String _qq_group_num_ = "";
    // QQ群号
    private static String _popup_title_ = "Title1";
    // 弹窗标题
    private static String _popup_title_eng_ = "Title2";
    // 弹窗英文标题
    private static String _force_upd_content_ = "UpdateMsg1";
    // 强制更新内容
    private static String _force_upd_content_eng_ = "UpdateMsg2";
    // 强制更新英文内容
    private static String _upd_log_ = "Log1";
    // 更新日志
    private static String _upd_log_eng_ = "Log2";
    private static String _cfg_version_ = "1.0";
    // 配置版本
    private static List<String> _sig_sha1_list_ = new ArrayList<>(_DEF_SIG_LIST_);
    // 签名SHA1列表
    private static Map<String, Integer> _pkg_ver_cfg_ = new HashMap<>();
    // 包名版本配置
    private static Map<String, String> _pkg_content_map_ = new HashMap<>();
    // 包名内容映射
    private static boolean _force_upd_req_ = false;
    // 是否需要强制更新

    // Switch Fields
    private static boolean _net_cfg_enabled_ = true;
    // 网络配置总开关
    private static boolean _show_dyn_content_ = true;
    // 显示动态内容
    private static boolean _show_upd_log_ = true;
    // 显示更新日志
    private static boolean _reset_dont_show_ = false;
    // 重置不再提示
    private static boolean _enable_img_rot_ = true;
    // 启用Moonlight图旋转
    private static boolean _enable_bg_blur_ = true;
    // 启用背景模糊
    private static boolean _enable_norm_popup_ = true;
    // 启用普通弹窗
    private static boolean _show_close_btn_ = true;
    // 显示关闭弹窗按钮
    private static boolean _show_dont_show_btn_ = true;
    // 显示不再提示按钮
    private static boolean _show_qq_btn_ = true;
    // 显示QQ群按钮
    private static boolean _show_tg_btn_ = true;
    // 显示TG频道按钮
    private static boolean _enable_out_click_ = true;
    // 启用外部点击消失
    private static boolean _enable_sig_ver_ = false;
    // 启用签名验证
    private static boolean _enable_dpi_auto_ = true;
    // 启用DPI适配
    private static Map<String, String> _dev_card_keys_ = new HashMap<>();
    // 设备卡密映射
    private static boolean _enable_dev_id_check_ = false;
    // 启用设备ID检查
    private static List<String> _allowed_dev_ids_ = new ArrayList<>();
    // 允许的设备ID列表
    private static String _dev_id_card_link_ = "";
    // 设备ID卡密链接

    // Remote notification switches
    private static boolean _enable_remote_notif_ = false;
    // 启用远程通知
    private static String _remote_notif_content_ = "";
    // 远程通知内容

    // New configurable fields
    private static boolean _show_moonlight_icon_ = true;
    // 显示Moonlight图标 (Default: true)
    private static boolean _enable_dev_card_key_check_ = false;
    // 启用设备卡密检查 (Default: false)
    private static boolean _enable_countdown_dont_show_ = true;
    // 开启不再提示确认倒计时 (Default: true)
    private static Map<String, Boolean> _pkg_lock_map_ = new HashMap<>();
    // 包名锁定映射 (key: package name, value: true if locked)
    private static String _pkg_lock_content_ = "";
    // 包名锁定内容
    private static String _pkg_lock_link_ = "";
    // 包名锁定链接
    private static boolean _show_force_update_close_btn_ = false;
    // 强制更新弹窗显示关闭按钮 (Default: false)
    private static boolean _show_package_lock_close_btn_ = false;
    // 包名锁定弹窗显示关闭按钮 (Default: false)
    private static boolean _force_use_domestic_url_ = false;
    // 强制使用国内URL
    private static boolean _force_use_international_url_ = false;
    // 强制使用国际URL
    private static boolean _enable_user_custom_url_ = false;
    // 启用用户自定义URL
    private static String _user_custom_urls_ = "";
    // 用户自定义URL列表 (逗号分隔)
    private static long _config_load_timeout_ms_ = _DEF_CONFIG_LOAD_TIMEOUT_;
    // 配置加载超时时间
    private static boolean _enable_config_syntax_check_ = false;
    // 启用配置文件语法检查
    private static boolean _enable_rich_device_info_collection_ = false;
    // 启用更丰富的设备信息收集

    // NEW: Enable dynamic text/button color based on background luminosity
    private static boolean _enable_dynamic_text_colors_ = true;
    // Default: true (enabled)
    // NEW: Neutral Button fields
    private static boolean _show_neutral_btn_ = false;
    // 是否显示中立按钮
    private static String _neutral_btn_content_ = "";
    // 中立按钮内容 (e.g., "网站=https://example.com" or "QQ=12345")
    // NEW: Package-specific popup controls
    private static Map<String, Boolean> _pkg_popup_control_ = new HashMap<>();
    // 包名主弹窗显示控制
    private static Map<String, Boolean> _normal_popup_control_ = new HashMap<>();
    // 包名普通弹窗显示控制

    // Cloud Inject Security Flags
    private static boolean _security_enabled_ = true;
    private static boolean _detect_xp_ = false;
    private static boolean _detect_packet_sniffing_ = false;
    private static boolean _detect_gg_ = false;
    private static boolean _cloud_inject_enabled_ = false;

    // Cloud Inject Control Parameters
    public static final String CI_DEFAULT_APP_ID = "131d758d7b7767600000242d50cf1f9f";
    private static final Map<String, String> _ci_package_app_id_map_ = new HashMap<>();
    private static String _ci_global_app_id_ = CI_DEFAULT_APP_ID;
    private static boolean _ci_notice_enabled_ = true;
    
    // Cloud Inject Domain lists
    private static final String[] _CI_DOMESTIC_HOSTS_ = {"360stop.org", "360mixup.com"};
    private static final String[] _CI_INTERNATIONAL_HOSTS_ = {"checksum.cc", "360stat.org"};
    
    // 云注入配置URL
    private static final String CI_CONFIG_PATH = "/feature/config";
    private static final String CI_VERIFY_PATH = "/feature/pack/verify";


    // Color Switch Fields
    private static boolean _enable_night_mode_ = false;
    // 启用夜间模式
    private static boolean _enable_monet_dyn_ = true;
    // 启用Monet动态取色
    private static boolean _enable_builtin_monet_ = true;
    // 启用内置Monet
    private static String _monet_theme_color_ = "Color_Val";
    // Monet主题色

    // Default Day Colors
    private static final int _DIALOG_BG_DAY_ = 0xFFFFFFFF;
    // 对话框背景日间模式
    private static final int _BUTTON_BG_DAY_ = 0xFFE0E0E0;
    // 按钮背景日间模式
    private static final int _TEXT_COLOR_DAY_ = 0xFF000000;
    // 文本颜色日间模式
    private static final int _BUTTON_TEXT_COLOR_DAY_ = 0xFF000000;
    // 按钮文本颜色日间模式
    private static final int _EDITTEXT_TEXT_COLOR_DAY_ = 0xFF000000;
    // EditText文本颜色日间模式
    private static final int _EDITTEXT_HINT_COLOR_DAY_ = 0x80000000;
    // EditText提示颜色日间模式

    // Default Night Colors
    private static final int _DIALOG_BG_NIGHT_ = 0xFF121212;
    // 对话框背景夜间模式
    private static final int _BUTTON_BG_NIGHT_ = 0xFF363636;
    // 按钮背景夜间模式
    private static final int _TEXT_COLOR_NIGHT_ = 0xFFFFFFFF;
    // 文本颜色夜间模式
    private static final int _BUTTON_TEXT_COLOR_NIGHT_ = 0xFFFFFFFF;
    // 按钮文本颜色夜间模式
    private static final int _EDITTEXT_TEXT_COLOR_NIGHT_ = 0xFFFFFFFF;
    // EditText文本颜色夜间模式
    private static final int _EDITTEXT_HINT_COLOR_NIGHT_ = 0x80FFFFFF;
    // EditText提示颜色夜间模式

    // Current resolved colors
    private static int _current_dialog_bg_ = _DIALOG_BG_DAY_;
    // 当前对话框背景色
    private static int _current_button_bg_ = _BUTTON_BG_DAY_;
    // 当前按钮背景色
    private static int _current_text_color_ = _TEXT_COLOR_DAY_;
    // 当前文本颜色
    private static int _current_button_text_ = _BUTTON_TEXT_COLOR_DAY_;
    // 当前按钮文本颜色
    private static int _current_edittext_text_ = _EDITTEXT_TEXT_COLOR_DAY_;
    // 当前EditText文本颜色
    private static int _current_edittext_hint_ = _EDITTEXT_HINT_COLOR_DAY_;
    // 当前EditText提示颜色
    private static int _current_edittext_stroke_ = 0xFFCCCCCC;
    // 当前EditText描边颜色


    // Internal State
    private static WeakReference<Activity> _s_activity_ref_ = null;
    // 正在显示的Activity弱引用
    private static AlertDialog _s_main_dialog_ = null;
    // 主对话框实例
    private static boolean _is_blur_applied_ = false;
    // 是否已应用背景模糊
    private static String _cfg_dom_url_ = "";
    // 国内配置URL
    private static String _cfg_intl_url_ = "";
    // 国际配置URL
    private static boolean _is_large_screen_ = false;
    // 是否为大屏幕设备
    private static CountDownTimer _card_key_timer_ = null;
    // 卡密倒计时器
    private static CountDownTimer _dev_id_timer_ = null;
    // 设备ID倒计时器
    private static TextView _dev_id_timer_text_ = null;
    // 设备ID倒计时文本视图
    private static String _full_config_string_ = "";
    // 完整的配置字符串，用于自定义解析
    private static String _ci_last_notice_hash_ = "";

    // Animation Interpolators
    private static final Interpolator _STD_DECEL_ = new DecelerateInterpolator();
    // 标准减速插值器
    private static final Interpolator _EMPH_INTERP_ = Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ?
            new PathInterpolator(0.2f, 0f, 0f, 1f) : new AccelerateDecelerateInterpolator();
    // 强调插值器
    // Built-in Monet Colors
    private static final Map<String, Integer> _MONET_COLORS_ = new HashMap<String, Integer>() {{ // Monet颜色映射
        put("Red", Color.parseColor("#F44336"));
        put("Pink", Color.parseColor("#E91E63"));
        put("Purple", Color.parseColor("#9C27B0"));
        put("DeepPurple", Color.parseColor("#673AB7"));
        put("Indigo", Color.parseColor("#3F51B5"));
        put("Blue", Color.parseColor("#2196F3"));
        put("LightBlue", Color.parseColor("#03A9F4"));
        put("Cyan", Color.parseColor("#00BCD4"));
        put("Teal", Color.parseColor("#009688"));
        put("Green", Color.parseColor("#4CAF50"));
        put("LightGreen", Color.parseColor("#8BC34A"));
        put("Lime", Color.parseColor("#CDDC39"));
        put("Yellow", Color.parseColor("#FFEB3B"));
        put("Amber", Color.parseColor("#FFC107"));
        put("Orange", Color.parseColor("#FF9800"));
        put("DeepOrange", Color.parseColor("#FF5722"));
        put("Brown", Color.parseColor("#795548"));
        put("Grey", Color.parseColor("#9E9E9E"));
        put("BlueGrey", Color.parseColor("#607D8B"));
        put("PastelBlue", Color.parseColor("#A7C7E7"));
        put("PastelGreen", Color.parseColor("#C1E1C1"));
        put("PastelPink", Color.parseColor("#FFD1DC"));
        put("PastelPurple", Color.parseColor("#C8A2C8"));
        put("PastelYellow", Color.parseColor("#FFFD96"));
        put("PastelOrange", Color.parseColor("#FFD8A9"));
        put("PastelRed", Color.parseColor("#FFB6B9"));
        put("PastelTeal", Color.parseColor("#99D5C9"));
        put("SkyBlue", Color.parseColor("#87CEEB"));
        put("OceanBlue", Color.parseColor("#4F97A3"));
        put("ForestGreen", Color.parseColor("#228B22"));
        put("MossGreen", Color.parseColor("#8A9A5B"));
        put("SunsetOrange", Color.parseColor("#FF6B35"));
        put("SunflowerYellow", Color.parseColor("#FFDA03"));
        put("Lavender", Color.parseColor("#E6E6FA"));
        put("WarmGrey", Color.parseColor("#A9A9A9"));
        put("Sakura", Color.parseColor("#FF9CA8"));
        put("Matcha", Color.parseColor("#A5D6A7"));
        put("MidnightBlue", Color.parseColor("#2C3E50"));
        put("Coral", Color.parseColor("#FF7F50"));
        put("Turquoise", Color.parseColor("#40E0D0"));
        put("Lilac", Color.parseColor("#C8A2C8"));
        put("Gold", Color.parseColor("#FFD700"));
        put("Silver", Color.parseColor("#C0C0C0"));
        put("DarkSlate", Color.parseColor("#2F4F4F"));
        put("Navy", Color.parseColor("#001F3F"));
        put("Burgundy", Color.parseColor("#800020"));
        put("DarkTeal", Color.parseColor("#006D5B"));
        put("DeepPlum", Color.parseColor("#673147"));
        put("Charcoal", Color.parseColor("#36454F"));
    }};
    // Obfuscation key
    private static final String _OBF_KEY_ = "MoonlightSecureKey123!";
    // 混淆密钥

    private static Handler _main_handler_; // 主线程Handler

    // Obfuscation method
    private static String obfuscate(String input) {
        if (input == null) return null;
        try {
            byte[] inputBytes = input.getBytes(StandardCharsets.UTF_8);
            byte[] keyBytes = _OBF_KEY_.getBytes(StandardCharsets.UTF_8);
            byte[] outputBytes = new byte[inputBytes.length];
            for (int i = 0; i < inputBytes.length; i++) {
                outputBytes[i] = (byte) (inputBytes[i] ^ keyBytes[i % keyBytes.length]);
            }
            return Base64.encodeToString(outputBytes, Base64.NO_WRAP);
        } catch (Exception e) {
            return input;
        }
    }

    // Deobfuscation method
    private static String deobfuscate(String input) {
        if (input == null) return null;
        try {
            byte[] inputBytes = Base64.decode(input, Base64.DEFAULT);
            byte[] keyBytes = _OBF_KEY_.getBytes(StandardCharsets.UTF_8);
            byte[] outputBytes = new byte[inputBytes.length];
            for (int i = 0; i < inputBytes.length; i++) {
                outputBytes[i] = (byte) (inputBytes[i] ^ keyBytes[i % keyBytes.length]);
            }
            return new String(outputBytes, StandardCharsets.UTF_8);
        } catch (Exception e) {
            return input;
        }
    }

    public static void init(Activity activity, String domesticUrl, String internationalUrl) {
        if (_main_handler_ == null) {
            _main_handler_ = new Handler(Looper.getMainLooper());
        }

        if (activity == null || (domesticUrl == null || domesticUrl.trim().isEmpty()) && (internationalUrl == null || internationalUrl.trim().isEmpty())) {
            return;
        }

        // Clean up invalid dialog references
        if (_s_main_dialog_ != null && _s_main_dialog_.isShowing()) {
            Activity dialogActivity = _s_activity_ref_ != null ?
                    _s_activity_ref_.get() : null;
            if (dialogActivity == null || dialogActivity.isFinishing()) {
                _s_main_dialog_.dismiss();
                _s_main_dialog_ = null;
                _s_activity_ref_ = null;
            }
        }

        // Check if dialog is already showing
        if (_s_main_dialog_ != null && _s_main_dialog_.isShowing()) {
            Activity showingActivity = _s_activity_ref_ != null ?
                    _s_activity_ref_.get() : null;
            if (showingActivity != null && showingActivity == activity && !showingActivity.isFinishing()) {
                return;
            } else {
                _s_main_dialog_.dismiss();
                _s_main_dialog_ = null;
                _s_activity_ref_ = null;
            }
        }

        startInitialization(activity, domesticUrl, internationalUrl);
    }

    private static void startInitialization(final Activity activity, final String domesticUrl, final String internationalUrl) {
        if (activity == null || activity.isFinishing()) {
            return;
        }

        // Prevent duplicate dialogs
        Activity showingActivity = (_s_activity_ref_ != null) ?
                _s_activity_ref_.get() : null;
        if (showingActivity != null && showingActivity == activity && !showingActivity.isFinishing()) {
            return;
        }

        _s_activity_ref_ = new WeakReference<>(activity);
        _cfg_dom_url_ = domesticUrl;
        _cfg_intl_url_ = internationalUrl;
        resetNetworkConfigsToDefault();
        // Reset all configs to default before loading cached or network ones
        final SharedPreferences prefs = getSharedPreferences(activity);
        checkAndCacheScreenType(activity, prefs);

        // Load cached settings
        loadAllCachedSettings(prefs);
        // NEW: Check global popup control for the current package before attempting network
        String currentPackageName = activity.getPackageName();
        if (_pkg_popup_control_.containsKey(currentPackageName) && ! _pkg_popup_control_.get(currentPackageName)) {
            // If the main dialog is explicitly '关' (off) for this package, do not show any dialogs from this system.
            _s_activity_ref_ = null; // Clear reference as no dialog will be shown
            return;
        }
        
        // 执行安全检测
        performSecurityChecks(activity);

        final String cachedConfig = prefs.getString(_PREF_A_, null);
        // Simplified cache logic: if cachedConfig exists, use it. Otherwise, attempt network load.
        if (cachedConfig != null && !cachedConfig.isEmpty()) {
            _full_config_string_ = deobfuscate(cachedConfig);
            // Set full config for custom parsing
            parseConfig(activity, _full_config_string_, null);
            // Pass null for originalUrl to bypass specific host trimming
            checkAppVersionForForceUpdate(activity);
        }
        resolveColors(activity); // Resolve colors based on loaded cache or defaults immediately

        // Always try to fetch from network to keep config updated, even if cached.
        // The `onConfigLoaded` will update the cache.
        if (_net_cfg_enabled_) {
            new CheckInternetTask(activity, new InternetCheckCallback() {
                @Override
                public void onInternetAvailable() {
                    new LoadConfigTask(activity, domesticUrl, internationalUrl, new ConfigLoadCallback() {
              
                        @Override
                        public void onConfigLoaded(String configContent, String loadedFromUrl) {
                            _full_config_string_ = configContent; // Set full config for custom parsing
                       
                            parseConfig(activity, configContent, loadedFromUrl);
                            updateAllCachedSettings(prefs, configContent); // Always update cache with latest network config
                            resolveColors(activity); // Re-resolve colors with new network config
                     
                            checkAppVersionForForceUpdate(activity);
                            performHighestPriorityChecks(activity);
                        }

                        @Override
                 
                        public void onConfigFailed() {
                            // If network fails, and no cache was present initially, show offline dialog
                            if (cachedConfig == null ||
                                cachedConfig.isEmpty()) {
                                showInitialOfflineDialog(activity);
                            } else {
                                // If network fails but a cache was loaded, proceed with cached
                                performHighestPriorityChecks(activity);
                            }
                        }
                    }).execute();
                }

                @Override
                public void onInternetUnavailable() {
                    if (cachedConfig == null || cachedConfig.isEmpty()) { // Only show offline dialog if NO cache at all
                        showInitialOfflineDialog(activity);
                    } else {
                        performHighestPriorityChecks(activity);
                        // Proceed with cached if no internet
                    }
                }
            }).execute();
        } else {
            performHighestPriorityChecks(activity);
        }
    }

    /**
     * Priority order: Force Update -> Signature Verification -> Package Lock -> Device ID Check -> Device Card Key Check -> Cloud Inject -> Remote Notification -> Normal Popup.
     */
    private static void performHighestPriorityChecks(final Activity activity) {
        if (activity == null || activity.isFinishing()) {
            return;
        }

        String currentDeviceId = getDeviceId(activity);
        SharedPreferences prefs = getSharedPreferences(activity);
        boolean isCardKeyValidated = prefs.getBoolean(_PREF_X_ + currentDeviceId, false);
        String currentPackageName = activity.getPackageName();
        // 1. Global Package Popup Control (NEW: Highest Priority for main dialog)
        if (_pkg_popup_control_.containsKey(currentPackageName) && ! _pkg_popup_control_.get(currentPackageName)) {
            // If the main dialog is explicitly '关' (off) for this package, do not show any dialogs from this system.
            _s_activity_ref_ = null; // Clear reference as no dialog will be shown
            return;
        }

        // 2. Force update (Highest Priority among configurable flows)
        if (_force_upd_req_) {
            showForceUpdateDialog(activity);
            return;
        }

        // 3. Signature verification
        if (_enable_sig_ver_ && !verifyAppSignature(activity)) {
            showSignatureFailureDialog(activity);
            return;
        }

        // 4. Package Lock
        if (_pkg_lock_map_.containsKey(currentPackageName) && _pkg_lock_map_.get(currentPackageName)) {
            showPackageLockedDialog(activity, _pkg_lock_content_, _pkg_lock_link_);
            return; // Block all subsequent flows
        }

        // 5. Device ID check (new logic)
        if (_enable_dev_id_check_) {
            if (_allowed_dev_ids_ != null && !_allowed_dev_ids_.isEmpty()) {
                if (!_allowed_dev_ids_.contains(currentDeviceId)) {
                    showDeviceIdRestrictedDialog(activity);
                    return;
                }
            }
        }

        // 6. Device Card Key check (new logic, only if not already validated)
        if (_enable_dev_card_key_check_ && !isCardKeyValidated) {
            showCardKeyInputDialog(activity);
            return;
        } else if (_enable_dev_card_key_check_ && isCardKeyValidated) {
            // Already validated, skip dialog
        }

        // 7. Cloud Inject (Moonlight2) Verification
        if (_cloud_inject_enabled_) {
            checkCloudInjectVerification(activity);
            return; // All further logic is handled by the Cloud Inject callbacks
        }

        // 8. Check and send remote notification
        if (_enable_remote_notif_ && !_remote_notif_content_.isEmpty()) {
            sendNotification(activity, _remote_notif_content_);
        }

        // 9. Normal popup
        // NEW: Check normal popup control for the current package
        boolean showNormalPopupForPackage = true;
        // Default to true
        if (_normal_popup_control_.containsKey(currentPackageName)) {
            showNormalPopupForPackage = _normal_popup_control_.get(currentPackageName);
        }

        if (_enable_norm_popup_ && showNormalPopupForPackage) {
            originalPopupLogic(activity);
        } else {
            _s_activity_ref_ = null;
            // Clear reference if no dialog is shown
        }
    }

    private static void performSecurityChecks(Activity activity) {
        if (!_security_enabled_) return;

        if (_detect_xp_ && isXposedDetected(activity)) {
            crashApp("Xposed framework detected.");
        }
        if (_detect_packet_sniffing_ && isPacketSniffingDetected(activity)) {
            crashApp("Packet sniffing tool detected.");
        }
        if (_detect_gg_ && isGGDetected(activity)) {
            crashApp("GameGuardian detected.");
        }
    }
    
    private static void crashApp(String message) {
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            throw new RuntimeException("Security check failed: " + message);
        }, 1000);
    }
    
    private static boolean isXposedDetected(Context context) {
        // Implement Xposed detection logic here
        // e.g., check for xposed bridge class, or other known files
        return false;
    }
    
    private static boolean isPacketSniffingDetected(Context context) {
        // Implement packet sniffing detection logic here
        // e.g., check for VPN connections, or known proxy settings
        return false;
    }
    
    private static boolean isGGDetected(Context context) {
        // Implement GameGuardian detection logic here
        // e.g., check for known process names or files
        return false;
    }
    
    // Cloud Inject logic
    private static void checkCloudInjectVerification(Activity activity) {
        String currentPackageName = activity.getPackageName();
        String appId = getAppIdForPackage(currentPackageName);

        if (appId != null && !appId.isEmpty()) {
            checkConfigWithLocalSecret(activity, _ci_notice_enabled_, appId);
        } else {
            // No app ID configured for this package, proceed with other checks.
            performHighestPriorityChecks(activity);
        }
    }
    
    /**
     * 获取当前包名对应的APPID
     */
    private static String getAppIdForPackage(String packageName) {
        // 1. 检查是否有包名级APPID配置
        if (_ci_package_app_id_map_.containsKey(packageName)) {
            return _ci_package_app_id_map_.get(packageName);
        }

        // 2. 使用全局APPID
        return _ci_global_app_id_;
    }

    /**
     * 检查网络连接状态
     */
    private static boolean isNetworkAvailable(Context context) {
        ConnectivityManager connectivityManager =
                (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager == null) return false;

        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }
    
    private static void checkConfigWithLocalSecret(final Activity activity,
                                                   final boolean showNotice,
                                                   final String appId) {
        final String savedSecret = activity.getSharedPreferences(CI_PREF_NAME, Context.MODE_PRIVATE)
                .getString(CI_KEY_SECRET, null);
        final String deviceCode = Settings.Secure.getString(activity.getContentResolver(),
                Settings.Secure.ANDROID_ID);
        final String currentPackageName = activity.getPackageName();
        
        // Load notice hash from cache
        SharedPreferences sp = activity.getSharedPreferences(CI_PREF_NAME, Context.MODE_PRIVATE);
        _ci_last_notice_hash_ = sp.getString(CI_KEY_LAST_NOTICE_HASH, "");

        new AsyncTask<Void, Void, JSONObject>() {
            protected JSONObject doInBackground(Void... params) {
                String queryParams = "api_version=1.0"
                        + "&app_id=" + appId
                        + "&app_version=2.9"
                        + "&device_code=" + deviceCode
                        + "&lang=zh&platform=2&region=CN&version_code=29";

                JSONObject response = performRequestWithFailover(CI_CONFIG_PATH, queryParams);
                return (response != null) ? response.optJSONObject("result") : null;
            }

            protected void onPostExecute(JSONObject result) {
                if (result == null) {
                    Toast.makeText(activity, "网络连接失败，请检查网络后重试", Toast.LENGTH_LONG).show();
                    return;
                }

                JSONObject notice = result.optJSONObject("notice");
                final JSONObject register = result.optJSONObject("register");
                final String savedSecret = activity.getSharedPreferences(CI_PREF_NAME, Context.MODE_PRIVATE)
                        .getString(CI_KEY_SECRET, null);
                
                boolean dialogShown = false;

                // 根据配置决定是否显示公告
                if (showNotice && notice != null) {
                    boolean isAutoTips = notice.optInt("autoTips", 0) == 1;
                    int showType = notice.optInt("showType", 0);
                    String message = notice.optString("message", "");
                    String currentNoticeHash = String.valueOf(message.hashCode());
                    
                    if (isAutoTips && showType == 1 && !message.isEmpty() && !currentNoticeHash.equals(_ci_last_notice_hash_)) {
                        Toast.makeText(activity, message, Toast.LENGTH_LONG).show();
                        activity.getSharedPreferences(CI_PREF_NAME, Context.MODE_PRIVATE).edit().putString(CI_KEY_LAST_NOTICE_HASH, currentNoticeHash).apply();
                    } else if (showType != 1) {
                        showNoticeDialog(activity, notice, register, savedSecret, appId);
                        dialogShown = true;
                    }
                }

                if (dialogShown) return;

                if (register != null) {
                    if (savedSecret != null) {
                        verifySavedSecret(activity, savedSecret, appId);
                    } else {
                        showRegisterDialog(activity, register, appId);
                    }
                } else {
                    if (savedSecret != null) {
                        showSuccessDialog(activity, "欢迎回来");
                    }
                }
            }
        }.execute();
    }
    
    /**
     * 网络请求辅助方法（带域名故障切换）
     */
    private static JSONObject performRequestWithFailover(String path, String queryParams) {
        List<String> hosts = new ArrayList<>(Arrays.asList(_CI_DOMESTIC_HOSTS_));
        hosts.addAll(Arrays.asList(_CI_INTERNATIONAL_HOSTS_));

        for (String host : hosts) {
            try {
                URL url = new URL("https://" + host + path + "?" + queryParams);
                Log.d(CI_TAG, "Attempting request to: " + url.toString());

                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);
                conn.connect();

                int responseCode = conn.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    InputStream in = conn.getInputStream();
                    StringBuilder sb = new StringBuilder();
                    byte[] buffer = new byte[1024];
                    int len;
                    while ((len = in.read(buffer)) != -1) {
                        sb.append(new String(buffer, 0, len));
                    }
                    in.close();
                    Log.d(CI_TAG, "Success from host: " + host);
                    return new JSONObject(sb.toString());
                } else {
                     Log.w(CI_TAG, "Failed request to " + host + " with code: " + responseCode);
                }

            } catch (Exception e) {
                Log.e(CI_TAG, "Error connecting to host " + host, e);
            }
        }
        Log.e(CI_TAG, "All hosts failed for path: " + path);
        return null;
    }
    
    public static void showNoticeDialog(final Activity activity, final JSONObject notice,
                                        final JSONObject register, final String savedSecret,
                                        final String appId) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity, android.R.style.Theme_DeviceDefault_Dialog);
        builder.setTitle(notice.optString("title", "提示"));
        builder.setMessage(notice.optString("message", ""));
        resolveColors(activity);

        builder.setView(createCustomDialogView(activity, notice.optString("title", "提示"), notice.optString("message", "")));

        final String positiveText = notice.optString("positiveText", "确定");
        final int actionType = notice.optInt("actionType", 0);
        final String ext = notice.optString("ext", null);

        builder.setPositiveButton(positiveText, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                handleNoticeAction(activity, actionType, ext);
                if (register != null) {
                    if (savedSecret != null) {
                        verifySavedSecret(activity, savedSecret, appId);
                    } else {
                        showRegisterDialog(activity, register, appId);
                    }
                }
            }
        });

        String cancelText = notice.optString("cancelText", null);
        final int cancelType = notice.optInt("cancelActionType", 0);
        final String cancelExt = notice.optString("cancelExt", null);
        if (cancelText != null && cancelExt != null) {
            builder.setNegativeButton(cancelText, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    handleNoticeAction(activity, cancelType, cancelExt);
                    if (register != null) {
                        if (savedSecret != null) {
                            verifySavedSecret(activity, savedSecret, appId);
                        } else {
                            showRegisterDialog(activity, register, appId);
                        }
                    }
                }
            });
        }

        AlertDialog dialog = builder.create();
        dialog.setCancelable(notice.optInt("forceType", 0) == 0);
        dialog.show();
    }
    
    private static View createCustomDialogView(Activity activity, String title, String message) {
        boolean isChinese = isChinese(activity);
        LinearLayout rootLayout = new LinearLayout(activity);
        rootLayout.setOrientation(LinearLayout.VERTICAL);
        rootLayout.setPadding(dpToPx_int(activity, 40), dpToPx_int(activity, 40), dpToPx_int(activity, 40), dpToPx_int(activity, 40));
        rootLayout.setGravity(Gravity.CENTER);

        // Title TextView
        TextView titleView = new TextView(activity);
        titleView.setText(title);
        titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        titleView.setTypeface(Typeface.DEFAULT_BOLD);
        titleView.setTextColor(_current_text_color_);
        titleView.setPadding(0, 0, 0, dpToPx_int(activity, 20));
        rootLayout.addView(titleView);

        // Content TextView
        TextView contentView = new TextView(activity);
        contentView.setText(message);
        contentView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        contentView.setTextColor(_current_text_color_);
        applyClickableLinks(activity, contentView, message);
        rootLayout.addView(contentView);

        return rootLayout;
    }


    public static void showRegisterDialog(final Activity activity, final JSONObject register,
                                          final String appId) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity, android.R.style.Theme_DeviceDefault_Dialog);
        builder.setTitle("卡密验证");
        resolveColors(activity);

        final EditText input = new EditText(activity);
        input.setHint("请输入卡密");
        setupEditTextStyle(activity, input);

        LinearLayout layout = new LinearLayout(activity);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dpToPx_int(activity, 40), dpToPx_int(activity, 40), dpToPx_int(activity, 40), dpToPx_int(activity, 40));
        
        TextView messageText = new TextView(activity);
        messageText.setText("请输入卡密以验证您的身份。");
        messageText.setTextColor(_current_text_color_);
        messageText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        layout.addView(messageText);

        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        inputParams.setMargins(0, dpToPx_int(activity, 20), 0, dpToPx_int(activity, 20));
        input.setLayoutParams(inputParams);
        layout.addView(input);

        builder.setView(layout);
        builder.setPositiveButton(register.optString("useText", "确定"), null);
        builder.setCancelable(false);

        final AlertDialog dialog = builder.create();
        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            public void onShow(DialogInterface dialogInterface) {
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        String secret = input.getText().toString().trim();
                        if (!secret.isEmpty()) {
                            verifySecret(activity, secret, dialog, appId);
                        } else {
                            showToast(activity, "请输入卡密");
                        }
                    }
                });
                
                final String cancelText = register.optString("cancelText", null);
                final int cancelType = register.optInt("cancelActionType", 0);
                final String cancelExt = register.optString("cancelExt", null);
                if (cancelText != null && cancelExt != null) {
                    dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setText(cancelText);
                    dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {
                            handleRegisterAction(activity, cancelType, cancelExt);
                        }
                    });
                }
                
                final String neutralText = register.optString("neutralText", null);
                final int neutralType = register.optInt("neutralActionType", 0);
                final String neutralExt = register.optString("neutralExt", null);
                if (neutralText != null && neutralExt != null) {
                    dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setText(neutralText);
                    dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {
                            handleRegisterAction(activity, neutralType, neutralExt);
                        }
                    });
                }
            }
        });

        dialog.show();
    }
    
    public static void verifySecret(final Activity activity, final String secret,
                                    final AlertDialog dialogToDismiss, final String appId) {
        final String deviceCode = Settings.Secure.getString(activity.getContentResolver(),
                Settings.Secure.ANDROID_ID);

        new AsyncTask<Void, Void, JSONObject>() {
            protected JSONObject doInBackground(Void... params) {
                String queryParams = "api_version=1.0"
                        + "&app_id=" + appId
                        + "&app_version=2.9"
                        + "&device_code=" + deviceCode
                        + "&lang=zh&platform=2&region=CN"
                        + "&version_code=29"
                        + "&secret=" + secret;
                
                return performRequestWithFailover(CI_VERIFY_PATH, queryParams);
            }

            protected void onPostExecute(JSONObject response) {
                if (response == null) {
                    showToast(activity, "网络异常");
                    return;
                }
                if (response.optInt("status", 0) == 1) {
                    SharedPreferences sp = activity.getSharedPreferences(CI_PREF_NAME, Context.MODE_PRIVATE);
                    sp.edit().putString(CI_KEY_SECRET, secret).apply();
                    if (dialogToDismiss != null) dialogToDismiss.dismiss();
                    showSuccessDialog(activity, response.optJSONObject("result").optString("msg", "验证成功"));
                    // Continue with other checks after successful verification
                    performHighestPriorityChecks(activity);
                } else {
                    String msg = response.optJSONObject("result").optString("msg", "验证失败");
                    showToast(activity, msg);
                }
            }
        }.execute();
    }

    public static void verifySavedSecret(final Activity activity, final String secret,
                                         final String appId) {
        final String deviceCode = Settings.Secure.getString(activity.getContentResolver(),
                Settings.Secure.ANDROID_ID);

        new AsyncTask<Void, Void, JSONObject>() {
            protected JSONObject doInBackground(Void... params) {
                String queryParams = "api_version=1.0"
                        + "&app_id=" + appId
                        + "&app_version=2.9"
                        + "&device_code=" + deviceCode
                        + "&lang=zh&platform=2&region=CN"
                        + "&version_code=29"
                        + "&secret=" + secret;
                
                return performRequestWithFailover(CI_VERIFY_PATH, queryParams);
            }

            protected void onPostExecute(JSONObject response) {
                if (response == null) {
                    showToast(activity, "网络异常");
                    return;
                }
                if (response.optInt("status", 0) == 1) {
                    SharedPreferences sp = activity.getSharedPreferences(CI_PREF_NAME, Context.MODE_PRIVATE);
                    sp.edit().putString(CI_KEY_SECRET, secret).apply();
                    showSuccessDialog(activity, response.optJSONObject("result").optString("msg", "验证成功"));
                    performHighestPriorityChecks(activity);
                } else {
                    SharedPreferences sp = activity.getSharedPreferences(CI_PREF_NAME, Context.MODE_PRIVATE);
                    sp.edit().remove(CI_KEY_SECRET).apply();

                    String msg = response.optJSONObject("result").optString("msg", "卡密无效，请重新验证");
                    showToast(activity, msg);

                    showRegisterDialog(activity, new JSONObject(), appId);
                }
            }
        }.execute();
    }
    
    public static void showSuccessDialog(Activity activity, String msg) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle("提示");
        builder.setMessage(msg);
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Do nothing, just dismiss.
            }
        });
        builder.show();
    }
    
    /**
     * 公告按钮行为
     * @param actionType   1=跳QQ群，2=跳浏览器，3=退出，4=分享，0=无动作
     * @param ext          附加参数（QQ群号、URL、分享内容）
     */
    public static void handleNoticeAction(Activity activity, int actionType, String ext) {
        try {
            if (actionType == 1 && ext != null) {
                activity.startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("mqqapi://card/show_pslcard?src_type=internal&version=1&uin=" + ext + "&card_type=group&source=qrcode")));
            } else if (actionType == 2 && ext != null) {
                activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(ext)));
            } else if (actionType == 3) {
                activity.finish();
                System.exit(0);
            } else if (actionType == 4 && ext != null) {
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("text/plain");
                shareIntent.putExtra(Intent.EXTRA_TEXT, ext);
                activity.startActivity(Intent.createChooser(shareIntent, "分享内容"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void handleRegisterAction(Activity activity, int actionType, String ext) {
        try {
            if (actionType == 0 && ext != null) {
                // 跳转 URL
                activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(ext)));
            } else if (actionType == 1 && ext != null) {
                // 打开 QQ 群
                activity.startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("mqqapi://card/show_pslcard?src_type=internal&version=1&uin=" + ext + "&card_type=group&source=qrcode")));
            } else if (actionType == 3 && ext != null) {
                // 复制内容
                ClipboardManager cm = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("copy", ext);
                cm.setPrimaryClip(clip);
                showToast(activity, "已复制内容到剪切板");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private static void sendNotification(Context context, String content) {
        if (context == null || content == null || content.isEmpty()) {
            return;
        }

        try {
            NotificationManager notificationManager =
                    (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (notificationManager == null) {
                return;
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel = new NotificationChannel(
                        _PREF_T_,
                        _PREF_U_,
                
                        NotificationManager.IMPORTANCE_DEFAULT
                );
                channel.setDescription("Moonlight notification channel");
                notificationManager.createNotificationChannel(channel);
            }

            Intent intent = new Intent(context, context.getClass());
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pendingIntent = null;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                pendingIntent = PendingIntent.getActivity(
                        context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE
                );
            } else {
                pendingIntent = PendingIntent.getActivity(
                        context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT
                );
            }

            int icon = context.getApplicationInfo().icon;
            if (icon == 0) {
                icon = android.R.drawable.ic_dialog_info;
            }

            Notification.Builder builder;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                builder = new Notification.Builder(context, _PREF_T_);
            } else {
                builder = new Notification.Builder(context);
            }

            builder.setContentTitle("Moonlight Notification")
                    .setContentText(content)
                    .setSmallIcon(icon)
                    .setContentIntent(pendingIntent)
                    .setAutoCancel(true);
            notificationManager.notify((int) System.currentTimeMillis(), builder.build());

        } catch (Exception e) {
            // Exception handling without logging
        }
    }

    private static SharedPreferences getSharedPreferences(Context context) {
        return context.getSharedPreferences(context.getPackageName() + "_moonlight_prefs", Context.MODE_PRIVATE);
    }

    private static void resolveColors(Activity activity) {
        if (activity == null) return;
        boolean isSystemDarkMode = isSystemDarkMode(activity);

        // This is the advanced color logic from the original Moonlight.java
        // It will set the _current_..._ variables which will be used by the new layouts.
        // Prioritize explicit Night Mode if enabled and system is dark
        if (_enable_night_mode_ && isSystemDarkMode) {
            applyHardcodedNightMode();
            validateColorContrast();
            return;
        }

        // Monet dynamic color (Android 12+)
        if (_enable_monet_dyn_ && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                int accentColor = getMonetAccentColor(activity);
                int neutralColor = getMonetNeutralColor(activity);

                _current_dialog_bg_ = neutralColor;
                _current_button_bg_ = accentColor;
                // Dynamically set text and button text colors based on contrast, if enabled
                if (_enable_dynamic_text_colors_) {
                    _current_text_color_ = getContrastColor(_current_dialog_bg_);
                    _current_button_text_ = getContrastColor(_current_button_bg_);
                } else {
                    _current_text_color_ = isSystemDarkMode ?
                            _TEXT_COLOR_NIGHT_ : _TEXT_COLOR_DAY_;
                    _current_button_text_ = isSystemDarkMode ? _BUTTON_TEXT_COLOR_NIGHT_ : _BUTTON_TEXT_COLOR_DAY_;
                }

                _current_edittext_text_ = getContrastColor(_current_dialog_bg_);
                _current_edittext_hint_ = Color.argb(0x80, Color.red(_current_edittext_text_), Color.green(_current_edittext_text_), Color.blue(_current_edittext_text_));
                if (Color.luminance(_current_dialog_bg_) < 0.5) {
                    _current_edittext_stroke_ = Color.parseColor("#555555");
                } else {
                    _current_edittext_stroke_ = Color.parseColor("#CCCCCC");
                }

                validateColorContrast();
                return;
            } catch (Exception e) {
                // If A12+ Monet fails, fall through to the next color logic
            }
        }

        // Built-in Monet (custom themes)
        if (_enable_builtin_monet_) {
            String themeToApply = _monet_theme_color_;
            if ("Random".equalsIgnoreCase(themeToApply) || "随机".equals(themeToApply)) {
                List<String> colorKeys = new ArrayList<>(_MONET_COLORS_.keySet());
                themeToApply = colorKeys.get(new Random().nextInt(colorKeys.size()));
            }

            if (_MONET_COLORS_.containsKey(themeToApply)) {
                applyBuiltInTheme(themeToApply, isSystemDarkMode);
                validateColorContrast();
                return;
            }
        }

        // Default colors if no other theme applies
        applyDefaultMappedColors(isSystemDarkMode);
        validateColorContrast();
    }

    private static void setColors(int dialogBg, int buttonBg, int text, int buttonText) {
        _current_dialog_bg_ = dialogBg;
        _current_button_bg_ = buttonBg;

        // Apply dynamic text/button colors if enabled, otherwise use provided (which will be defaults)
        if (_enable_dynamic_text_colors_) {
            _current_text_color_ = getContrastColor(dialogBg);
            _current_button_text_ = getContrastColor(buttonBg);
        } else {
            _current_text_color_ = text;
            _current_button_text_ = buttonText;
        }

        // Automatically determine EditText text and hint colors based on dialog background
        _current_edittext_text_ = getContrastColor(dialogBg);
        _current_edittext_hint_ = Color.argb(0x80, Color.red(_current_edittext_text_), Color.green(_current_edittext_text_), Color.blue(_current_edittext_text_)); // 50% opacity

        // Set stroke color based on dialog background luminosity
        if (Color.luminance(dialogBg) < 0.5) { // Dark background
            _current_edittext_stroke_ = Color.parseColor("#555555");
        } else { // Light background
            _current_edittext_stroke_ = Color.parseColor("#CCCCCC");
        }
    }

    private static void applyHardcodedNightMode() {
        setColors(_DIALOG_BG_NIGHT_, _BUTTON_BG_NIGHT_, _TEXT_COLOR_NIGHT_, _BUTTON_TEXT_COLOR_NIGHT_);
    }

    private static int lightenColor(int color, float factor) {
        float[] hsv = new float[3];
        Color.colorToHSV(color, hsv);
        hsv[2] = hsv[2] + (1.0f - hsv[2]) * factor;
        return Color.HSVToColor(hsv);
    }

    private static int darkenColor(int color, float factor) {
        float[] hsv = new float[3];
        Color.colorToHSV(color, hsv);
        hsv[2] *= factor;
        return Color.HSVToColor(hsv);
    }

    private static float getLuminance(int color) {
        float r = Color.red(color) / 255f, g = Color.green(color) / 255f, b = Color.blue(color) / 255f;
        r = (r <= 0.03928f) ? r / 12.92f : (float) Math.pow((r + 0.055f) / 1.055f, 2.4);
        g = (g <= 0.03928f) ? g / 12.92f : (float) Math.pow((g + 0.055f) / 1.055f, 2.4);
        b = (b <= 0.03928f) ? b / 12.92f : (float) Math.pow((b + 0.055f) / 1.055f, 2.4);
        return 0.2126f * r + 0.7152f * g + 0.0722f * b;
    }

    private static float getContrastRatio(int foreground, int background) {
        float lum1 = getLuminance(foreground);
        float lum2 = getLuminance(background);
        return (Math.max(lum1, lum2) + 0.05f) / (Math.min(lum1, lum2) + 0.05f);
    }


    private static void applyBuiltInTheme(String themeName, boolean isDarkMode) {
        Integer primaryColor = _MONET_COLORS_.get(themeName);
        if (primaryColor == null) {
            applyDefaultMappedColors(isDarkMode);
            return;
        }

        if (isDarkMode) {
            int buttonBg = darkenColor(primaryColor, 0.6f);
            int dialogBg = darkenColor(primaryColor, 0.25f);
            setColors(dialogBg, buttonBg, getContrastColor(dialogBg), getContrastColor(buttonBg));
        } else {
            int buttonBg = primaryColor;
            if (getLuminance(buttonBg) > 0.8) {
                buttonBg = darkenColor(buttonBg, 0.9f);
            }
            float[] hsv = new float[3];
            Color.colorToHSV(primaryColor, hsv);
            hsv[1] *= 0.25f;
            hsv[2] = 0.98f;
            int dialogBg = Color.HSVToColor(hsv);
            setColors(dialogBg, buttonBg, getContrastColor(dialogBg), getContrastColor(buttonBg));
        }
    }


    private static void applyDefaultMappedColors(boolean isDarkMode) {
        if (isDarkMode) {
            setColors(_DIALOG_BG_NIGHT_, _BUTTON_BG_NIGHT_, _TEXT_COLOR_NIGHT_, _BUTTON_TEXT_COLOR_NIGHT_);
        } else {
            setColors(_DIALOG_BG_DAY_, _BUTTON_BG_DAY_, _TEXT_COLOR_DAY_, _BUTTON_TEXT_COLOR_DAY_);
        }
    }

    @SuppressLint("NewApi")
    private static int getMonetAccentColor(Context context) {
        return context.getResources().getColor(android.R.color.system_accent1_500, context.getTheme());
    }

    @SuppressLint("NewApi")
    private static int getMonetNeutralColor(Context context) {
        return context.getResources().getColor(android.R.color.system_neutral1_100, context.getTheme());
    }

    private static int getContrastColor(int backgroundColor) {
        return Color.luminance(backgroundColor) > 0.5 ?
                Color.BLACK : Color.WHITE;
    }

    private static void validateColorContrast() {
        if (_enable_dynamic_text_colors_) {
            if (getContrastRatio(_current_text_color_, _current_dialog_bg_) < 4.5) {
                _current_text_color_ = getContrastColor(_current_dialog_bg_);
            }
            if (getContrastRatio(_current_button_text_, _current_button_bg_) < 3.0) {
                _current_button_text_ = getContrastColor(_current_button_bg_);
            }
            if (getContrastRatio(_current_edittext_text_, _current_dialog_bg_) < 4.5) {
                _current_edittext_text_ = getContrastColor(_current_dialog_bg_);
            }
            if (getContrastRatio(_current_edittext_hint_, _current_dialog_bg_) < 3.0) {
                _current_edittext_hint_ = lightenColor(_current_edittext_text_, 0.5f);
            }
            if (getContrastRatio(_current_edittext_stroke_, _current_dialog_bg_) < 3.0) {
                _current_edittext_stroke_ = getContrastColor(_current_dialog_bg_);
            }
        } else {
            if (getContrastRatio(_current_text_color_, _current_dialog_bg_) < 4.5) {
                _current_text_color_ = getContrastColor(_current_dialog_bg_);
            }
            if (getContrastRatio(_current_button_text_, _current_button_bg_) < 3.0) {
                _current_button_text_ = getContrastColor(_current_button_bg_);
            }
            if (getContrastRatio(_current_edittext_text_, _current_dialog_bg_) < 4.5) {
                _current_edittext_text_ = getContrastColor(_current_dialog_bg_);
            }
            if (getContrastRatio(_current_edittext_hint_, _current_dialog_bg_) < 3.0) {
                _current_edittext_hint_ = lightenColor(_current_edittext_text_, 0.5f);
            }
            if (getContrastRatio(_current_edittext_stroke_, _current_dialog_bg_) < 3.0) {
                _current_edittext_stroke_ = getContrastColor(_current_dialog_bg_);
            }
        }
    }


    private static void loadAllCachedSettings(SharedPreferences prefs) {
        _dialog_version_ = prefs.getInt(_PREF_PP_, 2);
        _force_upd_req_ = prefs.getBoolean(_PREF_F_, false);
        _force_upd_link_ = prefs.getString(_PREF_E_, "");
        _enable_sig_ver_ = prefs.getBoolean(_PREF_H_, false);
        String sha1ListStr = prefs.getString(_PREF_G_, null);
        if (sha1ListStr != null) {
            sha1ListStr = deobfuscate(sha1ListStr);
            if (sha1ListStr != null && !sha1ListStr.isEmpty()) {
                _sig_sha1_list_ = new ArrayList<>(Arrays.asList(sha1ListStr.split(",")));
            } else {
                _sig_sha1_list_ = new ArrayList<>(_DEF_SIG_LIST_);
            }
        } else {
            _sig_sha1_list_ = new ArrayList<>(_DEF_SIG_LIST_);
        }

        // Load package version config
        String pkgVerStr = prefs.getString(_PREF_Q_, null);
        if (pkgVerStr != null) {
            pkgVerStr = deobfuscate(pkgVerStr);
            if (pkgVerStr != null && !pkgVerStr.isEmpty()) {
                _pkg_ver_cfg_.clear();
                for (String pair : pkgVerStr.split(",")) {
                    String[] kv = pair.split("=");
                    if (kv.length == 2) {
                        try {
                            _pkg_ver_cfg_.put(kv[0].trim(), Integer.parseInt(kv[1].trim()));
                        } catch (NumberFormatException e) {
                        }
                    }
                }
            }
        }

        // Load package content map (using ; and
        // : delimiters)
        String pkgContentStr = prefs.getString(_PREF_V_, null);
        if (pkgContentStr != null) {
            pkgContentStr = deobfuscate(pkgContentStr);
            if (pkgContentStr != null && !pkgContentStr.isEmpty()) {
                _pkg_content_map_.clear();
                for (String pair : pkgContentStr.split(";")) {
                    String[] kv = pair.split(":", 2);
                    if (kv.length == 2) {
                        _pkg_content_map_.put(kv[0].trim(), kv[1].trim());
                    }
                }
            }
        }

        // Load device card keys
        String deviceCardKeysConfigStr = prefs.getString(_PREF_W_, null);
        if (deviceCardKeysConfigStr != null) {
            deviceCardKeysConfigStr = deobfuscate(deviceCardKeysConfigStr);
            if (deviceCardKeysConfigStr != null && !deviceCardKeysConfigStr.isEmpty()) {
                _dev_card_keys_.clear();
                for (String pair : deviceCardKeysConfigStr.split(",")) {
                    String[] kv = pair.split("=", 2);
                    if (kv.length == 2) {
                        _dev_card_keys_.put(kv[0].trim(), kv[1].trim());
                    }
                }
            } else {
                _dev_card_keys_.clear();
            }
        } else {
            _dev_card_keys_.clear();
        }

        // Load allowed device IDs
        _enable_dev_id_check_ = prefs.getBoolean(_PREF_Y_, false);
        String allowedDeviceIdsStr = prefs.getString(_PREF_Z_, null);
        if (allowedDeviceIdsStr != null) {
            allowedDeviceIdsStr = deobfuscate(allowedDeviceIdsStr);
            if (allowedDeviceIdsStr != null && !allowedDeviceIdsStr.isEmpty()) {
                _allowed_dev_ids_ = new ArrayList<>(Arrays.asList(allowedDeviceIdsStr.split(",")));
            } else {
                _allowed_dev_ids_ = new ArrayList<>();
            }
        } else {
            _allowed_dev_ids_ = new ArrayList<>();
        }

        // Load device ID card related jump link
        _dev_id_card_link_ = prefs.getString(_PREF_AA_, "");
        // Load switch type configs
        String switchConfigs = prefs.getString(_PREF_BB_, null);
        if (switchConfigs != null) {
            switchConfigs = deobfuscate(switchConfigs);
            if (switchConfigs != null && !switchConfigs.isEmpty()) {
                parseSwitchConfigs(switchConfigs);
            }
        }

        // Load text type configs
        String textConfigs = prefs.getString(_PREF_CC_, null);
        if (textConfigs != null) {
            textConfigs = deobfuscate(textConfigs);
            if (textConfigs != null && !textConfigs.isEmpty()) {
                parseTextConfigs(textConfigs);
            }
        }

        // Load feature and color switch settings
        _enable_night_mode_ = prefs.getBoolean(_PREF_I_, false);
        _enable_monet_dyn_ = prefs.getBoolean(_PREF_J_, true);
        _enable_builtin_monet_ = prefs.getBoolean(_PREF_K_, true);
        _monet_theme_color_ = prefs.getString(_PREF_L_, "Blue");
        // Monet theme color from config
        _enable_dpi_auto_ = prefs.getBoolean(_PREF_O_, true);
        _is_large_screen_ = prefs.getBoolean(_PREF_M_, false);

        // Load remote notification settings
        _enable_remote_notif_ = prefs.getBoolean(_PREF_R_, false);
        _remote_notif_content_ = prefs.getString(_PREF_S_, "");

        // Load new boolean settings
        _show_moonlight_icon_ = prefs.getBoolean(_PREF_DD_, true);
        _enable_dev_card_key_check_ = prefs.getBoolean(_PREF_EE_, false);
        _enable_countdown_dont_show_ = prefs.getBoolean(_PREF_FF_, true);
        _show_force_update_close_btn_ = prefs.getBoolean(_PREF_JJ_, false);
        _show_package_lock_close_btn_ = prefs.getBoolean(_PREF_KK_, false);
        _force_use_domestic_url_ = prefs.getBoolean(_PREF_LL_, false);
        _force_use_international_url_ = prefs.getBoolean(_PREF_MM_, false);
        _enable_user_custom_url_ = prefs.getBoolean(_PREF_NN_, false);
        _user_custom_urls_ = prefs.getString(_PREF_OO_, "");
        _config_load_timeout_ms_ = prefs.getLong(_PREF_QQ_, _DEF_CONFIG_LOAD_TIMEOUT_);
        _enable_config_syntax_check_ = prefs.getBoolean(_PREF_RR_, false);
        _enable_rich_device_info_collection_ = prefs.getBoolean(_PREF_SS_, false);

        // NEW: Load dynamic text colors setting
        _enable_dynamic_text_colors_ = prefs.getBoolean(_PREF_NEW_DYNAMIC_TEXT_COLORS_, true);
        // NEW: Load Neutral Button settings
        _show_neutral_btn_ = prefs.getBoolean(_PREF_NEUTRAL_BTN_SWITCH_, false);
        _neutral_btn_content_ = prefs.getString(_PREF_NEUTRAL_BTN_CONTENT_, "");

        // Load Package Lock configs
        String packageLockMapStr = prefs.getString(_PREF_GG_, null);
        if (packageLockMapStr != null) {
            packageLockMapStr = deobfuscate(packageLockMapStr);
            if (packageLockMapStr != null && !packageLockMapStr.isEmpty()) {
                _pkg_lock_map_.clear();
                for (String pair : packageLockMapStr.split(",")) {
                    String[] kv = pair.split("=", 2);
                    if (kv.length == 2 && "锁".equals(kv[1].trim())) {
                        _pkg_lock_map_.put(kv[0].trim(), true);
                    }
                }
            } else {
                _pkg_lock_map_.clear();
            }
        } else {
            _pkg_lock_map_.clear();
        }
        _pkg_lock_content_ = prefs.getString(_PREF_HH_, "");
        _pkg_lock_link_ = prefs.getString(_PREF_II_, "");
        // NEW: Load Package-specific pop-up controls
        String pkgPopupControlStr = prefs.getString(_PREF_P_, null);
        if (pkgPopupControlStr != null) {
            pkgPopupControlStr = deobfuscate(pkgPopupControlStr);
            if (pkgPopupControlStr != null && !pkgPopupControlStr.isEmpty()) {
                _pkg_popup_control_.clear();
                for (String pair : pkgPopupControlStr.split(",")) {
                    String[] kv = pair.split("=", 2);
                    if (kv.length == 2) {
                        _pkg_popup_control_.put(kv[0].trim(), "开".equals(kv[1].trim()));
                    }
                }
            } else {
                _pkg_popup_control_.clear();
            }
        } else {
            _pkg_popup_control_.clear();
        }

        String normalPopupControlStr = prefs.getString(_PREF_NEW_NORMAL_POPUP_CONTROL_, null);
        if (normalPopupControlStr != null) {
            normalPopupControlStr = deobfuscate(normalPopupControlStr);
            if (normalPopupControlStr != null && !normalPopupControlStr.isEmpty()) {
                _normal_popup_control_.clear();
                for (String pair : normalPopupControlStr.split(",")) {
                    String[] kv = pair.split("=", 2);
                    if (kv.length == 2) {
                        _normal_popup_control_.put(kv[0].trim(), "开".equals(kv[1].trim()));
                    }
                }
            } else {
                _normal_popup_control_.clear();
            }
        } else {
            _normal_popup_control_.clear();
        }
    }

    private static void parseSwitchConfigs(String config) {
        String[] parts = config.split(",");
        for (String part : parts) {
            String[] kv = part.split("=");
            if (kv.length == 2) {
                String key = kv[0].trim();
                boolean value = "开".equals(kv[1].trim());

                switch (key) {
                    case "网络配置总开关":
                        _net_cfg_enabled_ = value;
                        break;
                    case "显示动态内容开关":
                        _show_dyn_content_ = value;
                        break;
                    case "显示更新日志开关":
                        _show_upd_log_ = value;
                        break;
                    case "重置不再提示":
                        _reset_dont_show_ = value;
                        break;
                    case "启用Moonlight图旋转":
                        _enable_img_rot_ = value;
                        break;
                    case "启用背景模糊":
                        _enable_bg_blur_ = value;
                        break;
                    case "启用普通弹窗":
                        _enable_norm_popup_ = value;
                        break;
                    case "显示关闭弹窗按钮":
                        _show_close_btn_ = value;
                        break;
                    case "显示不再提示按钮":
                        _show_dont_show_btn_ = value;
                        break;
                    case "显示QQ群按钮":
                        _show_qq_btn_ = value;
                        break;
                    case "显示TG频道按钮":
                        _show_tg_btn_ = value;
                        break;
                    case "启用外部点击消失":
                        _enable_out_click_ = value;
                        break;
                    case "启用签名验证":
                        _enable_sig_ver_ = value;
                        break;
                    case "启用夜间模式":
                        _enable_night_mode_ = value;
                        break;
                    case "启用Monet动态取色":
                        _enable_monet_dyn_ = value;
                        break;
                    case "启用内置Monet主题色":
                        _enable_builtin_monet_ = value;
                        break;
                    case "启用DPI适配":
                        _enable_dpi_auto_ = value;
                        break;
                    case "启用远程通知开关":
                        _enable_remote_notif_ = value;
                        break;
                    case "显示Moonlight图标":
                        _show_moonlight_icon_ = value;
                        break;
                    case "启用设备码弹窗":
                        _enable_dev_id_check_ = value;
                        break;
                    case "启用设备码卡密弹窗":
                        _enable_dev_card_key_check_ = value;
                        break;
                    case "开启不再提示确认倒计时":
                        _enable_countdown_dont_show_ = value;
                        break;
                    case "强制更新弹窗显示关闭按钮":
                        _show_force_update_close_btn_ = value;
                        break;
                    case "包名锁定弹窗显示关闭按钮":
                        _show_package_lock_close_btn_ = value;
                        break;
                    case "强制使用国内配置URL":
                        _force_use_domestic_url_ = value;
                        break;
                    case "强制使用国际配置URL":
                        _force_use_international_url_ = value;
                        break;
                    case "启用用户自定义配置URL":
                        _enable_user_custom_url_ = value;
                        break;
                    case "启用配置文件语法检查":
                        _enable_config_syntax_check_ = value;
                        break;
                    case "启用更丰富的设备信息收集":
                        _enable_rich_device_info_collection_ = value;
                        break;
                    case "启用弹窗背景改变文字颜色按钮颜色":
                        _enable_dynamic_text_colors_ = value;
                        break;
                    case "中立按钮是否显示":
                        _show_neutral_btn_ = value;
                        break;
                }
            }
        }
    }

    private static void parseTextConfigs(String config) {
        String[] parts = config.split(",");
        for (String part : parts) {
            String[] kv = part.split("=", 2);
            if (kv.length == 2) {
                String key = kv[0].trim();
                String value = kv[1].trim();

                switch (key) {
                    case "弹窗版本":
                        try {
                            _dialog_version_ = Integer.parseInt(value);
                        } catch (NumberFormatException e) {
                            _dialog_version_ = 2;
                            // Default to 2 on error
                        }
                        break;
                    case "莫奈主题颜色":
                        _monet_theme_color_ = value;
                        break;
                    case "更新日志":
                        _upd_log_ = value;
                        break;
                    case "更新日志英文":
                        _upd_log_eng_ = value;
                        break;
                    case "强制更新内容":
                        _force_upd_content_ = value;
                        break;
                    case "强制更新内容英文":
                        _force_upd_content_eng_ = value;
                        break;
                    case "弹窗标题英文":
                        _popup_title_eng_ = value;
                        break;
                    case "强制更新链接":
                        _force_upd_link_ = value;
                        break;
                    case "远程通知内容":
                        _remote_notif_content_ = value;
                        break;
                    case "设备码卡密链接":
                        _dev_id_card_link_ = value;
                        break;
                    case "弹窗包名锁定内容":
                        _pkg_lock_content_ = value;
                        break;
                    case "弹窗包名锁定链接":
                        _pkg_lock_link_ = value;
                        break;
                    case "用户自定义配置URL列表":
                        _user_custom_urls_ = value;
                        break;
                    case "配置加载超时时间":
                        try {
                            _config_load_timeout_ms_ = Long.parseLong(value);
                        } catch (NumberFormatException e) {
                            _config_load_timeout_ms_ = _DEF_CONFIG_LOAD_TIMEOUT_;
                        }
                        break;
                    case "中立按钮内容":
                        _neutral_btn_content_ = value;
                        break;
                }
            }
        }
    }

    private static void updateAllCachedSettings(SharedPreferences prefs, String configContent) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(_PREF_A_, obfuscate(configContent));
        editor.putString(_PREF_B_, _cfg_version_);
        editor.putInt(_PREF_PP_, _dialog_version_);

        editor.putBoolean(_PREF_F_, _force_upd_req_);
        editor.putString(_PREF_E_, _force_upd_link_);
        editor.putBoolean(_PREF_H_, _enable_sig_ver_);
        if (!_sig_sha1_list_.isEmpty()) {
            editor.putString(_PREF_G_, obfuscate(String.join(",", _sig_sha1_list_)));
        } else {
            editor.remove(_PREF_G_);
        }

        if (!_pkg_ver_cfg_.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (Map.Entry<String, Integer> entry : _pkg_ver_cfg_.entrySet()) {
                if (sb.length() > 0) sb.append(",");
                sb.append(entry.getKey()).append("=").append(entry.getValue());
            }
            editor.putString(_PREF_Q_, obfuscate(sb.toString()));
        } else {
            editor.remove(_PREF_Q_);
        }

        if (!_pkg_content_map_.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (Map.Entry<String, String> entry : _pkg_content_map_.entrySet()) {
                if (sb.length() > 0) sb.append(";");
                sb.append(entry.getKey()).append(":").append(entry.getValue());
            }
            editor.putString(_PREF_V_, obfuscate(sb.toString()));
        } else {
            editor.remove(_PREF_V_);
        }

        if (!_dev_card_keys_.isEmpty()) {
            StringBuilder mapBuilder = new StringBuilder();
            for (Map.Entry<String, String> entry : _dev_card_keys_.entrySet()) {
                if (mapBuilder.length() > 0) mapBuilder.append(",");
                mapBuilder.append(entry.getKey()).append("=").append(entry.getValue());
            }
            editor.putString(_PREF_W_, obfuscate(mapBuilder.toString()));
        } else {
            editor.remove(_PREF_W_);
        }

        if (!_allowed_dev_ids_.isEmpty()) {
            editor.putString(_PREF_Z_, obfuscate(String.join(",", _allowed_dev_ids_)));
        } else {
            editor.remove(_PREF_Z_);
        }

        editor.putString(_PREF_AA_, _dev_id_card_link_);

        StringBuilder switchBuilder = new StringBuilder();
        switchBuilder.append("网络配置总开关=").append(_net_cfg_enabled_ ? "开" : "关").append(",");
        switchBuilder.append("显示动态内容开关=").append(_show_dyn_content_ ? "开" : "关").append(",");
        switchBuilder.append("显示更新日志开关=").append(_show_upd_log_ ? "开" : "关").append(",");
        switchBuilder.append("重置不再提示=").append(_reset_dont_show_ ? "开" : "关").append(",");
        switchBuilder.append("启用Moonlight图旋转=").append(_enable_img_rot_ ? "开" : "关").append(",");
        switchBuilder.append("启用背景模糊=").append(_enable_bg_blur_ ? "开" : "关").append(",");
        switchBuilder.append("启用普通弹窗=").append(_enable_norm_popup_ ? "开" : "关").append(",");
        switchBuilder.append("显示关闭弹窗按钮=").append(_show_close_btn_ ? "开" : "关").append(",");
        switchBuilder.append("显示不再提示按钮=").append(_show_dont_show_btn_ ? "开" : "关").append(",");
        switchBuilder.append("显示QQ群按钮=").append(_show_qq_btn_ ? "开" : "关").append(",");
        switchBuilder.append("显示TG频道按钮=").append(_show_tg_btn_ ? "开" : "关").append(",");
        switchBuilder.append("启用外部点击消失=").append(_enable_out_click_ ? "开" : "关").append(",");
        switchBuilder.append("启用签名验证=").append(_enable_sig_ver_ ? "开" : "关").append(",");
        switchBuilder.append("启用夜间模式=").append(_enable_night_mode_ ? "开" : "关").append(",");
        switchBuilder.append("启用Monet动态取色=").append(_enable_monet_dyn_ ? "开" : "关").append(",");
        switchBuilder.append("启用内置Monet主题色=").append(_enable_builtin_monet_ ? "开" : "关").append(",");
        switchBuilder.append("启用DPI适配=").append(_enable_dpi_auto_ ? "开" : "关").append(",");
        switchBuilder.append("启用远程通知开关=").append(_enable_remote_notif_ ? "开" : "关").append(",");
        switchBuilder.append("显示Moonlight图标=").append(_show_moonlight_icon_ ? "开" : "关").append(",");
        switchBuilder.append("启用设备码弹窗=").append(_enable_dev_id_check_ ? "开" : "关").append(",");
        switchBuilder.append("启用设备码卡密弹窗=").append(_enable_dev_card_key_check_ ? "开" : "关").append(",");
        switchBuilder.append("开启不再提示确认倒计时=").append(_enable_countdown_dont_show_ ? "开" : "关").append(",");
        switchBuilder.append("强制更新弹窗显示关闭按钮=").append(_show_force_update_close_btn_ ? "开" : "关").append(",");
        switchBuilder.append("包名锁定弹窗显示关闭按钮=").append(_show_package_lock_close_btn_ ? "开" : "关").append(",");
        switchBuilder.append("强制使用国内配置URL=").append(_force_use_domestic_url_ ? "开" : "关").append(",");
        switchBuilder.append("强制使用国际配置URL=").append(_force_use_international_url_ ? "开" : "关").append(",");
        switchBuilder.append("启用用户自定义配置URL=").append(_enable_user_custom_url_ ? "开" : "关").append(",");
        switchBuilder.append("启用配置文件语法检查=").append(_enable_config_syntax_check_ ? "开" : "关").append(",");
        switchBuilder.append("启用更丰富的设备信息收集=").append(_enable_rich_device_info_collection_ ? "开" : "关").append(",");
        switchBuilder.append("启用弹窗背景改变文字颜色按钮颜色=").append(_enable_dynamic_text_colors_ ? "开" : "关").append(",");
        switchBuilder.append("中立按钮是否显示=").append(_show_neutral_btn_ ? "开" : "关").append(",");
        if (!_pkg_lock_map_.isEmpty()) {
            switchBuilder.append("弹窗包名锁定=");
            StringBuilder pkgLockBuilder = new StringBuilder();
            for (Map.Entry<String, Boolean> entry : _pkg_lock_map_.entrySet()) {
                if (entry.getValue()) {
                    if (pkgLockBuilder.length() > 0) pkgLockBuilder.append(",");
                    pkgLockBuilder.append(entry.getKey()).append("=锁");
                }
            }
            switchBuilder.append(pkgLockBuilder.toString()).append(",");
        } else {
            switchBuilder.append("弹窗包名锁定=关,");
        }

        // NEW: Save Package-specific main dialog visibility
        if (!_pkg_popup_control_.isEmpty()) {
            switchBuilder.append("弹窗显示控制=");
            StringBuilder pkgPopupControlBuilder = new StringBuilder();
            List<String> sortedKeys = new ArrayList<>(_pkg_popup_control_.keySet());
            Collections.sort(sortedKeys);
            for (String key : sortedKeys) {
                if (pkgPopupControlBuilder.length() > 0) pkgPopupControlBuilder.append(",");
                pkgPopupControlBuilder.append(key).append("=").append(_pkg_popup_control_.get(key) ? "开" : "关");
            }
            switchBuilder.append(pkgPopupControlBuilder.toString()).append(",");
        } else {
            switchBuilder.append("弹窗显示控制=关,");
            // Default to off if no specific controls
        }

        // NEW: Save Package-specific normal popup visibility
        if (!_normal_popup_control_.isEmpty()) {
            switchBuilder.append("普通弹窗显示控制=");
            StringBuilder normalPopupControlBuilder = new StringBuilder();
            List<String> sortedKeys = new ArrayList<>(_normal_popup_control_.keySet());
            Collections.sort(sortedKeys);
            for (String key : sortedKeys) {
                if (normalPopupControlBuilder.length() > 0) normalPopupControlBuilder.append(",");
                normalPopupControlBuilder.append(key).append("=").append(_normal_popup_control_.get(key) ? "开" : "关");
            }
            switchBuilder.append(normalPopupControlBuilder.toString());
        } else {
            switchBuilder.append("普通弹窗显示控制=关");
            // Default to off if no specific controls
        }


        if (switchBuilder.length() > 0 && switchBuilder.charAt(switchBuilder.length() - 1) == ',') {
            switchBuilder.setLength(switchBuilder.length() - 1);
        }
        editor.putString(_PREF_BB_, obfuscate(switchBuilder.toString()));


        StringBuilder textBuilder = new StringBuilder();
        textBuilder.append("弹窗版本=").append(_dialog_version_).append(",");
        textBuilder.append("莫奈主题颜色=").append(_monet_theme_color_).append(",");
        textBuilder.append("更新日志=").append(_upd_log_).append(",");
        textBuilder.append("更新日志英文=").append(_upd_log_eng_).append(",");
        textBuilder.append("强制更新内容=").append(_force_upd_content_).append(",");
        textBuilder.append("强制更新内容英文=").append(_force_upd_content_eng_).append(",");
        textBuilder.append("弹窗标题英文=").append(_popup_title_eng_).append(",");
        textBuilder.append("强制更新链接=").append(_force_upd_link_).append(",");
        textBuilder.append("远程通知内容=").append(_remote_notif_content_).append(",");
        textBuilder.append("设备码卡密链接=").append(_dev_id_card_link_).append(",");
        textBuilder.append("弹窗包名锁定内容=").append(_pkg_lock_content_).append(",");
        textBuilder.append("弹窗包名锁定链接=").append(_pkg_lock_link_).append(",");
        textBuilder.append("用户自定义配置URL列表=").append(_user_custom_urls_).append(",");
        textBuilder.append("配置加载超时时间=").append(_config_load_timeout_ms_).append(",");
        textBuilder.append("中立按钮内容=").append(_neutral_btn_content_);

        editor.putString(_PREF_CC_, obfuscate(textBuilder.toString()));

        editor.putBoolean(_PREF_I_, _enable_night_mode_);
        editor.putBoolean(_PREF_J_, _enable_monet_dyn_);
        editor.putBoolean(_PREF_K_, _enable_builtin_monet_);
        editor.putString(_PREF_L_, _monet_theme_color_);
        editor.putBoolean(_PREF_O_, _enable_dpi_auto_);
        editor.putBoolean(_PREF_R_, _enable_remote_notif_);
        editor.putString(_PREF_S_, _remote_notif_content_);

        editor.putString("cached_update_log_zh", _upd_log_);
        editor.putString("cached_update_log_en", _upd_log_eng_);
        editor.putString("cached_force_update_msg_zh", _force_upd_content_);
        editor.putString("cached_force_update_msg_en", _force_upd_content_eng_);

        editor.putBoolean(_PREF_DD_, _show_moonlight_icon_);
        editor.putBoolean(_PREF_EE_, _enable_dev_card_key_check_);
        editor.putBoolean(_PREF_FF_, _enable_countdown_dont_show_);
        editor.putBoolean(_PREF_Y_, _enable_dev_id_check_);
        editor.putString(_PREF_HH_, _pkg_lock_content_);
        editor.putString(_PREF_II_, _pkg_lock_link_);
        editor.putBoolean(_PREF_JJ_, _show_force_update_close_btn_);
        editor.putBoolean(_PREF_KK_, _show_package_lock_close_btn_);
        editor.putBoolean(_PREF_LL_, _force_use_domestic_url_);
        editor.putBoolean(_PREF_MM_, _force_use_international_url_);
        editor.putBoolean(_PREF_NN_, _enable_user_custom_url_);
        editor.putString(_PREF_OO_, _user_custom_urls_);
        editor.putLong(_PREF_QQ_, _config_load_timeout_ms_);
        editor.putBoolean(_PREF_RR_, _enable_config_syntax_check_);
        editor.putBoolean(_PREF_SS_, _enable_rich_device_info_collection_);
        editor.putBoolean(_PREF_NEW_DYNAMIC_TEXT_COLORS_, _enable_dynamic_text_colors_);
        editor.putBoolean(_PREF_NEUTRAL_BTN_SWITCH_, _show_neutral_btn_);
        editor.putString(_PREF_NEUTRAL_BTN_CONTENT_, _neutral_btn_content_);
        if (!_pkg_lock_map_.isEmpty()) {
            StringBuilder pkgLockMapString = new StringBuilder();
            for (Map.Entry<String, Boolean> entry : _pkg_lock_map_.entrySet()) {
                if (entry.getValue()) {
                    if (pkgLockMapString.length() > 0) pkgLockMapString.append(",");
                    pkgLockMapString.append(entry.getKey()).append("=锁");
                }
            }
            editor.putString(_PREF_GG_, obfuscate(pkgLockMapString.toString()));
        } else {
            editor.remove(_PREF_GG_);
        }

        // NEW: Save Package-specific main dialog visibility
        if (!_pkg_popup_control_.isEmpty()) {
            StringBuilder pkgPopupControlBuilder = new StringBuilder();
            List<String> sortedKeys = new ArrayList<>(_pkg_popup_control_.keySet());
            Collections.sort(sortedKeys);
            for (String key : sortedKeys) {
                if (pkgPopupControlBuilder.length() > 0) pkgPopupControlBuilder.append(",");
                pkgPopupControlBuilder.append(key).append("=").append(_pkg_popup_control_.get(key) ? "开" : "关");
            }
            editor.putString(_PREF_P_, obfuscate(pkgPopupControlBuilder.toString()));
        } else {
            editor.remove(_PREF_P_);
        }

        // NEW: Save Package-specific normal popup visibility
        if (!_normal_popup_control_.isEmpty()) {
            StringBuilder normalPopupControlBuilder = new StringBuilder();
            List<String> sortedKeys = new ArrayList<>(_normal_popup_control_.keySet());
            Collections.sort(sortedKeys);
            for (String key : sortedKeys) {
                if (normalPopupControlBuilder.length() > 0) normalPopupControlBuilder.append(",");
                normalPopupControlBuilder.append(key).append("=").append(_normal_popup_control_.get(key) ? "开" : "关");
            }
            editor.putString(_PREF_NEW_NORMAL_POPUP_CONTROL_, obfuscate(normalPopupControlBuilder.toString()));
        } else {
            editor.remove(_PREF_NEW_NORMAL_POPUP_CONTROL_);
        }
        
        // Save security configs
        editor.putString("moonlight_security_config", obfuscate(String.format(
                "XP=%s,抓包=%s,GG=%s,全局=%s,云注入=%s",
                _detect_xp_ ? "开" : "关",
                _detect_packet_sniffing_ ? "开" : "关",
                _detect_gg_ ? "开" : "关",
                _security_enabled_ ? "开" : "关",
                _cloud_inject_enabled_ ? "开" : "关"
        )));

        editor.apply();
    }

    @SuppressWarnings("deprecation")
    private static boolean verifyAppSignature(Activity activity) {
        if (!_enable_sig_ver_) return true;
        try {
            PackageInfo packageInfo = activity.getPackageManager().getPackageInfo(
                    activity.getPackageName(), PackageManager.GET_SIGNATURES);
            for (Signature signature : packageInfo.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA-1");
                md.update(signature.toByteArray());
                byte[] digest = md.digest();
                StringBuilder hexString = new StringBuilder();
                for (byte b : digest) {
                    hexString.append(String.format("%02X:", b));
                }
                String appSignature = hexString.substring(0, hexString.length() - 1);
                for (String expectedSignature : _sig_sha1_list_) {
                    if (expectedSignature.equalsIgnoreCase(appSignature)) {
                        return true;
                    }
                }
            }
        } catch (Exception e) {
            return false;
        }
        return false;
    }

    // --- [START] NEW DIALOG LAYOUT SECTION ---
    // This section contains the new, combined layout logic.
    private static void showSignatureFailureDialog(final Activity activity) {
        if (activity == null || activity.isFinishing() || (_s_main_dialog_ != null && _s_main_dialog_.isShowing())) {
            return;
        }
        if (_enable_bg_blur_) {
            applyBackgroundBlur(activity);
        }
        resolveColors(activity);
        boolean isChinese = isChinese(activity);
        AlertDialog.Builder builder = new AlertDialog.Builder(activity, android.R.style.Theme_DeviceDefault_Dialog);
        // --- Layout Logic ---
        DisplayMetrics displayMetrics = activity.getResources().getDisplayMetrics();
        float dpWidth = displayMetrics.widthPixels / displayMetrics.density;
        _is_large_screen_ = dpWidth >= 600;
        int orientation = activity.getResources().getConfiguration().orientation;
        boolean isLandscape = orientation == Configuration.ORIENTATION_LANDSCAPE;
        boolean useHorizontalLayout = _is_large_screen_ || isLandscape;

        ScrollView sv = new ScrollView(activity);
        LinearLayout rootLayout = new LinearLayout(activity);

        if (useHorizontalLayout) {
            // Landscape / Tablet Layout
            rootLayout.setOrientation(LinearLayout.HORIZONTAL);
            rootLayout.setPadding(40, 40, 40, 40);
            rootLayout.setGravity(Gravity.CENTER);

            LinearLayout leftContent = new LinearLayout(activity);
            leftContent.setOrientation(LinearLayout.VERTICAL);
            leftContent.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));
            if (_show_moonlight_icon_) {
                ImageView iv = new ImageView(activity);
                iv.setLayoutParams(new LinearLayout.LayoutParams(dpToPx_int(activity, 80), dpToPx_int(activity, 80)));
                setupMoonlightIcon(activity, iv);
                leftContent.addView(iv);
            }
            TextView title = new TextView(activity);
            title.setText(isChinese ? "签名验证失败" : "Signature Verification Failed");
            title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
            title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setTextColor(_current_text_color_);
            title.setPadding(0, 20, 0, 0);
            leftContent.addView(title);
            TextView content = new TextView(activity);
            content.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
            applyClickableLinks(activity, content, isChinese ? "应用签名验证失败，请下载官方正版！" : "App signature verification failed, please download the official version!");
            content.setTextColor(_current_text_color_);
            content.setPadding(0, 20, 0, 0);
            leftContent.addView(content);

            LinearLayout rightButtons = new LinearLayout(activity);
            rightButtons.setOrientation(LinearLayout.VERTICAL);
            rightButtons.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            rightButtons.setGravity(Gravity.CENTER);
            addButton(rightButtons, activity, isChinese ? "下载正版" : "Download Official", v -> {
                try {
                    String urlToOpen = convertToRawUrl(extractUrlFromHref(_force_upd_link_));
                    if (urlToOpen != null && !urlToOpen.isEmpty()) {
                        
                        activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(urlToOpen)));
                    } else {
                        showToast(activity, isChinese ? "更新链接未配置" : "Update link not configured");
                    }
                } catch (Exception e) {
    
                    showToast(activity, isChinese ? "打开链接失败" : "Failed to open link");
                }
            }, true);
            addButton(rightButtons, activity, isChinese ? "退出应用" : "Exit App", v -> {
                cleanupBeforeExit(activity);
                activity.finish();
            }, true);
            rootLayout.addView(leftContent);
            rootLayout.addView(rightButtons);
        } else {
            // Portrait Layout
            rootLayout.setOrientation(LinearLayout.VERTICAL);
            if (_show_moonlight_icon_) {
                ImageView iv = new ImageView(activity);
                LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(250, 250);
                ip.gravity = Gravity.CENTER_HORIZONTAL;
                ip.setMargins(0, 40, 0, 0);
                iv.setLayoutParams(ip);
                setupMoonlightIcon(activity, iv);
                rootLayout.addView(iv);
            }
            TextView title = new TextView(activity);
            title.setGravity(Gravity.CENTER);
            title.setText(isChinese ? "签名验证失败" : "Signature Verification Failed");
            title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setTextColor(_current_text_color_);
            title.setTextSize(25);
            rootLayout.addView(title);
            View spacer1 = new View(activity);
            spacer1.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, 80));
            rootLayout.addView(spacer1);
            TextView content = new TextView(activity);
            content.setTextSize(18);
            applyClickableLinks(activity, content, isChinese ? "应用签名验证失败，请下载官方正版！" : "App signature verification failed, please download the official version!");
            content.setTextColor(_current_text_color_);
            content.setPadding(100, 50, 100, 50);
            rootLayout.addView(content);
            addButton(rootLayout, activity, isChinese ? "下载正版" : "Download Official", v -> {
                try {
                    String urlToOpen = convertToRawUrl(extractUrlFromHref(_force_upd_link_));
                    if (urlToOpen != null && !urlToOpen.isEmpty()) {
                  
                        activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(urlToOpen)));
                    } else {
                        showToast(activity, isChinese ? "更新链接未配置" : "Update link not configured");
                    }
                } catch 
                        (Exception e) {
                    showToast(activity, isChinese ? "打开链接失败" : "Failed to open link");
                }
            }, false);
            addButton(rootLayout, activity, isChinese ? "退出应用" : "Exit App", v -> {
                cleanupBeforeExit(activity);
                activity.finish();
            }, false);
            View spacer2 = new View(activity);
            spacer2.setLayoutParams(new LinearLayout.LayoutParams(1, 40));
            rootLayout.addView(spacer2);
        }
        sv.addView(rootLayout);
        _s_main_dialog_ = builder.create();
        setupCommonDialogProperties(activity, _s_main_dialog_, sv, false);
    }

    private static void showDeviceIdRestrictedDialog(final Activity activity) {
        if (activity == null || activity.isFinishing() || (_s_main_dialog_ != null && _s_main_dialog_.isShowing())) {
            return;
        }
        if (_enable_bg_blur_) {
            applyBackgroundBlur(activity);
        }
        resolveColors(activity);
        boolean isChinese = isChinese(activity);
        final String deviceId = getDeviceId(activity);
        AlertDialog.Builder builder = new AlertDialog.Builder(activity, android.R.style.Theme_DeviceDefault_Dialog);

        DisplayMetrics displayMetrics = activity.getResources().getDisplayMetrics();
        float dpWidth = displayMetrics.widthPixels / displayMetrics.density;
        _is_large_screen_ = dpWidth >= 600;
        int orientation = activity.getResources().getConfiguration().orientation;
        boolean isLandscape = orientation == Configuration.ORIENTATION_LANDSCAPE;
        boolean useHorizontalLayout = _is_large_screen_ ||
                isLandscape;

        ScrollView sv = new ScrollView(activity);
        LinearLayout rootLayout = new LinearLayout(activity);
        if (useHorizontalLayout) {
            rootLayout.setOrientation(LinearLayout.HORIZONTAL);
            rootLayout.setPadding(40, 40, 40, 40);
            rootLayout.setGravity(Gravity.CENTER);
            LinearLayout leftContent = new LinearLayout(activity);
            leftContent.setOrientation(LinearLayout.VERTICAL);
            leftContent.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));
            if (_show_moonlight_icon_) {
                ImageView iv = new ImageView(activity);
                iv.setLayoutParams(new LinearLayout.LayoutParams(dpToPx_int(activity, 80), dpToPx_int(activity, 80)));
                setupMoonlightIcon(activity, iv);
                leftContent.addView(iv);
            }
            TextView title = new TextView(activity);
            title.setText(isChinese ? "设备限制" : "Device Restricted");
            title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
            title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setTextColor(_current_text_color_);
            title.setPadding(0, 20, 0, 0);
            leftContent.addView(title);
            TextView content = new TextView(activity);
            content.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
            applyClickableLinks(activity, content, isChinese ? "您的设备码: " + deviceId + "\n该设备未被授权使用此应用。" : "Your Device ID: " + deviceId + "\nThis device is not authorized to use this application.");
            content.setTextColor(_current_text_color_);
            content.setPadding(0, 20, 0, 0);
            leftContent.addView(content);
            _dev_id_timer_text_ = new TextView(activity);
            _dev_id_timer_text_.setTextSize(14);
            _dev_id_timer_text_.setTextColor(Color.RED);
            _dev_id_timer_text_.setPadding(0, 10, 0, 0);
            leftContent.addView(_dev_id_timer_text_);
            LinearLayout rightButtons = new LinearLayout(activity);
            rightButtons.setOrientation(LinearLayout.VERTICAL);
            rightButtons.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            rightButtons.setGravity(Gravity.CENTER);
            addButton(rightButtons, activity, isChinese ? "复制设备码" : "Copy Device ID", v -> {
                ClipboardManager clipboard = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("Device ID", deviceId);
                clipboard.setPrimaryClip(clip);
                showToast(activity, isChinese ? "设备码已复制" : "Device ID copied to clipboard");
       
            }, true);
            addButton(rightButtons, activity, isChinese ? "获取卡密/联系管理员" : "Get Key/Contact Admin", v -> {
                try {
                    String urlToOpen = _dev_id_card_link_;
                    if (urlToOpen == null || urlToOpen.isEmpty()) urlToOpen = _force_upd_link_;
              
                    if (urlToOpen == null || urlToOpen.isEmpty()) urlToOpen = _tg_channel_link_;
                    if (urlToOpen != null && !urlToOpen.isEmpty()) {
                        activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(convertToRawUrl(extractUrlFromHref(urlToOpen)))));
                    } else {
            
                        showToast(activity, isChinese ? "联系链接未配置" : "Contact link not configured");
                    }
                } catch (Exception e) {
                    showToast(activity, isChinese ? "打开链接失败" : "Failed to open link");
            
                }
            }, true);
            addButton(rightButtons, activity, isChinese ? "退出应用" : "Exit App", v -> {
                cleanupBeforeExit(activity);
                activity.finish();
            }, true);
            rootLayout.addView(leftContent);
            rootLayout.addView(rightButtons);
        } else {
            rootLayout.setOrientation(LinearLayout.VERTICAL);
            if (_show_moonlight_icon_) {
                ImageView iv = new ImageView(activity);
                LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(250, 250);
                ip.gravity = Gravity.CENTER_HORIZONTAL;
                ip.setMargins(0, 40, 0, 0);
                iv.setLayoutParams(ip);
                setupMoonlightIcon(activity, iv);
                rootLayout.addView(iv);
            }
            TextView title = new TextView(activity);
            title.setGravity(Gravity.CENTER);
            title.setText(isChinese ? "设备限制" : "Device Restricted");
            title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setTextColor(_current_text_color_);
            title.setTextSize(25);
            rootLayout.addView(title);
            View spacer1 = new View(activity);
            spacer1.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, 80));
            rootLayout.addView(spacer1);
            TextView content = new TextView(activity);
            content.setTextSize(18);
            applyClickableLinks(activity, content, isChinese ? "您的设备码: " + deviceId + "\n该设备未被授权使用此应用。" : "Your Device ID: " + deviceId + "\nThis device is not authorized to use this application.");
            content.setTextColor(_current_text_color_);
            content.setPadding(100, 0, 100, 50);
            rootLayout.addView(content);
            _dev_id_timer_text_ = new TextView(activity);
            _dev_id_timer_text_.setTextSize(16);
            _dev_id_timer_text_.setTextColor(Color.RED);
            _dev_id_timer_text_.setGravity(Gravity.CENTER);
            _dev_id_timer_text_.setPadding(100, dpToPx_int(activity, 10), 100, dpToPx_int(activity, 20));
            rootLayout.addView(_dev_id_timer_text_);
            addButton(rootLayout, activity, isChinese ? "复制设备码" : "Copy Device ID", v -> {
                ClipboardManager clipboard = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("Device ID", deviceId);
                clipboard.setPrimaryClip(clip);
                showToast(activity, isChinese ? "设备码已复制" : "Device ID copied to clipboard");
       
            }, false);
            addButton(rootLayout, activity, isChinese ? "获取卡密/联系管理员" : "Get Key/Contact Admin", v -> {
                try {
                    String urlToOpen = _dev_id_card_link_;
                    if (urlToOpen == null || urlToOpen.isEmpty()) urlToOpen = _force_upd_link_;
              
                    if (urlToOpen == null || urlToOpen.isEmpty()) urlToOpen = _tg_channel_link_;
                    if (urlToOpen != null && !urlToOpen.isEmpty()) {
                        activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(convertToRawUrl(extractUrlFromHref(urlToOpen)))));
                    } else {
            
                        showToast(activity, isChinese ? "联系链接未配置" : "Contact link not configured");
                    }
                } catch (Exception e) {
                    showToast(activity, isChinese ? "打开链接失败" : "Failed to open link");
            
                }
            }, false);
            addButton(rootLayout, activity, isChinese ? "退出应用" : "Exit App", v -> {
                cleanupBeforeExit(activity);
                activity.finish();
            }, false);
            View spacer2 = new View(activity);
            spacer2.setLayoutParams(new LinearLayout.LayoutParams(1, 40));
            rootLayout.addView(spacer2);
        }
        sv.addView(rootLayout);
        _s_main_dialog_ = builder.create();
        _s_main_dialog_.setOnDismissListener(dialogInterface -> {
            removeBackgroundBlur(activity);
            _s_activity_ref_ = null;
            _s_main_dialog_ = null;
            if (_dev_id_timer_ != null) {
                _dev_id_timer_.cancel();
                _dev_id_timer_ = null;
     
            }
        });

        setupCommonDialogProperties(activity, _s_main_dialog_, sv, false);
        startDeviceIdCountdown(activity, _dev_id_timer_text_);
    }

    private static void showCardKeyInputDialog(final Activity activity) {
        if (activity == null || activity.isFinishing() || (_s_main_dialog_ != null && _s_main_dialog_.isShowing())) {
            return;
        }
        if (_enable_bg_blur_) {
            applyBackgroundBlur(activity);
        }
        resolveColors(activity);
        final boolean isChinese = isChinese(activity);
        final String currentDeviceId = getDeviceId(activity);
        AlertDialog.Builder builder = new AlertDialog.Builder(activity, android.R.style.Theme_DeviceDefault_Dialog);

        DisplayMetrics displayMetrics = activity.getResources().getDisplayMetrics();
        float dpWidth = displayMetrics.widthPixels / displayMetrics.density;
        _is_large_screen_ = dpWidth >= 600;
        int orientation = activity.getResources().getConfiguration().orientation;
        boolean isLandscape = orientation == Configuration.ORIENTATION_LANDSCAPE;
        boolean useHorizontalLayout = _is_large_screen_ ||
                isLandscape;

        ScrollView sv = new ScrollView(activity);
        LinearLayout rootLayout = new LinearLayout(activity);
        final EditText cardKeyInput = new EditText(activity);
        final TextView cardKeyCountdownLocalTextView = new TextView(activity);

        if (useHorizontalLayout) {
            rootLayout.setOrientation(LinearLayout.HORIZONTAL);
            rootLayout.setPadding(40, 40, 40, 40);
            rootLayout.setGravity(Gravity.CENTER);

            LinearLayout leftContent = new LinearLayout(activity);
            leftContent.setOrientation(LinearLayout.VERTICAL);
            leftContent.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));
            if (_show_moonlight_icon_) {
                ImageView iv = new ImageView(activity);
                iv.setLayoutParams(new LinearLayout.LayoutParams(dpToPx_int(activity, 80), dpToPx_int(activity, 80)));
                setupMoonlightIcon(activity, iv);
                leftContent.addView(iv);
            }
            TextView title = new TextView(activity);
            title.setText(isChinese ? "卡密验证" : "Card Key Validation");
            title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
            title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setTextColor(_current_text_color_);
            title.setPadding(0, 20, 0, 0);
            leftContent.addView(title);
            TextView deviceIdTextView = new TextView(activity);
            deviceIdTextView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
            applyClickableLinks(activity, deviceIdTextView, isChinese ? "您的设备码: " + currentDeviceId : "Your Device ID: " + currentDeviceId);
            deviceIdTextView.setTextColor(_current_text_color_);
            deviceIdTextView.setPadding(0, 20, 0, 0);
            leftContent.addView(deviceIdTextView);
            cardKeyCountdownLocalTextView.setTextSize(14);
            cardKeyCountdownLocalTextView.setTextColor(Color.RED);
            cardKeyCountdownLocalTextView.setPadding(0, 10, 0, 0);
            leftContent.addView(cardKeyCountdownLocalTextView);
            LinearLayout.LayoutParams etParams = new LinearLayout.LayoutParams(-1, -2);
            etParams.setMargins(0, 10, 20, 10);
            cardKeyInput.setLayoutParams(etParams);
            cardKeyInput.setHint(isChinese ? "请输入卡密" : "Enter Card Key");
            cardKeyInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
            setupEditTextStyle(activity, cardKeyInput);
            leftContent.addView(cardKeyInput);
            LinearLayout rightButtons = new LinearLayout(activity);
            rightButtons.setOrientation(LinearLayout.VERTICAL);
            rightButtons.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            rightButtons.setGravity(Gravity.CENTER);
            addButton(rightButtons, activity, isChinese ? "验证卡密" : "Validate Card Key", v -> validateCardKey(activity, cardKeyInput), true);
            addButton(rightButtons, activity, isChinese ? "复制设备码" : "Copy Device ID", v -> copyDeviceId(activity, currentDeviceId), true);
            addButton(rightButtons, activity, isChinese ? "获取卡密/联系管理员" : "Get Key/Contact Admin", v -> getCardKey(activity), true);
            addButton(rightButtons, activity, isChinese ? "退出应用" : "Exit App", v -> {
                cleanupBeforeExit(activity);
                activity.finish();
            }, true);
            rootLayout.addView(leftContent);
            rootLayout.addView(rightButtons);
        } else {
            rootLayout.setOrientation(LinearLayout.VERTICAL);
            if (_show_moonlight_icon_) {
                ImageView iv = new ImageView(activity);
                LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(250, 250);
                ip.gravity = Gravity.CENTER_HORIZONTAL;
                ip.setMargins(0, 40, 0, 0);
                iv.setLayoutParams(ip);
                setupMoonlightIcon(activity, iv);
                rootLayout.addView(iv);
            }
            TextView title = new TextView(activity);
            title.setGravity(Gravity.CENTER);
            title.setText(isChinese ? "卡密验证" : "Card Key Validation");
            title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setTextColor(_current_text_color_);
            title.setTextSize(25);
            rootLayout.addView(title);
            View spacer1 = new View(activity);
            spacer1.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, 80));
            rootLayout.addView(spacer1);
            TextView deviceIdTextView = new TextView(activity);
            deviceIdTextView.setTextSize(18);
            applyClickableLinks(activity, deviceIdTextView, isChinese ? "您的设备码: " + currentDeviceId : "Your Device ID: " + currentDeviceId);
            deviceIdTextView.setTextColor(_current_text_color_);
            deviceIdTextView.setPadding(100, 0, 100, 50);
            rootLayout.addView(deviceIdTextView);
            cardKeyCountdownLocalTextView.setTextSize(16);
            cardKeyCountdownLocalTextView.setTextColor(Color.RED);
            cardKeyCountdownLocalTextView.setGravity(Gravity.CENTER);
            cardKeyCountdownLocalTextView.setPadding(100, dpToPx_int(activity, 10), 100, dpToPx_int(activity, 20));
            rootLayout.addView(cardKeyCountdownLocalTextView);
            LinearLayout.LayoutParams etParams = new LinearLayout.LayoutParams(-1, -2);
            etParams.setMargins(90, 10, 90, 10);
            cardKeyInput.setLayoutParams(etParams);
            cardKeyInput.setHint(isChinese ? "请输入卡密" : "Enter Card Key");
            cardKeyInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
            setupEditTextStyle(activity, cardKeyInput);
            rootLayout.addView(cardKeyInput);
            addButton(rootLayout, activity, isChinese ? "验证卡密" : "Validate Card Key", v -> validateCardKey(activity, cardKeyInput), false);
            addButton(rootLayout, activity, isChinese ? "复制设备码" : "Copy Device ID", v -> copyDeviceId(activity, currentDeviceId), false);
            addButton(rootLayout, activity, isChinese ? "获取卡密/联系管理员" : "Get Key/Contact Admin", v -> getCardKey(activity), false);
            addButton(rootLayout, activity, isChinese ? "退出应用" : "Exit App", v -> {
                cleanupBeforeExit(activity);
                activity.finish();
            }, false);
            View spacer2 = new View(activity);
            spacer2.setLayoutParams(new LinearLayout.LayoutParams(1, 40));
            rootLayout.addView(spacer2);
        }

        sv.addView(rootLayout);
        _s_main_dialog_ = builder.create();
        _s_main_dialog_.setOnDismissListener(dialogInterface -> {
            removeBackgroundBlur(activity);
            _s_activity_ref_ = null;
            _s_main_dialog_ = null;
            if (_card_key_timer_ != null) {
                _card_key_timer_.cancel();
                _card_key_timer_ = null;
     
            }
        });

        setupCommonDialogProperties(activity, _s_main_dialog_, sv, false);
        startCardKeyCountdownTimer(activity, cardKeyCountdownLocalTextView, _s_main_dialog_);
    }

    private static void validateCardKey(Activity activity, EditText cardKeyInput) {
        String enteredCardKey = cardKeyInput.getText().toString().trim();
        String currentDeviceId = getDeviceId(activity);
        boolean isKeyValid = false;
        if (_dev_card_keys_.containsKey(currentDeviceId)) {
            String expectedKeyForDevice = _dev_card_keys_.get(currentDeviceId);
            if (expectedKeyForDevice != null && expectedKeyForDevice.equals(enteredCardKey)) {
                isKeyValid = true;
            }
        } else {
            if (_dev_card_keys_.containsValue(enteredCardKey)) {
                isKeyValid = true;
            }
        }
        if (isKeyValid) {
            if (_card_key_timer_ != null) {
                _card_key_timer_.cancel();
                _card_key_timer_ = null;
            }
            showToast(activity, isChinese(activity) ? "卡密验证成功！" : "Card key validation successful!");
            getSharedPreferences(activity).edit().putBoolean(_PREF_X_ + currentDeviceId, true).apply();
            _s_main_dialog_.dismiss();
            performHighestPriorityChecks(activity);
        } else {
            showToast(activity, isChinese(activity) ? "卡密错误，请重试！" : "Incorrect card key, please try again!");
        }
    }

    private static void copyDeviceId(Activity activity, String deviceId) {
        ClipboardManager clipboard = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("Device ID", deviceId));
        showToast(activity, isChinese(activity) ? "设备码已复制" : "Device ID copied to clipboard");
    }

    private static void getCardKey(Activity activity) {
        try {
            String urlToOpen = _dev_id_card_link_;
            if (urlToOpen == null || urlToOpen.isEmpty()) urlToOpen = _force_upd_link_;
            if (urlToOpen == null || urlToOpen.isEmpty()) urlToOpen = _tg_channel_link_;
            if (urlToOpen != null && !urlToOpen.isEmpty()) {
                activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(convertToRawUrl(extractUrlFromHref(urlToOpen)))));
            } else {
                showToast(activity, isChinese(activity) ? "联系链接未配置" : "Contact link not configured");
            }
        } catch (Exception e) {
            showToast(activity, isChinese(activity) ? "打开链接失败" : "Failed to open link");
        }
    }


    private static void startCardKeyCountdownTimer(final Activity activity, final TextView countdownTextView, final AlertDialog dialog) {
        if (_card_key_timer_ != null) {
            _card_key_timer_.cancel();
        }

        _card_key_timer_ = new CountDownTimer(_CARD_KEY_CD_, 1000) {
            public void onTick(long millisUntilFinished) {
                int seconds = (int) (millisUntilFinished / 1000);
                countdownTextView.setText(isChinese(activity) ? "崩溃倒计时: " + seconds + " 秒" : "Crash Countdown: " + seconds + " seconds");
            }

            public void onFinish() {
                if (dialog != null && dialog.isShowing()) {
                    dialog.dismiss();
                }
                cleanupBeforeExit(activity);
                activity.runOnUiThread(() -> {
                    Toast.makeText(activity, isChinese(activity) ? "未激活卡密，应用即将退出！" : "Card key not activated, app will exit!", Toast.LENGTH_LONG).show();
                    new Handler(Looper.getMainLooper()).postDelayed(() -> {
                        throw new RuntimeException("Card key not activated, app crash initiated.");
           
                    }, 1000);
                });
            }
        }.start();
    }

    private static void startDeviceIdCountdown(final Activity activity, final TextView countdownTextView) {
        if (_dev_id_timer_ != null) {
            _dev_id_timer_.cancel();
        }

        _dev_id_timer_ = new CountDownTimer(_DEV_ID_CRASH_CD_ * 1000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                int seconds = (int) (millisUntilFinished / 1000);
                if (countdownTextView != null) {
                    countdownTextView.setText(isChinese(activity) ? "应用将在 " + seconds + " 秒后关闭" : "App will close in " + seconds + " seconds");
                }
            }

            @Override
            public void onFinish() {
                if (countdownTextView != null) {
                    countdownTextView.setText(isChinese(activity) ? "应用即将关闭..." : "App is closing...");
                }
                cleanupBeforeExit(activity);
                activity.finish();
                throw new RuntimeException("Device verification failed, app closed.");
            }
        }.start();
    }


    private static String extractUrlFromHref(String input) {
        if (input == null || input.isEmpty()) return "";
        if (input.contains("href=\"")) {
            int start = input.indexOf("href=\"") + 6;
            int end = input.indexOf("\"", start);
            if (end > start) return input.substring(start, end);
        }
        return input;
    }

    private static String convertToRawUrl(String url) {
        if (url == null || url.isEmpty()) return url;
        if (url.contains("gitee.com") && url.contains("/blob/")) return url.replace("/blob/", "/raw/");
        if (url.contains("github.com") && url.contains("/blob/"))
        
                return url.replace("github.com", "raw.githubusercontent.com").replace("/blob/", "/");
        if (url.contains("gitcode.com") && url.contains("/blob/")) return url.replace("/blob/", "/raw/");
        if (url.contains("gitcode.net") && url.contains("/blob/")) return url.replace("/blob/", "/raw/");
        if (url.contains("share.weiyun.com") && !url.endsWith(".txt")) return url + "&raw=1";
        return url;
    }

    private static int getScreenWidth(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            return activity.getWindowManager().getCurrentWindowMetrics().getBounds().width();
        } else {
            DisplayMetrics dm = new DisplayMetrics();
            activity.getWindowManager().getDefaultDisplay().getMetrics(dm);
            return dm.widthPixels;
        }
    }

    private static void originalPopupLogic(final Activity activity) {
        if (activity == null || activity.isFinishing()) {
            _s_activity_ref_ = null;
            return;
        }

        if (_s_main_dialog_ != null && _s_main_dialog_.isShowing()) {
            return;
        }

        String currentPackageName = activity.getPackageName();
        if (_normal_popup_control_.containsKey(currentPackageName) && !_normal_popup_control_.get(currentPackageName)) {
            _s_activity_ref_ = null;
            return;
        }


        final SharedPreferences prefs = getSharedPreferences(activity);
        try {
            String storedVersion = prefs.getString("dialogVer", "default");
            if (prefs.getBoolean("0", false) && !_reset_dont_show_ && storedVersion.equals(_cfg_version_)) {
                _s_activity_ref_ = null;
                return;
            }
            if (prefs.getBoolean("0", false) && !storedVersion.equals(_cfg_version_)) {
                prefs.edit().remove("0").apply();
            }
        } catch (Exception e) {
        }
        createDialog(activity, prefs);
    }

    private static void createDialog(final Activity activity, final SharedPreferences prefs) {
        if (activity == null || activity.isFinishing()) {
            _s_activity_ref_ = null;
            return;
        }
        if (_s_main_dialog_ != null && _s_main_dialog_.isShowing()) {
            return;
        }
        if (_enable_bg_blur_) {
            applyBackgroundBlur(activity);
        }
        resolveColors(activity);
        if (_dialog_version_ == 2) {
            createDialogStyle2(activity, prefs);
        } else {
            createDialogStyle1(activity, prefs);
        }
    }

    // --- Dialog Style 1 (Simple Layout) ---
    private static void createDialogStyle1(final Activity activity, final SharedPreferences prefs) {
        final boolean isChinese = isChinese(activity);
        AlertDialog.Builder builder = new AlertDialog.Builder(activity, android.R.style.Theme_DeviceDefault_Dialog);

        DisplayMetrics displayMetrics = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        float dpWidth = displayMetrics.widthPixels / displayMetrics.density;
        _is_large_screen_ = dpWidth >= 600;

        int orientation = activity.getResources().getConfiguration().orientation;
        boolean isLandscape = orientation == Configuration.ORIENTATION_LANDSCAPE;
        boolean useHorizontalLayout = _is_large_screen_ ||
                isLandscape;

        ScrollView sv = new ScrollView(activity);
        LinearLayout rootLayout = new LinearLayout(activity);
        if (useHorizontalLayout) {
            // ===== Landscape / Tablet Layout =====
            rootLayout.setOrientation(LinearLayout.HORIZONTAL);
            rootLayout.setPadding(40, 40, 40, 40);
            rootLayout.setGravity(Gravity.CENTER);

            // Left side
            LinearLayout leftContent = new LinearLayout(activity);
            leftContent.setOrientation(LinearLayout.VERTICAL);
            leftContent.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));

            LinearLayout imageTitleContainer = new LinearLayout(activity);
            imageTitleContainer.setOrientation(LinearLayout.HORIZONTAL);
            imageTitleContainer.setGravity(Gravity.CENTER_VERTICAL);
            if (_show_moonlight_icon_) {
                ImageView iv = new ImageView(activity);
                iv.setLayoutParams(new LinearLayout.LayoutParams(dpToPx_int(activity, 80), dpToPx_int(activity, 80)));
                setupMoonlightIcon(activity, iv);
                imageTitleContainer.addView(iv);
            }

            TextView title = new TextView(activity);
            title.setText(isChinese ? _popup_title_ : _popup_title_eng_);
            title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
            title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setTextColor(_current_text_color_);
            title.setPadding(20, 0, 0, 0);
            imageTitleContainer.addView(title);
            leftContent.addView(imageTitleContainer);

            TextView content = new TextView(activity);
            content.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
            applyClickableLinks(activity, content, _show_dyn_content_ ? (isChinese ? _dyn_content_ : _eng_content_) : (isChinese ? "欢迎使用" : "Welcome"));
            content.setTextColor(_current_text_color_);
            content.setPadding(0, 20, 0, 0);
            leftContent.addView(content);

            // Right side
            LinearLayout rightButtons = new LinearLayout(activity);
            rightButtons.setOrientation(LinearLayout.VERTICAL);
            rightButtons.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            rightButtons.setGravity(Gravity.CENTER);

            if (_show_close_btn_) addButtonStyle1(rightButtons, activity, isChinese ? "关闭弹窗" : "Close", v -> { if (_s_main_dialog_ != null) animateDialogDismiss(_s_main_dialog_); }, true);
            if (_show_tg_btn_) addButtonStyle1(rightButtons, activity, isChinese ? "加入TG频道" : "Join Telegram", v -> openTelegram(activity), true);
            if (_show_qq_btn_) addButtonStyle1(rightButtons, activity, isChinese ? "加入QQ群" : "Join QQ Group", v -> openQQGroup(activity), true);
            if (_show_dont_show_btn_) addButtonStyle1(rightButtons, activity, isChinese ? "不再提示" : "Don't Show Again", v -> showDontShowAgainDialog(activity, prefs), true);

            rootLayout.addView(leftContent);
            rootLayout.addView(rightButtons);
        } else {
            // ===== Portrait Layout =====
            rootLayout.setOrientation(LinearLayout.VERTICAL);
            if (_show_moonlight_icon_) {
                ImageView iv = new ImageView(activity);
                LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(250, 250);
                ip.gravity = Gravity.CENTER_HORIZONTAL;
                ip.setMargins(0, 40, 0, 0);
                iv.setLayoutParams(ip);
                setupMoonlightIcon(activity, iv);
                rootLayout.addView(iv);
            }

            TextView title = new TextView(activity);
            title.setGravity(Gravity.CENTER);
            title.setText(isChinese ? _popup_title_ : _popup_title_eng_);
            title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setTextColor(_current_text_color_);
            title.setTextSize(25);
            rootLayout.addView(title);

            View spacer1 = new View(activity);
            spacer1.setLayoutParams(new LinearLayout.LayoutParams(-2, 80));
            rootLayout.addView(spacer1);
            TextView content = new TextView(activity);
            content.setTextSize(18);
            applyClickableLinks(activity, content, _show_dyn_content_ ? (isChinese ? _dyn_content_ : _eng_content_) : (isChinese ? "欢迎使用" : "Welcome"));
            content.setTextColor(_current_text_color_);
            content.setPadding(100, 50, 100, 50);
            rootLayout.addView(content);

            if (_show_close_btn_) addButtonStyle1(rootLayout, activity, isChinese ? "关闭弹窗" : "Close", v -> { if (_s_main_dialog_ != null) animateDialogDismiss(_s_main_dialog_); }, false);
            if (_show_tg_btn_) addButtonStyle1(rootLayout, activity, isChinese ? "加入TG频道" : "Join Telegram", v -> openTelegram(activity), false);
            if (_show_qq_btn_) addButtonStyle1(rootLayout, activity, isChinese ? "加入QQ群" : "Join QQ Group", v -> openQQGroup(activity), false);
            if (_show_dont_show_btn_) addButtonStyle1(rootLayout, activity, isChinese ? "不再提示" : "Don't Show Again", v -> showDontShowAgainDialog(activity, prefs), false);
            View spacer2 = new View(activity);
            spacer2.setLayoutParams(new LinearLayout.LayoutParams(1, 40));
            rootLayout.addView(spacer2);
        }

        sv.addView(rootLayout);
        _s_main_dialog_ = builder.create();
        setupCommonDialogProperties(activity, _s_main_dialog_, sv, _enable_out_click_);
    }

    private static void addButtonStyle1(LinearLayout layout, Activity activity, String text, View.OnClickListener listener, boolean compactLayout) {
        LinearLayout.LayoutParams lp;
        if (compactLayout) {
            lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(20, 10, 20, 10);
        } else {
            lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(90, 10, 90, 10);
        }
        Button button = new Button(activity);
        button.setLayoutParams(lp);
        button.setText(text);
        button.setTextColor(_current_button_text_);
        button.setBackground(createButtonBackground(_current_button_bg_));
        if (compactLayout) {
            button.setMinWidth(dpToPx_int(activity, 120));
        }
        button.setOnClickListener(v -> animateButtonPress(v, () -> listener.onClick(v)));
        layout.addView(button);
    }

    // --- Dialog Style 2 (Themed Material Layout) ---
    private static void createDialogStyle2(final Activity activity, final SharedPreferences prefs) {
        final boolean isChinese = isChinese(activity);
        AlertDialog.Builder builder = new AlertDialog.Builder(activity, android.R.style.Theme_DeviceDefault_Dialog);

        DisplayMetrics displayMetrics = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        float dpWidth = displayMetrics.widthPixels / displayMetrics.density;
        _is_large_screen_ = dpWidth >= 600;

        int orientation = activity.getResources().getConfiguration().orientation;
        boolean isLandscape = orientation == Configuration.ORIENTATION_LANDSCAPE;
        boolean useHorizontalLayout = _is_large_screen_ ||
                isLandscape;

        ScrollView sv = new ScrollView(activity);
        LinearLayout rootLayout = new LinearLayout(activity);
        if (useHorizontalLayout) {
            // ===== Landscape / Tablet Layout (Style 2) =====
            rootLayout.setOrientation(LinearLayout.HORIZONTAL);
            rootLayout.setPadding(40, 40, 40, 40);
            rootLayout.setGravity(Gravity.CENTER);

            // Left side
            LinearLayout leftContent = new LinearLayout(activity);
            leftContent.setOrientation(LinearLayout.VERTICAL);
            leftContent.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));

            LinearLayout imageTitleContainer = new LinearLayout(activity);
            imageTitleContainer.setOrientation(LinearLayout.HORIZONTAL);
            imageTitleContainer.setGravity(Gravity.CENTER_VERTICAL);
            if (_show_moonlight_icon_) {
                ImageView iv = new ImageView(activity);
                iv.setLayoutParams(new LinearLayout.LayoutParams(dpToPx_int(activity, 80), dpToPx_int(activity, 80)));
                setupMoonlightIcon(activity, iv);
                imageTitleContainer.addView(iv);
            }

            TextView title = new TextView(activity);
            title.setText(isChinese ? _popup_title_ : _popup_title_eng_);
            title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
            title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setTextColor(_current_text_color_);
            title.setPadding(20, 0, 0, 0);
            imageTitleContainer.addView(title);
            leftContent.addView(imageTitleContainer);

            TextView content = new TextView(activity);
            content.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
            applyClickableLinks(activity, content, _show_dyn_content_ ? (isChinese ? _dyn_content_ : _eng_content_) : (isChinese ? "欢迎使用" : "Welcome"));
            content.setTextColor(_current_text_color_);
            content.setPadding(0, 20, 0, 0);
            leftContent.addView(content);

            // Right side
            LinearLayout rightButtons = new LinearLayout(activity);
            rightButtons.setOrientation(LinearLayout.VERTICAL);
            rightButtons.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            rightButtons.setGravity(Gravity.CENTER);

            if (_show_close_btn_) addButtonStyle2(rightButtons, activity, isChinese ? "关闭弹窗" : "Close", v -> { if (_s_main_dialog_ != null) animateDialogDismiss(_s_main_dialog_); }, true);
            if (_show_tg_btn_) addButtonStyle2(rightButtons, activity, isChinese ? "加入TG频道" : "Join Telegram", v -> openTelegram(activity), true);
            if (_show_qq_btn_) addButtonStyle2(rightButtons, activity, isChinese ? "加入QQ群" : "Join QQ Group", v -> openQQGroup(activity), true);
            if (_show_dont_show_btn_) addButtonStyle2(rightButtons, activity, isChinese ? "不再提示" : "Don't Show Again", v -> showDontShowAgainDialog(activity, prefs), true);

            rootLayout.addView(leftContent);
            rootLayout.addView(rightButtons);
        } else {
            // ===== Portrait Layout (Original Style 2) =====
            rootLayout.setOrientation(LinearLayout.VERTICAL);
            if (_show_moonlight_icon_) {
                ImageView iv = new ImageView(activity);
                LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(250, 250);
                ip.gravity = Gravity.CENTER_HORIZONTAL;
                ip.setMargins(0, 40, 0, 0);
                iv.setLayoutParams(ip);
                setupMoonlightIcon(activity, iv);
                rootLayout.addView(iv);
            }

            TextView title = new TextView(activity);
            title.setGravity(Gravity.CENTER);
            title.setText(isChinese ? _popup_title_ : _popup_title_eng_);
            title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setTextColor(_current_text_color_);
            title.setTextSize(25);
            rootLayout.addView(title);

            View spacer1 = new View(activity);
            spacer1.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, 80));
            rootLayout.addView(spacer1);
            TextView content = new TextView(activity);
            content.setTextSize(18);
            applyClickableLinks(activity, content, _show_dyn_content_ ? (isChinese ? _dyn_content_ : _eng_content_) : (isChinese ? "欢迎使用" : "Welcome"));
            content.setTextColor(_current_text_color_);
            content.setPadding(100, 50, 100, 50);
            rootLayout.addView(content);

            if (_show_close_btn_) addButtonStyle2(rootLayout, activity, isChinese ? "关闭弹窗" : "Close", v -> { if (_s_main_dialog_ != null) animateDialogDismiss(_s_main_dialog_); }, false);
            if (_show_tg_btn_) addButtonStyle2(rootLayout, activity, isChinese ? "加入TG频道" : "Join Telegram", v -> openTelegram(activity), false);
            if (_show_qq_btn_) addButtonStyle2(rootLayout, activity, isChinese ? "加入QQ群" : "Join QQ Group", v -> openQQGroup(activity), false);
            if (_show_dont_show_btn_) addButtonStyle2(rootLayout, activity, isChinese ? "不再提示" : "Don't Show Again", v -> showDontShowAgainDialog(activity, prefs), false);
            View spacer2 = new View(activity);
            spacer2.setLayoutParams(new LinearLayout.LayoutParams(1, 80));
            rootLayout.addView(spacer2);
        }

        sv.addView(rootLayout);
        _s_main_dialog_ = builder.create();
        setupCommonDialogProperties(activity, _s_main_dialog_, sv, _enable_out_click_);
    }

    private static void addButtonStyle2(LinearLayout layout, Activity activity, String text, View.OnClickListener listener, boolean compactLayout) {
        LinearLayout.LayoutParams lp;
        if (compactLayout) {
            lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(20, 5, 20, 5);
        } else {
            lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.gravity = Gravity.CENTER;
            lp.setMargins(90, 0, 90, 10);
        }

        Button button = new Button(activity);
        button.setLayoutParams(lp);
        button.setText(text);
        button.setTextColor(_current_button_text_);
        button.setBackground(createButtonBackground(_current_button_bg_));
        if (compactLayout) {
            button.setMinWidth(dpToPx_int(activity, 120));
        }
        button.setOnClickListener(v -> animateButtonPress(v, () -> listener.onClick(v)));
        layout.addView(button);
    }

    private static void addButton(LinearLayout layout, Activity activity, String text, View.OnClickListener listener, boolean compactLayout) {
        if (_dialog_version_ == 2) {
            addButtonStyle2(layout, activity, text, listener, compactLayout);
        } else {
            addButtonStyle1(layout, activity, text, listener, compactLayout);
        }
    }


    private static void setupCommonDialogProperties(Activity activity, AlertDialog dialog, View view, boolean isCancelable) {
        dialog.setCancelable(isCancelable);
        dialog.setView(view);
        dialog.setOnDismissListener(d -> {
            removeBackgroundBlur(activity);
            _s_activity_ref_ = null;
            _s_main_dialog_ = null;
        });
        GradientDrawable gd = new GradientDrawable();
        gd.setCornerRadius(dpToPx(activity, 16));
        gd.setColor(_current_dialog_bg_);
        dialog.getWindow().setBackgroundDrawable(gd);

        dialog.getWindow().setAttributes(getDialogWindowAttributes(activity, dialog));

        animateDialogShow(dialog);
        dialog.show();
    }

    private static void setupMoonlightIcon(Activity activity, ImageView iv) {
        Bitmap bmp = loadOptimizedMoonlightBitmap(activity);
        if (bmp != null) {
            Bitmap circleBmp = createCircularBitmap(bmp);
            iv.setImageBitmap(circleBmp);
            if (_enable_img_rot_) {
                startImageRotationAnimation(iv);
            }
        }
    }

    private static void openQQGroup(Activity activity) {
        try {
            activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("mqqapi://card/show_pslcard?card_type=group&uin=" + _qq_group_num_)));
        } catch (Exception e) {
            showToast(activity, isChinese(activity) ? "无法跳转到QQ" : "Unable to open QQ");
        }
    }

    private static void openTelegram(Activity activity) {
        try {
            String channelLink = _tg_channel_link_;
            if (channelLink != null && !channelLink.isEmpty()) {
                if (channelLink.startsWith("https://t.me/")) {
                    String tgAppLink = channelLink.replace("https://t.me/", "tg://resolve?domain=");
                    try {
                        activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(tgAppLink)));
                        return;
                    } catch (ActivityNotFoundException e) {
                        // Fallback to browser
                    }
                }
                activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(channelLink)));
            } else {
                Toast.makeText(activity, isChinese(activity) ? "TG链接未配置" : "TG link not configured", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            showToast(activity, isChinese(activity) ? "打开TG失败" : "Failed to open Telegram");
        }
    }

    // --- [END] REPLACEMENT UNIFIED DIALOG LAYOUT SECTION ---

    private static void showPackageLockedDialog(final Activity activity, final String contentMessage, final String link) {
        if (activity == null || activity.isFinishing() || (_s_main_dialog_ != null && _s_main_dialog_.isShowing())) {
            return;
        }
        if (_enable_bg_blur_) {
            applyBackgroundBlur(activity);
        }
        resolveColors(activity);
        boolean isChinese = isChinese(activity);
        AlertDialog.Builder builder = new AlertDialog.Builder(activity, android.R.style.Theme_DeviceDefault_Dialog);
        DisplayMetrics displayMetrics = activity.getResources().getDisplayMetrics();
        float dpWidth = displayMetrics.widthPixels / displayMetrics.density;
        _is_large_screen_ = dpWidth >= 600;
        int orientation = activity.getResources().getConfiguration().orientation;
        boolean isLandscape = orientation == Configuration.ORIENTATION_LANDSCAPE;
        boolean useHorizontalLayout = _is_large_screen_ || isLandscape;

        ScrollView sv = new ScrollView(activity);
        LinearLayout rootLayout = new LinearLayout(activity);

        if (useHorizontalLayout) {
            rootLayout.setOrientation(LinearLayout.HORIZONTAL);
            rootLayout.setPadding(40, 40, 40, 40);
            rootLayout.setGravity(Gravity.CENTER);

            LinearLayout leftContent = new LinearLayout(activity);
            leftContent.setOrientation(LinearLayout.VERTICAL);
            leftContent.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));
            if (_show_moonlight_icon_) {
                ImageView iv = new ImageView(activity);
                iv.setLayoutParams(new LinearLayout.LayoutParams(dpToPx_int(activity, 80), dpToPx_int(activity, 80)));
                setupMoonlightIcon(activity, iv);
                leftContent.addView(iv);
            }
            TextView title = new TextView(activity);
            title.setText(isChinese ? "应用已被锁定" : "Application Locked");
            title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
            title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setTextColor(_current_text_color_);
            title.setPadding(0, 20, 0, 0);
            leftContent.addView(title);
            TextView content = new TextView(activity);
            String defaultLockedContent = isChinese ? "此应用版本已锁定，请下载最新官方版本或联系管理员获取支持。" : "This application version is locked. Please download the latest official version or contact the administrator for support.";
            content.setText(contentMessage.isEmpty() ? defaultLockedContent : contentMessage);
            content.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
            content.setTextColor(_current_text_color_);
            content.setPadding(0, 20, 0, 0);
            applyClickableLinks(activity, content, content.getText().toString());
            leftContent.addView(content);
            LinearLayout rightButtons = new LinearLayout(activity);
            rightButtons.setOrientation(LinearLayout.VERTICAL);
            rightButtons.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            rightButtons.setGravity(Gravity.CENTER);
            if (link != null && !link.isEmpty()) {
                addButton(rightButtons, activity, isChinese ? "访问链接" : "Visit Link", v -> {
                    try {
                        String urlToOpen = convertToRawUrl(extractUrlFromHref(link));
                    
                        if (urlToOpen != null && !urlToOpen.isEmpty()) {
                            activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(urlToOpen)));
                        } else {
                            showToast(activity, isChinese ? "链接未配置" : "Linknot configured");
                        }
                    } catch (Exception e) {
                        showToast(activity, isChinese ? "打开链接失败" : "Failed to open link");
                   
                    }
                }, true);
            }
            if (_show_package_lock_close_btn_) {
                addButton(rightButtons, activity, isChinese ? "关闭弹窗" : "Close", v -> {
                    if (_s_main_dialog_ != null) animateDialogDismiss(_s_main_dialog_);
                }, true);
            }
            addButton(rightButtons, activity, isChinese ? "退出应用" : "Exit App", v -> {
                cleanupBeforeExit(activity);
                activity.finish();
                throw new RuntimeException("Application locked, forced exit.");
            }, true);
            rootLayout.addView(leftContent);
            rootLayout.addView(rightButtons);
        } else {
            rootLayout.setOrientation(LinearLayout.VERTICAL);
            if (_show_moonlight_icon_) {
                ImageView iv = new ImageView(activity);
                LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(250, 250);
                ip.gravity = Gravity.CENTER_HORIZONTAL;
                ip.setMargins(0, 40, 0, 0);
                iv.setLayoutParams(ip);
                setupMoonlightIcon(activity, iv);
                rootLayout.addView(iv);
            }
            TextView title = new TextView(activity);
            title.setGravity(Gravity.CENTER);
            title.setText(isChinese ? "应用已被锁定" : "Application Locked");
            title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setTextColor(_current_text_color_);
            title.setTextSize(25);
            rootLayout.addView(title);
            View spacer1 = new View(activity);
            spacer1.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, 80));
            rootLayout.addView(spacer1);
            TextView content = new TextView(activity);
            String defaultLockedContent = isChinese ?
                    "此应用版本已锁定，请下载最新官方版本或联系管理员获取支持。" : "This application version is locked. Please download the latest official version or contact the administrator for support.";
            content.setText(contentMessage.isEmpty() ? defaultLockedContent : contentMessage);
            content.setTextSize(18);
            content.setTextColor(_current_text_color_);
            content.setGravity(Gravity.CENTER);
            content.setPadding(100, 50, 100, 50);
            applyClickableLinks(activity, content, content.getText().toString());
            rootLayout.addView(content);
            if (link != null && !link.isEmpty()) {
                addButton(rootLayout, activity, isChinese ? "访问链接" : "Visit Link", v -> {
                    try {
                        String urlToOpen = convertToRawUrl(extractUrlFromHref(link));
                    
                        if (urlToOpen != null && !urlToOpen.isEmpty()) {
                            activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(urlToOpen)));
                        } else {
                            showToast(activity, isChinese ? "链接未配置" : "Linknot configured");
                        }
                    } catch (Exception e) {
                        showToast(activity, isChinese ? "打开链接失败" : "Failed to open link");
                   
                    }
                }, false);
            }
            if (_show_package_lock_close_btn_) {
                addButton(rootLayout, activity, isChinese ? "关闭弹窗" : "Close", v -> {
                    if (_s_main_dialog_ != null) animateDialogDismiss(_s_main_dialog_);
                }, false);
            }
            addButton(rootLayout, activity, isChinese ? "退出应用" : "Exit App", v -> {
                cleanupBeforeExit(activity);
                activity.finish();
                throw new RuntimeException("Application locked, forced exit.");
            }, false);
            View spacer2 = new View(activity);
            spacer2.setLayoutParams(new LinearLayout.LayoutParams(1, 40));
            rootLayout.addView(spacer2);
        }

        sv.addView(rootLayout);
        _s_main_dialog_ = builder.create();
        setupCommonDialogProperties(activity, _s_main_dialog_, sv, false);
    }

    private static void showDontShowAgainDialog(final Activity activity, final SharedPreferences prefs) {
        if (activity == null || activity.isFinishing()) {
            return;
        }

        final boolean isChinese = isChinese(activity);

        LinearLayout layout = new LinearLayout(activity);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 50, 50, 50);

        TextView message = new TextView(activity);
        message.setText(isChinese ? "是否不再提示此弹窗？" : "Don't show this dialog again?");
        message.setTextSize(18);
        message.setTextColor(_current_text_color_);
        message.setGravity(Gravity.CENTER);
        layout.addView(message);

        LinearLayout buttonLayout = new LinearLayout(activity);
        buttonLayout.setOrientation(LinearLayout.HORIZONTAL);
        buttonLayout.setGravity(Gravity.CENTER);
        buttonLayout.setPadding(0, 30, 0, 0);

        Button negativeButton = new Button(activity);
        negativeButton.setText(isChinese ? "否" : "No");
        negativeButton.setTextColor(_current_button_text_);
        negativeButton.setBackground(createButtonBackground(_current_button_bg_));
        LinearLayout.LayoutParams negativeParams = new LinearLayout.LayoutParams(0, -2);
        negativeParams.weight = 1;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            negativeParams.setMarginEnd(10);
        } else {
            negativeParams.setMargins(0, 0, 10, 0);
        }
        negativeButton.setLayoutParams(negativeParams);

        final Button positiveButton = new Button(activity);
        positiveButton.setTextColor(_current_button_text_);
        positiveButton.setBackground(createButtonBackground(_current_button_bg_));
        LinearLayout.LayoutParams positiveParams = new LinearLayout.LayoutParams(0, -2);
        positiveParams.weight = 1;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            positiveParams.setMarginStart(10);
        } else {
            positiveParams.setMargins(10, 0, 0, 0);
        }
        positiveButton.setLayoutParams(positiveParams);

        if (_enable_countdown_dont_show_) {
            positiveButton.setEnabled(false);
            new CountDownTimer(_DONT_SHOW_AGAIN_CD_, 1000) {
                public void onTick(long millisUntilFinished) {
                    int seconds = (int) (millisUntilFinished / 1000);
                    positiveButton.setText(isChinese ? "是 (" + seconds + ")" : "Yes (" + seconds + ")");
                }

                public void onFinish() {
                    positiveButton.setText(isChinese ? "是" : "Yes");
                    positiveButton.setEnabled(true);
                }
            }.start();
        } else {
            positiveButton.setText(isChinese ? "是" : "Yes");
            positiveButton.setEnabled(true);
        }


        buttonLayout.addView(negativeButton);
        buttonLayout.addView(positiveButton);
        layout.addView(buttonLayout);
        final AlertDialog dialog = new AlertDialog.Builder(activity, android.R.style.Theme_DeviceDefault_Dialog)
                .setView(layout)
                .create();
        GradientDrawable dialogBackground = new GradientDrawable();
        dialogBackground.setCornerRadius(dpToPx(activity, 16));
        dialogBackground.setColor(_current_dialog_bg_);
        dialog.getWindow().setBackgroundDrawable(dialogBackground);

        negativeButton.setOnClickListener(v -> animateButtonPress(v, () -> {
            vibrateOnClick(activity);
            dialog.dismiss();
        }));
        positiveButton.setOnClickListener(v -> animateButtonPress(v, () -> {
            vibrateOnClick(activity);
            try {
                prefs.edit()
                        .putString("dialogVer", _cfg_version_)
                        .putBoolean("0", true)
    
                        .apply();
            } catch (Exception e) {
                showToast(activity, isChinese ? "设置失败：" + e.getMessage() : "Failed to set: " + e.getMessage());
            }
            dialog.dismiss();
            
            if (_s_main_dialog_ != null) {
                animateDialogDismiss(_s_main_dialog_);
            }
        }));
        dialog.show();

        dialog.getWindow().setAttributes(getDialogWindowAttributes(activity, dialog));
    }

    private static void showInitialOfflineDialog(final Activity activity) {
        if (activity == null || activity.isFinishing() || (_s_main_dialog_ != null && _s_main_dialog_.isShowing())) {
            return;
        }
        if (_enable_bg_blur_) {
            applyBackgroundBlur(activity);
        }
        resolveColors(activity);
        boolean isChinese = isChinese(activity);
        AlertDialog.Builder builder = new AlertDialog.Builder(activity, android.R.style.Theme_DeviceDefault_Dialog);
        DisplayMetrics displayMetrics = activity.getResources().getDisplayMetrics();
        float dpWidth = displayMetrics.widthPixels / displayMetrics.density;
        _is_large_screen_ = dpWidth >= 600;
        int orientation = activity.getResources().getConfiguration().orientation;
        boolean isLandscape = orientation == Configuration.ORIENTATION_LANDSCAPE;
        boolean useHorizontalLayout = _is_large_screen_ || isLandscape;

        ScrollView sv = new ScrollView(activity);
        LinearLayout rootLayout = new LinearLayout(activity);

        if (useHorizontalLayout) {
            rootLayout.setOrientation(LinearLayout.HORIZONTAL);
            rootLayout.setPadding(40, 40, 40, 40);
            rootLayout.setGravity(Gravity.CENTER);

            LinearLayout leftContent = new LinearLayout(activity);
            leftContent.setOrientation(LinearLayout.VERTICAL);
            leftContent.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));
            if (_show_moonlight_icon_) {
                ImageView iv = new ImageView(activity);
                iv.setLayoutParams(new LinearLayout.LayoutParams(dpToPx_int(activity, 80), dpToPx_int(activity, 80)));
                setupMoonlightIcon(activity, iv);
                leftContent.addView(iv);
            }
            TextView title = new TextView(activity);
            title.setText(isChinese ? "网络连接错误" : "Network Error");
            title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
            title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setTextColor(_current_text_color_);
            title.setPadding(0, 20, 0, 0);
            leftContent.addView(title);
            TextView content = new TextView(activity);
            content.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
            applyClickableLinks(activity, content, isChinese ? "首次启动需要网络连接来获取配置，请连接网络后重试。" : "A network connection is required on first launch to fetch configuration. Please connect and try again.");
            content.setTextColor(_current_text_color_);
            content.setPadding(0, 20, 0, 0);
            leftContent.addView(content);

            LinearLayout rightButtons = new LinearLayout(activity);
            rightButtons.setOrientation(LinearLayout.VERTICAL);
            rightButtons.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            rightButtons.setGravity(Gravity.CENTER);
            addButton(rightButtons, activity, isChinese ? "确定并退出" : "OK & Exit", v -> {
                cleanupBeforeExit(activity);
                activity.finish();
            }, true);
            rootLayout.addView(leftContent);
            rootLayout.addView(rightButtons);
        } else {
            rootLayout.setOrientation(LinearLayout.VERTICAL);
            if (_show_moonlight_icon_) {
                ImageView iv = new ImageView(activity);
                LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(250, 250);
                ip.gravity = Gravity.CENTER_HORIZONTAL;
                ip.setMargins(0, 40, 0, 0);
                iv.setLayoutParams(ip);
                setupMoonlightIcon(activity, iv);
                rootLayout.addView(iv);
            }
            TextView title = new TextView(activity);
            title.setGravity(Gravity.CENTER);
            title.setText(isChinese ? "网络连接错误" : "Network Error");
            title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setTextColor(_current_text_color_);
            title.setTextSize(25);
            rootLayout.addView(title);
            View spacer1 = new View(activity);
            spacer1.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, 80));
            rootLayout.addView(spacer1);
            TextView content = new TextView(activity);
            content.setTextSize(18);
            applyClickableLinks(activity, content, isChinese ? "首次启动需要网络连接来获取配置，请连接网络后重试。" : "A network connection is required on first launch to fetch configuration. Please connect and try again.");
            content.setTextColor(_current_text_color_);
            content.setPadding(100, 50, 100, 50);
            rootLayout.addView(content);
            addButton(rootLayout, activity, isChinese ? "确定并退出" : "OK & Exit", v -> {
                cleanupBeforeExit(activity);
                activity.finish();
            }, false);
            View spacer2 = new View(activity);
            spacer2.setLayoutParams(new LinearLayout.LayoutParams(1, 40));
            rootLayout.addView(spacer2);
        }
        sv.addView(rootLayout);
        _s_main_dialog_ = builder.create();
        setupCommonDialogProperties(activity, _s_main_dialog_, sv, false);
    }

    private static void cleanupBeforeExit(Activity activity) {
        if (_s_main_dialog_ != null && _s_main_dialog_.isShowing()) {
            _s_main_dialog_.dismiss();
        }
        removeBackgroundBlur(activity);
        _s_main_dialog_ = null;
        _s_activity_ref_ = null;
        if (_card_key_timer_ != null) {
            _card_key_timer_.cancel();
            _card_key_timer_ = null;
        }
        if (_dev_id_timer_ != null) {
            _dev_id_timer_.cancel();
            _dev_id_timer_ = null;
        }
    }

    private static boolean isChinese(Context context) {
        return context.getResources().getConfiguration().getLocales().get(0).getLanguage().equals("zh");
    }

    private static boolean isSystemDarkMode(Context context) {
        return (context.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    }

    private static void showToast(Activity activity, String message) {
        if (activity != null && !activity.isFinishing()) {
            _main_handler_.post(() -> Toast.makeText(activity, message, Toast.LENGTH_SHORT).show());
        }
    }

    private static void resetNetworkConfigsToDefault() {
        _dialog_version_ = 2;
        _dyn_content_ = "Content1";
        _eng_content_ = "Content2";
        _force_upd_link_ = "";
        _tg_channel_link_ = "https://t.me/channel";
        _qq_group_num_ = "";
        _popup_title_ = "Title1";
        _popup_title_eng_ = "Title2";
        _force_upd_content_ = "UpdateMsg1";
        _force_upd_content_eng_ = "UpdateMsg2";
        _upd_log_ = "Log1";
        _upd_log_eng_ = "Log2";
        _cfg_version_ = "1.0";
        _sig_sha1_list_ = new ArrayList<>(_DEF_SIG_LIST_);
        _pkg_ver_cfg_ = new HashMap<>();
        _pkg_content_map_ = new HashMap<>();
        _dev_card_keys_ = new HashMap<>();
        _enable_dev_id_check_ = false;
        _allowed_dev_ids_ = new ArrayList<>();
        _dev_id_card_link_ = "";
        _force_upd_req_ = false;
        _net_cfg_enabled_ = true;
        _show_dyn_content_ = true;
        _show_upd_log_ = true;
        _reset_dont_show_ = false;
        _enable_img_rot_ = true;
        _enable_bg_blur_ = true;
        _enable_norm_popup_ = true;
        _show_close_btn_ = true;
        _show_dont_show_btn_ = true;
        _show_qq_btn_ = true;
        _show_tg_btn_ = true;
        _enable_out_click_ = true;
        _enable_sig_ver_ = false;
        _enable_night_mode_ = false;
        _enable_monet_dyn_ = true;
        _enable_builtin_monet_ = true;
        _monet_theme_color_ = "Color_Val";
        _enable_dpi_auto_ = true;
        _enable_remote_notif_ = false;
        _remote_notif_content_ = "";
        _show_moonlight_icon_ = true;
        _enable_dev_card_key_check_ = false;
        _enable_countdown_dont_show_ = true;
        _show_force_update_close_btn_ = false;
        _show_package_lock_close_btn_ = false;
        _force_use_domestic_url_ = false;
        _force_use_international_url_ = false;
        _enable_user_custom_url_ = false;
        _user_custom_urls_ = "";
        _config_load_timeout_ms_ = _DEF_CONFIG_LOAD_TIMEOUT_;
        _enable_config_syntax_check_ = false;
        _enable_rich_device_info_collection_ = false;
        _enable_dynamic_text_colors_ = true;
        _show_neutral_btn_ = false;
        _neutral_btn_content_ = "";
        _pkg_lock_map_ = new HashMap<>();
        _pkg_lock_content_ = "";
        _pkg_lock_link_ = "";
        _pkg_popup_control_ = new HashMap<>();
        _normal_popup_control_ = new HashMap<>();
        
        // Reset cloud inject configs
        _security_enabled_ = true;
        _detect_xp_ = false;
        _detect_packet_sniffing_ = false;
        _detect_gg_ = false;
        _cloud_inject_enabled_ = false;
        _ci_package_app_id_map_.clear();
        _ci_global_app_id_ = CI_DEFAULT_APP_ID;
        _ci_notice_enabled_ = true;
        _ci_last_notice_hash_ = "";
    }

    private static void applyBackgroundBlur(Activity activity) {
        if (!_enable_bg_blur_ || Build.VERSION.SDK_INT < Build.VERSION_CODES.S || activity.isFinishing()) return;
        try {
            activity.getWindow().getDecorView().setRenderEffect(RenderEffect.createBlurEffect(25, 25, Shader.TileMode.CLAMP));
            _is_blur_applied_ = true;
        } catch (Exception e) {
        }
    }

    private static void removeBackgroundBlur(Activity activity) {
        if (!_is_blur_applied_ || Build.VERSION.SDK_INT < Build.VERSION_CODES.S || activity == null || activity.isFinishing()) return;
        try {
            activity.getWindow().getDecorView().setRenderEffect(null);
            _is_blur_applied_ = false;
        } catch (Exception e) {
        }
    }

    private static void showForceUpdateDialog(final Activity activity) {
        if (activity == null || activity.isFinishing() || (_s_main_dialog_ != null && _s_main_dialog_.isShowing())) {
            return;
        }
        if (_enable_bg_blur_) {
            applyBackgroundBlur(activity);
        }
        resolveColors(activity);
        boolean isChinese = isChinese(activity);
        AlertDialog.Builder builder = new AlertDialog.Builder(activity, android.R.style.Theme_DeviceDefault_Dialog);
        DisplayMetrics displayMetrics = activity.getResources().getDisplayMetrics();
        float dpWidth = displayMetrics.widthPixels / displayMetrics.density;
        _is_large_screen_ = dpWidth >= 600;
        int orientation = activity.getResources().getConfiguration().orientation;
        boolean isLandscape = orientation == Configuration.ORIENTATION_LANDSCAPE;
        boolean useHorizontalLayout = _is_large_screen_ || isLandscape;

        ScrollView sv = new ScrollView(activity);
        LinearLayout rootLayout = new LinearLayout(activity);

        if (useHorizontalLayout) {
            rootLayout.setOrientation(LinearLayout.HORIZONTAL);
            rootLayout.setPadding(40, 40, 40, 40);
            rootLayout.setGravity(Gravity.CENTER);

            LinearLayout leftContent = new LinearLayout(activity);
            leftContent.setOrientation(LinearLayout.VERTICAL);
            leftContent.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));
            if (_show_moonlight_icon_) {
                ImageView iv = new ImageView(activity);
                iv.setLayoutParams(new LinearLayout.LayoutParams(dpToPx_int(activity, 80), dpToPx_int(activity, 80)));
                setupMoonlightIcon(activity, iv);
                leftContent.addView(iv);
            }
            TextView title = new TextView(activity);
            title.setText(isChinese ? "版本更新" : "Update Required");
            title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
            title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setTextColor(_current_text_color_);
            title.setPadding(0, 20, 0, 0);
            leftContent.addView(title);
            TextView content = new TextView(activity);
            content.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
            applyClickableLinks(activity, content, isChinese ? _force_upd_content_ : _force_upd_content_eng_);
            content.setTextColor(_current_text_color_);
            content.setPadding(0, 20, 0, 0);
            leftContent.addView(content);
            if (_show_upd_log_) {
                TextView updateLogView = new TextView(activity);
                updateLogView.setTextSize(14);
                updateLogView.setText((isChinese ? "更新日志：\n" : "Update Log:\n") + (isChinese ? _upd_log_ : _upd_log_eng_));
                updateLogView.setTextColor(_current_text_color_);
                updateLogView.setPadding(0, 20, 0, 0);
                leftContent.addView(updateLogView);
            }

            LinearLayout rightButtons = new LinearLayout(activity);
            rightButtons.setOrientation(LinearLayout.VERTICAL);
            rightButtons.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            rightButtons.setGravity(Gravity.CENTER);

            addButton(rightButtons, activity, isChinese ? "立即更新" : "Update Now", v -> {
                try {
                    String urlToOpen = convertToRawUrl(extractUrlFromHref(_force_upd_link_));
                    if (urlToOpen != null && !urlToOpen.isEmpty()) {
                    
                        activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(urlToOpen)));
                    } else {
                        showToast(activity, isChinese ? "更新链接未配置" : "Update link not configured");
                    }
                } catch (Exception e) 
                {
                    showToast(activity, isChinese ? "打开链接失败" : "Failed to open link");
                }
            }, true);
            if (_show_force_update_close_btn_) {
                addButton(rightButtons, activity, isChinese ? "暂不更新" : "Close", v -> {
                    if (_s_main_dialog_ != null) animateDialogDismiss(_s_main_dialog_);
                }, true);
            }
            addButton(rightButtons, activity, isChinese ? "退出应用" : "Exit App", v -> {
                cleanupBeforeExit(activity);
                activity.finish();
            }, true);
            rootLayout.addView(leftContent);
            rootLayout.addView(rightButtons);
        } else {
            rootLayout.setOrientation(LinearLayout.VERTICAL);
            if (_show_moonlight_icon_) {
                ImageView iv = new ImageView(activity);
                LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(250, 250);
                ip.gravity = Gravity.CENTER_HORIZONTAL;
                ip.setMargins(0, 40, 0, 0);
                iv.setLayoutParams(ip);
                setupMoonlightIcon(activity, iv);
                rootLayout.addView(iv);
            }
            TextView title = new TextView(activity);
            title.setGravity(Gravity.CENTER);
            title.setText(isChinese ? "版本更新" : "Update Required");
            title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setTextColor(_current_text_color_);
            title.setTextSize(25);
            rootLayout.addView(title);
            View spacer1 = new View(activity);
            spacer1.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, 80));
            rootLayout.addView(spacer1);
            TextView content = new TextView(activity);
            content.setTextSize(18);
            applyClickableLinks(activity, content, isChinese ? _force_upd_content_ : _force_upd_content_eng_);
            content.setTextColor(_current_text_color_);
            content.setPadding(100, 50, 100, 50);
            rootLayout.addView(content);
            if (_show_upd_log_) {
                TextView updateLogView = new TextView(activity);
                updateLogView.setTextSize(16);
                updateLogView.setText((isChinese ? "更新日志：\n" : "Update Log:\n") + (isChinese ? _upd_log_ : _upd_log_eng_));
                updateLogView.setTextColor(_current_text_color_);
                updateLogView.setPadding(100, 20, 100, 50);
                rootLayout.addView(updateLogView);
            }
            addButton(rootLayout, activity, isChinese ? "立即更新" : "Update Now", v -> {
                try {
                    String urlToOpen = convertToRawUrl(extractUrlFromHref(_force_upd_link_));
                    if (urlToOpen != null && !urlToOpen.isEmpty()) {
            
                        activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(urlToOpen)));
                    } else {
                        showToast(activity, isChinese ? "更新链接未配置" : "Update link not configured");
                    }
            
                } catch (Exception e) {
                    showToast(activity, isChinese ? "打开链接失败" : "Failed to open link");
                }
            }, false);
            if (_show_force_update_close_btn_) {
                addButton(rootLayout, activity, isChinese ? "暂不更新" : "Close", v -> {
                    if (_s_main_dialog_ != null) animateDialogDismiss(_s_main_dialog_);
                }, false);
            }
            addButton(rootLayout, activity, isChinese ? "退出应用" : "Exit App", v -> {
                cleanupBeforeExit(activity);
                activity.finish();
            }, false);
            View spacer2 = new View(activity);
            spacer2.setLayoutParams(new LinearLayout.LayoutParams(1, 40));
            rootLayout.addView(spacer2);
        }

        sv.addView(rootLayout);
        _s_main_dialog_ = builder.create();
        setupCommonDialogProperties(activity, _s_main_dialog_, sv, false);
    }

    private static void checkAndCacheScreenType(Activity activity, SharedPreferences prefs) {
        boolean alreadyChecked = prefs.getBoolean(_PREF_N_, false);
        if (alreadyChecked) {
            return;
        }

        DisplayMetrics displayMetrics = activity.getResources().getDisplayMetrics();
        float dpWidth = displayMetrics.widthPixels / displayMetrics.density;
        boolean isTablet = dpWidth >= 600;
        _is_large_screen_ = isTablet;

        prefs.edit()
                .putBoolean(_PREF_M_, isTablet)
                .putBoolean(_PREF_N_, true)
                .apply();
    }

    private static Drawable createButtonBackground(int buttonColor) {
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        gd.setCornerRadius(70f);
        gd.setColor(buttonColor);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            return new RippleDrawable(ColorStateList.valueOf(adjustColorBrightness(buttonColor, 0.8f)), gd, null);
        }
        return gd;
    }

    private static int adjustColorBrightness(int color, float factor) {
        float[] hsv = new float[3];
        Color.colorToHSV(color, hsv);
        hsv[2] *= factor;
        return Color.HSVToColor(hsv);
    }

    private static void animateButtonPress(View view, final Runnable action) {
        view.animate().scaleX(0.95f).scaleY(0.95f).setDuration(80).setInterpolator(_STD_DECEL_)
                .withEndAction(() -> {
                    view.animate().scaleX(1f).scaleY(1f).setDuration(120).setInterpolator(_EMPH_INTERP_).start();
                    if (action != null) {
           
                        action.run();
                    }
                }).start();
    }

    private static void animateDialogShow(AlertDialog dialog) {
        if (dialog == null || dialog.getWindow() == null) return;
        View view = dialog.getWindow().getDecorView();
        view.setAlpha(0f);
        view.setScaleX(0.0f);
        view.setScaleY(0.0f);
        view.setTranslationY(dpToPx(dialog.getContext(), 50));
        view.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f).setDuration(300).setInterpolator(_EMPH_INTERP_).start();
    }

    private static void animateDialogDismiss(final AlertDialog dialog) {
        if (dialog == null || dialog.getWindow() == null) return;
        dialog.getWindow().getDecorView().animate().alpha(0f).scaleX(0.9f).scaleY(0.9f).setDuration(250)
                .setInterpolator(_STD_DECEL_).withEndAction(dialog::dismiss).start();
    }

    private static float dpToPx(Context context, float dp) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, context.getResources().getDisplayMetrics());
    }

    private static int dpToPx_int(Context context, float dp) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, context.getResources().getDisplayMetrics());
    }

    private static void vibrateOnClick(Context context) {
        try {
            Vibrator v = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null && v.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v.vibrate(VibrationEffect.createOneShot(15, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    v.vibrate(15);
                }
            }
        } catch (Exception e) {
        }
    }

    private static Bitmap loadOptimizedMoonlightBitmap(Activity activity) {
        try (InputStream is = activity.getAssets().open("Moonlight")) {
            BitmapFactory.Options opt = new BitmapFactory.Options();
            opt.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(is, null, opt);
            opt.inSampleSize = calculateInSampleSize(opt, 250, 250);
            opt.inJustDecodeBounds = false;
            opt.inPreferredConfig = Bitmap.Config.ARGB_8888;
            try (InputStream is2 = activity.getAssets().open("Moonlight")) {
                return BitmapFactory.decodeStream(is2, null, opt);
            }
        } catch (IOException e) {
            return null;
        }
    }

    private static Bitmap createCircularBitmap(Bitmap source) {
        if (source == null) return null;
        int width = source.getWidth();
        int height = source.getHeight();
        Bitmap output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        canvas.drawCircle(width / 2f, height / 2f, Math.min(width, height) / 2f, paint);

        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(source, 0, 0, paint);
        if (source != output) {
            source.recycle();
        }
        return output;
    }

    private static void startImageRotationAnimation(ImageView imageView) {
        ObjectAnimator rotation = ObjectAnimator.ofFloat(imageView, "rotation", 0f, 360f);
        rotation.setDuration(5000);
        rotation.setRepeatCount(ObjectAnimator.INFINITE);
        rotation.setInterpolator(new LinearInterpolator());
        rotation.start();
    }

    private static int calculateInSampleSize(BitmapFactory.Options opt, int reqW, int reqH) {
        int h = opt.outHeight;
        int w = opt.outWidth;
        int size = 1;
        if (h > reqH || w > reqW) {
            final int halfH = h / 2;
            final int halfW = w / 2;
            while ((halfH / size) >= reqH && (halfW / size) >= reqW) {
                size *= 2;
            }
        }
        return size;
    }

    private static void parseConfig(Activity activity, String config, String originalUrl) {
        if (config == null || config.isEmpty()) {
            return;
        }

        String processedConfig = config;
        if (originalUrl != null) {
            if (originalUrl.contains("sharechain.qq.com") ||
                    originalUrl.contains("gitee.com") ||
                    originalUrl.contains("gitcode.net") ||
                    originalUrl.contains("gitcode.com") ||
                   
                            originalUrl.contains("github.com")) {
                int startIndex = processedConfig.indexOf("//配置开始");
                int endIndex = processedConfig.indexOf("//配置结束");
                if (startIndex != -1 && endIndex != -1 && startIndex < endIndex) {
                    processedConfig = processedConfig.substring(startIndex + "//配置开始".length(), endIndex);
                }
            } else if (originalUrl.contains("share.weiyun.com")) {
                int firstStartIndex = processedConfig.indexOf("//配置开始");
                if (firstStartIndex != -1) {
                    int secondStartIndex = processedConfig.indexOf("//配置开始", firstStartIndex + "//配置开始".length());
                    int endIndex = processedConfig.indexOf("//配置结束");
                    if (secondStartIndex != -1 && endIndex != -1 && secondStartIndex < endIndex) {
                        processedConfig = processedConfig.substring(secondStartIndex + "//配置开始".length(), endIndex);
                    }
                }
            }
        }

        processedConfig = processedConfig.replaceAll("\\\\\"", "\"").replaceAll("\\\\n", "\n");
        boolean jsonParsedSuccessfully = false;
        try {
            parseConfigJson(processedConfig);
            jsonParsedSuccessfully = true;
        } catch (JSONException e) {
        }

        if (!jsonParsedSuccessfully) {
            parseConfigTxt(activity, processedConfig);
        }

        if (_enable_config_syntax_check_) {
            performConfigSyntaxCheck(processedConfig, jsonParsedSuccessfully);
        }
    }

    private static void performConfigSyntaxCheck(String configContent, boolean isJsonParsed) {
        boolean isValid = true;
        List<String> missingFields = new ArrayList<>();

        String[] criticalFields = {
                "配置版本", "内容", "英文内容", "更新链接", "强制更新内容", "强制更新内容英文"
        };
        for (String field : criticalFields) {
            if (isJsonParsed) {
                try {
                    JSONObject jsonConfig = new JSONObject(configContent);
                    if (!jsonConfig.has(field) || jsonConfig.getString(field).isEmpty()) {
                        missingFields.add(field);
                        isValid = false;
                    }
                } catch (JSONException e) {
                    isValid = false;
                    break;
                }
            } else {
                String content = extractContentBetweenMarkers(field, null);
                if (content == null || content.isEmpty()) {
                    missingFields.add(field);
                    isValid = false;
                }
            }
        }

        if (!isValid) {
        } else {
        }
    }


    private static void parseConfigJson(String config) throws JSONException {
        JSONObject jsonConfig = new JSONObject(config);
        if (jsonConfig.has("弹窗版本")) _dialog_version_ = jsonConfig.optInt("弹窗版本", 2);
        if (jsonConfig.has("内容")) _dyn_content_ = jsonConfig.getString("内容");
        if (jsonConfig.has("英文内容")) _eng_content_ = jsonConfig.getString("英文内容");
        if (jsonConfig.has("更新链接")) _force_upd_link_ = jsonConfig.getString("更新链接");

        if (jsonConfig.has("TG频道")) {
            String tgChannelConfig = jsonConfig.getString("TG频道");
            if (tgChannelConfig != null && !tgChannelConfig.isEmpty()) {
                if (!tgChannelConfig.startsWith("https://") && !tgChannelConfig.startsWith("tg://")) {
                    if (tgChannelConfig.startsWith("@")) {
                        _tg_channel_link_ = "https://t.me/" + tgChannelConfig.substring(1);
                    } else {
                        _tg_channel_link_ = "https://t.me/" + tgChannelConfig;
                    }
                } else {
                    _tg_channel_link_ = tgChannelConfig;
                }
            } else {
                _tg_channel_link_ = "https://t.me/channel";
            }
        }


        if (jsonConfig.has("QQ群")) _qq_group_num_ = jsonConfig.getString("QQ群");
        if (jsonConfig.has("弹窗标题")) _popup_title_ = jsonConfig.getString("弹窗标题");
        if (jsonConfig.has("弹窗标题英文")) _popup_title_eng_ = jsonConfig.getString("弹窗标题英文");
        if (jsonConfig.has("强制更新内容")) _force_upd_content_ = jsonConfig.getString("强制更新内容");
        if (jsonConfig.has("强制更新内容英文")) _force_upd_content_eng_ = jsonConfig.getString("强制更新内容英文");
        if (jsonConfig.has("更新日志")) _upd_log_ = jsonConfig.getString("更新日志");
        if (jsonConfig.has("更新日志英文")) _upd_log_eng_ = jsonConfig.getString("更新日志英文");
        if (jsonConfig.has("配置版本")) _cfg_version_ = jsonConfig.getString("配置版本");
        if (jsonConfig.has("远程通知内容")) _remote_notif_content_ = jsonConfig.getString("远程通知内容");
        if (jsonConfig.has("签名SHA1")) {
            String sigs = jsonConfig.getString("签名SHA1");
            if (sigs != null && !sigs.isEmpty()) {
                _sig_sha1_list_ = new ArrayList<>(Arrays.asList(sigs.split(",")));
            } else {
                _sig_sha1_list_ = new ArrayList<>(_DEF_SIG_LIST_);
            }
        }

        if (jsonConfig.has("包名版本")) {
            String pkgVer = jsonConfig.getString("包名版本");
            if (pkgVer != null && !pkgVer.isEmpty()) {
                _pkg_ver_cfg_.clear();
                for (String pair : pkgVer.split(",")) {
                    String[] kv = pair.split("=");
                    if (kv.length == 2) {
                        try {
                            _pkg_ver_cfg_.put(kv[0].trim(), Integer.parseInt(kv[1].trim()));
                        } catch (NumberFormatException e) {
                        }
                    }
                }
            }
        }

        if (jsonConfig.has("包名内容")) {
      
            String pkgContent = jsonConfig.getString("包名内容");
            if (pkgContent != null && !pkgContent.isEmpty()) {
                _pkg_content_map_.clear();
                for (String pair : pkgContent.split(";")) {
                    String[] kv = pair.split(":", 2);
                    if (kv.length == 2) {
                        _pkg_content_map_.put(kv[0].trim(), kv[1].trim());
                    }
                }
            }
        }

        if (jsonConfig.has("设备码卡密")) {
            String deviceCardKeysConfig = jsonConfig.getString("设备码卡密");
            if (deviceCardKeysConfig != null && !deviceCardKeysConfig.isEmpty()) {
                _dev_card_keys_.clear();
                for (String pair : deviceCardKeysConfig.split(",")) {
                    String[] kv = pair.split("=", 2);
                    if (kv.length == 2) {
                        _dev_card_keys_.put(kv[0].trim(), kv[1].trim());
                    }
                }
            } else {
                _dev_card_keys_.clear();
            }
        }

        if (jsonConfig.has("启用设备码弹窗")) {
            _enable_dev_id_check_ = jsonConfig.getString("启用设备码弹窗").equals("开");
        }
        if (jsonConfig.has("设备码列表")) {
            String allowedDeviceIdsConfig = jsonConfig.getString("设备码列表");
            if (allowedDeviceIdsConfig != null && !allowedDeviceIdsConfig.isEmpty()) {
                _allowed_dev_ids_ = new ArrayList<>(Arrays.asList(allowedDeviceIdsConfig.split(",")));
            } else {
                _allowed_dev_ids_ = new ArrayList<>();
            }
        }

        if (jsonConfig.has("设备码卡密链接")) {
            _dev_id_card_link_ = jsonConfig.getString("设备码卡密链接");
        }

        if (jsonConfig.has("弹窗包名锁定")) {
            String packageLockConfig = jsonConfig.getString("弹窗包名锁定");
            if (packageLockConfig != null && !packageLockConfig.isEmpty()) {
                _pkg_lock_map_.clear();
                for (String pair : packageLockConfig.split(",")) {
                    String[] kv = pair.split("=", 2);
                    if (kv.length == 2 && "锁".equals(kv[1].trim())) {
                        _pkg_lock_map_.put(kv[0].trim(), true);
                    }
                }
            } else {
                _pkg_lock_map_.clear();
            }
        }
        if (jsonConfig.has("弹窗包名锁定内容")) {
            _pkg_lock_content_ = jsonConfig.getString("弹窗包名锁定内容");
        }
        if (jsonConfig.has("弹窗包名锁定链接")) {
            _pkg_lock_link_ = jsonConfig.getString("弹窗包名锁定链接");
        }

        if (jsonConfig.has("弹窗显示控制")) {
            String pkgPopupControlJson = jsonConfig.getString("弹窗显示控制");
            if (pkgPopupControlJson != null && !pkgPopupControlJson.isEmpty()) {
                _pkg_popup_control_.clear();
                for (String pair : pkgPopupControlJson.split(",")) {
                    String[] kv = pair.split("=", 2);
                    if (kv.length == 2) {
                        _pkg_popup_control_.put(kv[0].trim(), "开".equals(kv[1].trim()));
                    }
                }
            } else {
                _pkg_popup_control_.clear();
            }
        }

        if (jsonConfig.has("普通弹窗显示控制")) {
            String normalPopupControlJson = jsonConfig.getString("普通弹窗显示控制");
            if (normalPopupControlJson != null && !normalPopupControlJson.isEmpty()) {
                _normal_popup_control_.clear();
                for (String pair : normalPopupControlJson.split(",")) {
                    String[] kv = pair.split("=", 2);
                    if (kv.length == 2) {
                        _normal_popup_control_.put(kv[0].trim(), "开".equals(kv[1].trim()));
                    }
                }
            } else {
                _normal_popup_control_.clear();
            }
        }


        if (jsonConfig.has("网络配置总开关")) _net_cfg_enabled_ = !"关".equals(jsonConfig.getString("网络配置总开关"));
        if (jsonConfig.has("显示动态内容开关")) _show_dyn_content_ = !"关".equals(jsonConfig.getString("显示动态内容开关"));
        if (jsonConfig.has("显示更新日志开关")) _show_upd_log_ = !"关".equals(jsonConfig.getString("显示更新日志开关"));
        if (jsonConfig.has("重置不再提示")) _reset_dont_show_ = "开".equals(jsonConfig.getString("重置不再提示"));
        if (jsonConfig.has("启用Moonlight图旋转")) _enable_img_rot_ = !"关".equals(jsonConfig.getString("启用Moonlight图旋转"));
        if (jsonConfig.has("启用背景模糊")) _enable_bg_blur_ = !"关".equals(jsonConfig.getString("启用背景模糊"));
        if (jsonConfig.has("启用普通弹窗")) _enable_norm_popup_ = !"关".equals(jsonConfig.getString("启用普通弹窗"));
        if (jsonConfig.has("显示关闭弹窗按钮")) _show_close_btn_ = !"关".equals(jsonConfig.getString("显示关闭弹窗按钮"));
        if (jsonConfig.has("显示不再提示按钮")) _show_dont_show_btn_ = !"关".equals(jsonConfig.getString("显示不再提示按钮"));
        if (jsonConfig.has("显示QQ群按钮")) _show_qq_btn_ = !"关".equals(jsonConfig.getString("显示QQ群按钮"));
        if (jsonConfig.has("显示TG频道按钮")) _show_tg_btn_ = !"关".equals(jsonConfig.getString("显示TG频道按钮"));
        if (jsonConfig.has("启用外部点击消失")) _enable_out_click_ = !"关".equals(jsonConfig.getString("启用外部点击消失"));
        if (jsonConfig.has("启用签名验证")) _enable_sig_ver_ = "开".equals(jsonConfig.getString("启用签名验证"));
        if (jsonConfig.has("启用夜间模式")) _enable_night_mode_ = "开".equals(jsonConfig.getString("启用夜间模式"));
        if (jsonConfig.has("启用Monet动态取色")) _enable_monet_dyn_ = "开".equals(jsonConfig.getString("启用Monet动态取色"));
        if (jsonConfig.has("启用内置Monet主题色")) _enable_builtin_monet_ = "开".equals(jsonConfig.getString("启用内置Monet主题色"));
        if (jsonConfig.has("莫奈主题颜色")) _monet_theme_color_ = jsonConfig.getString("莫奈主题颜色");
        if (jsonConfig.has("启用DPI适配")) _enable_dpi_auto_ = !"关".equals(jsonConfig.getString("启用DPI适配"));
        if (jsonConfig.has("启用远程通知开关")) _enable_remote_notif_ = "开".equals(jsonConfig.getString("启用远程通知开关"));

        if (jsonConfig.has("显示Moonlight图标")) _show_moonlight_icon_ = !"关".equals(jsonConfig.getString("显示Moonlight图标"));
        if (jsonConfig.has("启用设备码卡密弹窗")) _enable_dev_card_key_check_ = "开".equals(jsonConfig.getString("启用设备码卡密弹窗"));
        if (jsonConfig.has("开启不再提示确认倒计时")) _enable_countdown_dont_show_ = !"关".equals(jsonConfig.getString("开启不再提示确认倒计时"));
        if (jsonConfig.has("强制更新弹窗显示关闭按钮")) _show_force_update_close_btn_ = "开".equals(jsonConfig.getString("强制更新弹窗显示关闭按钮"));
        if (jsonConfig.has("包名锁定弹窗显示关闭按钮")) _show_package_lock_close_btn_ = "开".equals(jsonConfig.getString("包名锁定弹窗显示关闭按钮"));
        if (jsonConfig.has("强制使用国内配置URL")) _force_use_domestic_url_ = "开".equals(jsonConfig.getString("强制使用国内配置URL"));
        if (jsonConfig.has("强制使用国际配置URL")) _force_use_international_url_ = "开".equals(jsonConfig.getString("强制使用国际配置URL"));
        if (jsonConfig.has("启用用户自定义配置URL")) _enable_user_custom_url_ = "开".equals(jsonConfig.getString("启用用户自定义配置URL"));
        if (jsonConfig.has("用户自定义配置URL列表")) _user_custom_urls_ = jsonConfig.getString("用户自定义配置URL列表");
        if (jsonConfig.has("配置加载超时时间")) {
            try {
                _config_load_timeout_ms_ = Long.parseLong(jsonConfig.getString("配置加载超时时间"));
            } catch (NumberFormatException e) {
                _config_load_timeout_ms_ = _DEF_CONFIG_LOAD_TIMEOUT_;
            }
        }
        if (jsonConfig.has("启用配置文件语法检查")) _enable_config_syntax_check_ = "开".equals(jsonConfig.getString("启用配置文件语法检查"));
        if (jsonConfig.has("启用更丰富的设备信息收集")) _enable_rich_device_info_collection_ = "开".equals(jsonConfig.getString("启用更丰富的设备信息收集"));

        if (jsonConfig.has("启用弹窗背景改变文字颜色按钮颜色")) {
            _enable_dynamic_text_colors_ = "开".equals(jsonConfig.getString("启用弹窗背景改变文字颜色按钮颜色"));
        }
        if (jsonConfig.has("中立按钮是否显示")) {
            _show_neutral_btn_ = "开".equals(jsonConfig.getString("中立按钮是否显示"));
        }
        if (jsonConfig.has("中立按钮内容")) {
            _neutral_btn_content_ = jsonConfig.getString("中立按钮内容");
        }
    }


    private static void parseConfigTxt(Activity activity, String config) {
        String cleanConfig = config
                .replace("</p><p>", "\n")
                .replace("<br />", "\n")
                .replace("<br/>", "\n")
                .replace("<br>", "\n")
     
                .replace("</div><div>", "\n")
                .replace("<p><br></p>", "\n")
                .replace("amp;", "");
        cleanConfig = decodeHtmlEntities(cleanConfig);

        cleanConfig = cleanConfig.replaceAll("<[^>]*>", "");

        cleanConfig = cleanConfig.replaceAll("[\r\n]+", "\n").trim();

        _full_config_string_ = cleanConfig;

        _dialog_version_ = Integer.parseInt(extractContentBetweenMarkers("弹窗版本", "2"));
        _dyn_content_ = extractContentBetweenMarkers("内容", "Content1");
        _eng_content_ = extractContentBetweenMarkers("英文内容", "Content2");
        _force_upd_link_ = extractContentBetweenMarkers("更新链接", "");

        String tgChannelConfig = extractContentBetweenMarkers("TG频道", null);
        if (tgChannelConfig != null && !tgChannelConfig.isEmpty()) {
            if (!tgChannelConfig.startsWith("https://") && !tgChannelConfig.startsWith("tg://")) {
                if (tgChannelConfig.startsWith("@")) {
                    _tg_channel_link_ = "https://t.me/" + tgChannelConfig.substring(1);
                } else {
                    _tg_channel_link_ = "https://t.me/" + tgChannelConfig;
                }
            } else {
                _tg_channel_link_ = "https://t.me/channel";
            }
        }

        _qq_group_num_ = extractContentBetweenMarkers("QQ群", "");
        _popup_title_ = extractContentBetweenMarkers("弹窗标题", "Title1");
        _popup_title_eng_ = extractContentBetweenMarkers("弹窗标题英文", "Title2");
        _force_upd_content_ = extractContentBetweenMarkers("强制更新内容", "UpdateMsg1");
        _force_upd_content_eng_ = extractContentBetweenMarkers("强制更新内容英文", "UpdateMsg2");
        _upd_log_ = extractContentBetweenMarkers("更新日志", "Log1");
        _upd_log_eng_ = extractContentBetweenMarkers("更新日志英文", "Log2");
        _cfg_version_ = extractContentBetweenMarkers("配置版本", "1.0");
        _remote_notif_content_ = extractContentBetweenMarkers("远程通知内容", "");

        String sigs = extractContentBetweenMarkers("签名SHA1", null);
        if (sigs != null && !sigs.isEmpty()) {
            _sig_sha1_list_ = new ArrayList<>(Arrays.asList(sigs.split(",")));
        } else {
            _sig_sha1_list_ = new ArrayList<>(_DEF_SIG_LIST_);
        }

        String pkgVer = extractContentBetweenMarkers("包名版本", null);
        if (pkgVer != null && !pkgVer.isEmpty()) {
            _pkg_ver_cfg_.clear();
            for (String pair : pkgVer.split(",")) {
                String[] kv = pair.split("=");
                if (kv.length == 2) {
                    try {
                        _pkg_ver_cfg_.put(kv[0].trim(), Integer.parseInt(kv[1].trim()));
                    } catch (NumberFormatException e) {
                    }
                }
            }
        } else {
            _pkg_ver_cfg_.clear();
        }

        String pkgContent = extractContentBetweenMarkers("包名内容", null);
        if (pkgContent != null && !pkgContent.isEmpty()) {
            _pkg_content_map_.clear();
            for (String pair : pkgContent.split(";")) {
                String[] kv = pair.split(":", 2);
                if (kv.length == 2) {
                    _pkg_content_map_.put(kv[0].trim(), kv[1].trim());
                }
            }
        } else {
            _pkg_content_map_.clear();
        }

        String deviceCardKeysConfig = extractContentBetweenMarkers("设备码卡密", null);
        if (deviceCardKeysConfig != null && !deviceCardKeysConfig.isEmpty()) {
            _dev_card_keys_.clear();
            for (String pair : deviceCardKeysConfig.split(",")) {
                String[] kv = pair.split("=", 2);
                if (kv.length == 2) {
                    _dev_card_keys_.put(kv[0].trim(), kv[1].trim());
                }
            }
        } else {
            _dev_card_keys_.clear();
        }

        _enable_dev_id_check_ = "开".equals(extractContentBetweenMarkers("启用设备码弹窗", "关"));
        String allowedDeviceIdsConfig = extractContentBetweenMarkers("设备码列表", null);
        if (allowedDeviceIdsConfig != null && !allowedDeviceIdsConfig.isEmpty()) {
            _allowed_dev_ids_ = new ArrayList<>(Arrays.asList(allowedDeviceIdsConfig.split(",")));
        } else {
            _allowed_dev_ids_ = new ArrayList<>();
        }

        _dev_id_card_link_ = extractContentBetweenMarkers("设备码卡密链接", "");

        String packageLockConfig = extractContentBetweenMarkers("弹窗包名锁定", null);
        if (packageLockConfig != null && !packageLockConfig.isEmpty()) {
            _pkg_lock_map_.clear();
            for (String pair : packageLockConfig.split(",")) {
                String[] kv = pair.split("=", 2);
                if (kv.length == 2 && "锁".equals(kv[1].trim())) {
                    _pkg_lock_map_.put(kv[0].trim(), true);
                }
            }
        } else {
            _pkg_lock_map_.clear();
        }
        _pkg_lock_content_ = extractContentBetweenMarkers("弹窗包名锁定内容", "");
        _pkg_lock_link_ = extractContentBetweenMarkers("弹窗包名锁定链接", "");
        String pkgPopupControlTxt = extractContentBetweenMarkers("弹窗显示控制", null);
        if (pkgPopupControlTxt != null && !pkgPopupControlTxt.isEmpty()) {
            _pkg_popup_control_.clear();
            for (String pair : pkgPopupControlTxt.split(",")) {
                String[] kv = pair.split("=", 2);
                if (kv.length == 2) {
                    _pkg_popup_control_.put(kv[0].trim(), "开".equals(kv[1].trim()));
                }
            }
        } else {
            _pkg_popup_control_.clear();
        }

        String normalPopupControlTxt = extractContentBetweenMarkers("普通弹窗显示控制", null);
        if (normalPopupControlTxt != null && !normalPopupControlTxt.isEmpty()) {
            _normal_popup_control_.clear();
            for (String pair : normalPopupControlTxt.split(",")) {
                String[] kv = pair.split("=", 2);
                if (kv.length == 2) {
                    _normal_popup_control_.put(kv[0].trim(), "开".equals(kv[1].trim()));
                }
            }
        } else {
            _normal_popup_control_.clear();
        }


        _net_cfg_enabled_ = !"关".equals(extractContentBetweenMarkers("网络配置总开关", "开"));
        _show_dyn_content_ = !"关".equals(extractContentBetweenMarkers("显示动态内容开关", "开"));
        _show_upd_log_ = !"关".equals(extractContentBetweenMarkers("显示更新日志开关", "开"));
        _reset_dont_show_ = "开".equals(extractContentBetweenMarkers("重置不再提示", "关"));
        _enable_img_rot_ = !"关".equals(extractContentBetweenMarkers("启用Moonlight图旋转", "开"));
        _enable_bg_blur_ = !"关".equals(extractContentBetweenMarkers("启用背景模糊", "开"));
        _enable_norm_popup_ = !"关".equals(extractContentBetweenMarkers("启用普通弹窗", "开"));
        _show_close_btn_ = !"关".equals(extractContentBetweenMarkers("显示关闭弹窗按钮", "开"));
        _show_dont_show_btn_ = !"关".equals(extractContentBetweenMarkers("显示不再提示按钮", "开"));
        _show_qq_btn_ = !"关".equals(extractContentBetweenMarkers("显示QQ群按钮", "开"));
        _show_tg_btn_ = !"关".equals(extractContentBetweenMarkers("显示TG频道按钮", "开"));
        _enable_out_click_ = !"关".equals(extractContentBetweenMarkers("启用外部点击消失", "开"));
        _enable_sig_ver_ = "开".equals(extractContentBetweenMarkers("启用签名验证", "关"));
        _enable_night_mode_ = "开".equals(extractContentBetweenMarkers("启用夜间模式", "关"));
        _enable_monet_dyn_ = "开".equals(extractContentBetweenMarkers("启用Monet动态取色", "开"));
        _enable_builtin_monet_ = "开".equals(extractContentBetweenMarkers("启用内置Monet主题色", "开"));
        _monet_theme_color_ = extractContentBetweenMarkers("莫奈主题颜色", "Color_Val");
        _enable_dpi_auto_ = !"关".equals(extractContentBetweenMarkers("启用DPI适配", "开"));
        _enable_remote_notif_ = "开".equals(extractContentBetweenMarkers("启用远程通知开关", "关"));
        _enable_dev_card_key_check_ = "开".equals(extractContentBetweenMarkers("启用设备码卡密弹窗", "关"));

        _show_moonlight_icon_ = !"关".equals(extractContentBetweenMarkers("显示Moonlight图标", "开"));
        _enable_countdown_dont_show_ = !"关".equals(extractContentBetweenMarkers("开启不再提示确认倒计时", "开"));
        _show_force_update_close_btn_ = "开".equals(extractContentBetweenMarkers("强制更新弹窗显示关闭按钮", "关"));
        _show_package_lock_close_btn_ = "开".equals(extractContentBetweenMarkers("包名锁定弹窗显示关闭按钮", "关"));
        _force_use_domestic_url_ = "开".equals(extractContentBetweenMarkers("强制使用国内配置URL", "关"));
        _force_use_international_url_ = "开".equals(extractContentBetweenMarkers("强制使用国际配置URL", "关"));
        _enable_user_custom_url_ = "开".equals(extractContentBetweenMarkers("启用用户自定义配置URL", "关"));
        _user_custom_urls_ = extractContentBetweenMarkers("用户自定义配置URL列表", "");
        _enable_config_syntax_check_ = "开".equals(extractContentBetweenMarkers("启用配置文件语法检查", "关"));
        _enable_rich_device_info_collection_ = "开".equals(extractContentBetweenMarkers("启用更丰富的设备信息收集", "关"));

        try {
            _config_load_timeout_ms_ = Long.parseLong(extractContentBetweenMarkers("配置加载超时时间", String.valueOf(_DEF_CONFIG_LOAD_TIMEOUT_)));
        } catch (NumberFormatException e) {
            _config_load_timeout_ms_ = _DEF_CONFIG_LOAD_TIMEOUT_;
        }

        _enable_dynamic_text_colors_ = "开".equals(extractContentBetweenMarkers("启用弹窗背景改变文字颜色按钮颜色", "开"));
        _show_neutral_btn_ = "开".equals(extractContentBetweenMarkers("中立按钮是否显示", "关"));
        _neutral_btn_content_ = extractContentBetweenMarkers("中立按钮内容", "");
        
        // Parse cloud inject and security settings
        parseSecurityConfigs(extractContentBetweenMarkers("安全", null));
        parseCloudInjectManagement(extractContentBetweenMarkers("云注入管理", null));
        _cloud_inject_enabled_ = "开".equals(extractContentBetweenMarkers("云注入模块", "关"));
        _ci_notice_enabled_ = "开".equals(extractContentBetweenMarkers("云注入公告显示", "开"));
        
    }
    
    private static void parseSecurityConfigs(String config) {
        if (config == null || config.isEmpty()) return;
        String[] parts = config.split(",");
        for (String part : parts) {
            String[] kv = part.split("/");
            if (kv.length == 2) {
                String key = kv[0].trim();
                boolean value = "开".equals(kv[1].trim());
                switch (key) {
                    case "XP":
                        _detect_xp_ = value;
                        break;
                    case "抓包":
                        _detect_packet_sniffing_ = value;
                        break;
                    case "GG":
                        _detect_gg_ = value;
                        break;
                    case "全局":
                        _security_enabled_ = value;
                        break;
                    case "云注入":
                        _cloud_inject_enabled_ = value;
                        break;
                }
            }
        }
    }
    
    private static void parseCloudInjectManagement(String config) {
        if (config == null || config.isEmpty()) return;
        _ci_package_app_id_map_.clear();
        String[] entries = config.split(",");
        for (String entry : entries) {
            if (entry.contains("=")) {
                String[] parts = entry.split("=");
                if (parts.length == 2) {
                    String packageName = parts[0].trim();
                    String appId = parts[1].trim();
                    _ci_package_app_id_map_.put(packageName, appId);
                }
            }
        }
    }


    private static String extractContentBetweenMarkers(String tagName, String defaultValue) {
        if (_full_config_string_ == null || _full_config_string_.isEmpty() || tagName == null || tagName.trim().isEmpty()) {
            return defaultValue;
        }

        try {
            String startTag = "〈" + tagName + "〉";
            String endTag = "〈/" + tagName + "〉";

            int startIndex = _full_config_string_.indexOf(startTag);
            if (startIndex == -1) {
                return defaultValue;
            }

            int endIndex = _full_config_string_.indexOf(endTag, startIndex + startTag.length());
            if (endIndex == -1) {
                return defaultValue;
            }

            return _full_config_string_.substring(startIndex + startTag.length(), endIndex).trim();
        } catch (Exception e) {
            return defaultValue;
        }
    }

    private static String decodeHtmlEntities(String text) {
        if (text == null) return "";
        String decodedText = text.replace("\\u003C", "<")
                .replace("\\u003E", ">")
                .replace("\\n", "\n")
                .replace("&#x000A;", "\n")
                .replace("u003Cdiv>", "\n")
                .replace("u003C/a>", "\n")
           
                .replace("！", "\n")

                .replace("&nbsp;", " ")
                .replace("&lt;", "<")
                .replace("&gt;", ">")
                .replace("&amp;", "&")
                .replace("&quot;", "\"")
        
                .replace("&apos;", "'")
                .replace("&#39;", "'")
                .replace("&#47", "/")
                .replace("#x27", "\\")
                .replace("&#x60", "`")
                .replace("&copy", "©");

      
        return decodedText;
    }

    private static void applyClickableLinks(Context context, TextView textView, String message) {
        String cleanMessage = decodeHtmlEntities(message);
        cleanMessage = cleanMessage.replaceAll("<[^>]*>", "");
        cleanMessage = cleanMessage.replaceAll("[\r\n]+", "\n").trim();
        SpannableString spannableMessage = new SpannableString(cleanMessage);
        Pattern urlPattern = Pattern.compile(
                "(https?://[\\w\\-\\.]+\\.[a-z]{2,}(?:/[^\\s\"'<]*)?)",
                Pattern.CASE_INSENSITIVE
        );

        Matcher matcher = urlPattern.matcher(cleanMessage);
        while (matcher.find()) {
            final String cleanUrl = matcher.group(1);

            if (cleanUrl == 
                    null || cleanUrl.isEmpty() || (!cleanUrl.startsWith("http://") && !cleanUrl.startsWith("https://"))) {
                continue;
            }

            ClickableSpan clickableSpan = new ClickableSpan() {
                @Override
                public void onClick(View widget) {
            
                    try {
                        Intent intent = new Intent(Intent.ACTION_VIEW);
                        intent.setData(Uri.parse(cleanUrl));
                        context.startActivity(intent);
               
                        showToast((Activity) context, isChinese(context) ? "正在打开链接..." : "Opening link...");
                    } catch (Exception e) {
                        showToast((Activity) context, isChinese(context) ?
                                "打开链接失败" : "Failed to open link");
                    }
                }

                @Override
                public void updateDrawState(TextPaint ds) {
                    ds.setColor(Color.parseColor("#FF2196F3"));
                    ds.setUnderlineText(false);
                }
            };

            spannableMessage.setSpan(clickableSpan, matcher.start(), matcher.end(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        textView.setText(spannableMessage);
        textView.setMovementMethod(LinkMovementMethod.getInstance());
    }

    private static String getDeviceId(Context context) {
        return Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
    }

    private static String getRichDeviceInfo(Context context) {
        if (context == null) return "UnknownDevice";
        DisplayMetrics dm = context.getResources().getDisplayMetrics();
        String deviceInfo = String.format(
                "Model:%s;OS:%s;API:%d;DPI:%d;Density:%.2f;Screen:%dx%d",
                Build.MODEL,
                Build.VERSION.RELEASE,
                Build.VERSION.SDK_INT,
                dm.densityDpi,
             
                dm.density,
                dm.widthPixels,
                dm.heightPixels
        );
        return deviceInfo;
    }


    private static void setupEditTextStyle(Activity activity, EditText editText) {
        GradientDrawable backgroundDrawable = new GradientDrawable();
        backgroundDrawable.setShape(GradientDrawable.RECTANGLE);
        backgroundDrawable.setCornerRadius(dpToPx(activity, 10));

        backgroundDrawable.setStroke(dpToPx_int(activity, 1.5f), _current_edittext_stroke_);

        if (Color.luminance(_current_dialog_bg_) < 0.5) {
            backgroundDrawable.setColor(Color.argb(0x22, 0xFF, 0xFF, 0xFF));
        } else {
            backgroundDrawable.setColor(Color.argb(0x22, 0x00, 0x00, 0x00));
        }

        editText.setBackground(backgroundDrawable);
        editText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        editText.setTextColor(_current_edittext_text_);
        editText.setHintTextColor(_current_edittext_hint_);
        editText.setPadding(dpToPx_int(activity, 15), dpToPx_int(activity, 10), dpToPx_int(activity, 15), dpToPx_int(activity, 10));
    }


    @SuppressWarnings("deprecation")
    private static void checkAppVersionForForceUpdate(Activity activity) {
        if (activity == null || activity.isFinishing() || _pkg_ver_cfg_.isEmpty()) {
            _force_upd_req_ = false;
            return;
        }

        try {
            String pkgName = activity.getPackageName();
            if (_pkg_ver_cfg_.containsKey(pkgName)) {
                int requiredVersion = _pkg_ver_cfg_.get(pkgName);
                PackageInfo pkgInfo = activity.getPackageManager().getPackageInfo(pkgName, 0);
                int currentVersion = pkgInfo.versionCode;

                if (currentVersion < requiredVersion) {
                    _force_upd_req_ = true;
                } else {
                    _force_upd_req_ = false;
                }
            } else {
                _force_upd_req_ = false;
            }
        } catch (PackageManager.NameNotFoundException e) {
            _force_upd_req_ = false;
        }
    }

    private static void handleNeutralButtonAction(Activity activity, String actionContent) {
        if (activity == null || actionContent == null || actionContent.isEmpty()) {
            showToast(activity, isChinese(activity) ? "中立按钮链接未配置" : "Neutral button link not configured");
            return;
        }

        String[] parts = actionContent.split("=", 2);
        if (parts.length != 2) {
            showToast(activity, isChinese(activity) ? "中立按钮配置格式错误" : "Neutral button config format error");
            return;
        }

        String type = parts[0].trim();
        String target = parts[1].trim();
        boolean isChinese = isChinese(activity);

        try {
            switch (type) {
                case "网站":
                    String urlToOpen = convertToRawUrl(extractUrlFromHref(target));
                    if (!urlToOpen.isEmpty()) {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(urlToOpen));
                        activity.startActivity(intent);
                        showToast(activity, isChinese ? "正在打开网站..." : "Opening website...");
                    } else {
                        showToast(activity, isChinese ? "网站链接无效" : "Invalid website link");
                    }
                    break;
                case "QQ":
                    openQQ(activity, "聊天" + target);
                    showToast(activity, isChinese ? "正在打开QQ聊天..." : "Opening QQ chat...");
                    break;
                case "QQ群":
                    openQQ(activity, "群" + target);
                    showToast(activity, isChinese ? "正在打开QQ群..." : "Opening QQ group...");
                    break;
                default:
                    showToast(activity, isChinese ? "未知的中立按钮类型" : "Unknown neutral button type");
                    break;
            }
        } catch (ActivityNotFoundException e) {
            showToast(activity, isChinese ? "未安装QQ或无法打开链接" : "QQ not installed or failed to open link");
        } catch (Exception e) {
            showToast(activity, isChinese ? "打开链接失败" : "Failed to open link");
        }
    }

    private static void openQQ(Activity activity, String action) {
        try {
            String qq = action.substring(action.indexOf("=") + 1).trim();
            if (action.startsWith("个人")) {
                Intent intent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("mqqapi://card/show_pslcard?src_type=internal&uin=" + qq));
                activity.startActivity(intent);
            } else if (action.startsWith("群")) {
                Intent intent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("mqqapi://card/show_pslcard?src_type=internal&uin=" + qq + "&card_type=group"));
                activity.startActivity(intent);
            } else if (action.startsWith("聊天")) {
                Intent intent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("mqqwpa://im/chat?chat_type=wpa&uin=" + qq));
                activity.startActivity(intent);
            } else {
                Intent intent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("mqqwpa://im/chat?chat_type=wpa&uin=" + qq));
                activity.startActivity(intent);
            }
        } catch (ActivityNotFoundException e) {
            showToast(activity, activity.getResources().getConfiguration().getLocales().get(0).getLanguage().equals("zh") ? "未安装QQ" : "QQ not installed");
        } catch (Exception e) {
            showToast(activity, activity.getResources().getConfiguration().getLocales().get(0).getLanguage().equals("zh") ? "QQ操作失败: " + e.getMessage() : "QQ operation failed: " + e.getMessage());
        }
    }

    private static WindowManager.LayoutParams getDialogWindowAttributes(Activity activity, AlertDialog dialog) {
        WindowManager.LayoutParams windowAttributes = new WindowManager.LayoutParams();
        if (dialog.getWindow() != null) {
            windowAttributes.copyFrom(dialog.getWindow().getAttributes());
        }

        DisplayMetrics displayMetrics = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int screenWidth = displayMetrics.widthPixels;
        int screenHeight = displayMetrics.heightPixels;

        int orientation = activity.getResources().getConfiguration().orientation;

        if (orientation == Configuration.ORIENTATION_LANDSCAPE || _is_large_screen_) { // If in landscape or it's a large screen (tablet)
            windowAttributes.width = (int) (screenWidth * 0.85f); // 85% of landscape width
            windowAttributes.height = WindowManager.LayoutParams.WRAP_CONTENT;
        } else { // Portrait for phones
            windowAttributes.width = (int) (screenWidth * 0.9f); // 90% of portrait width
            windowAttributes.height = WindowManager.LayoutParams.WRAP_CONTENT;
        }

        windowAttributes.gravity = Gravity.CENTER;

        return windowAttributes;
    }


    interface ConfigLoadCallback {
        void onConfigLoaded(String configContent, String loadedFromUrl);

        void onConfigFailed();
    }

    interface InternetCheckCallback {
        void onInternetAvailable();

        void onInternetUnavailable();
    }

    @SuppressWarnings("deprecation")
    static class LoadConfigTask extends AsyncTask<Void, Void, String> {
        private final WeakReference<Activity> activityRef;
        private final ConfigLoadCallback callback;
        private final String domesticUrl;
        private final String internationalUrl;
        private String loadedFromUrl = null;

        LoadConfigTask(Activity activity, String domesticUrl, String internationalUrl, ConfigLoadCallback cb) {
            activityRef = new WeakReference<>(activity);
            callback = cb;
            this.domesticUrl = domesticUrl;
            this.internationalUrl = internationalUrl;
        }

        private String fetchConfig(String urlString) {
            if (urlString == null || urlString.trim().isEmpty()) {
                return null;
            }
            try {
                URL url = new URL(convertToRawUrl(urlString));
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout((int) _config_load_timeout_ms_);
                conn.setReadTimeout((int) _config_load_timeout_ms_);

                String userAgent = "Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_0 like Mac OS X; en-us) AppleWebKit/532.9 (KHTML, like Gecko) Version/4.0.5 Mobile/8A293 Safari/6531.22.7";
                if (_enable_rich_device_info_collection_) {
                    Activity activity = activityRef.get();
                    if (activity != null) {
                        userAgent += " (Moonlight-Device: " + getRichDeviceInfo(activity) + ")";
                    }
                }
                conn.setRequestProperty("User-Agent", userAgent);

                int responseCode = conn.getResponseCode();

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"))) {
                        StringBuilder sb = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) {
                            sb.append(line).append("\n");
                        }
                        String content = sb.toString();
                        try {
                            new JSONObject(content);
                            return content;
                        } catch (JSONException e) {
                            if (content.contains("〈配置版本〉") && content.contains("〈/配置版本〉")) {
                                return content;
                            } else {
                                return null;
                            }
                        }
                    }
                } else {
                    return null;
                }
            } catch (Exception e) {
                return null;
            }
        }

        @Override
        protected String doInBackground(Void... voids) {
            if (activityRef.get() == null || activityRef.get().isFinishing()) return null;

            String configContent = null;
            List<String> urlsToTry = new ArrayList<>();

            if (_enable_user_custom_url_ && _user_custom_urls_ != null && !_user_custom_urls_.isEmpty()) {
                String[] customUrls = _user_custom_urls_.split(",");
                for (String url : customUrls) {
                    if (!url.trim().isEmpty()) {
                        urlsToTry.add(url.trim());
                    }
                }
            }

            if (_force_use_domestic_url_ && domesticUrl != null && !domesticUrl.trim().isEmpty()) {
                if (!urlsToTry.contains(domesticUrl.trim())) urlsToTry.add(domesticUrl.trim());
            }
            if (_force_use_international_url_ && internationalUrl != null && !internationalUrl.trim().isEmpty()) {
                if (!urlsToTry.contains(internationalUrl.trim())) urlsToTry.add(internationalUrl.trim());
            }

            if (domesticUrl != null && !domesticUrl.trim().isEmpty() && !_force_use_international_url_ && !urlsToTry.contains(domesticUrl.trim())) {
                urlsToTry.add(domesticUrl.trim());
            }
            if (internationalUrl != null && !internationalUrl.trim().isEmpty() && !_force_use_domestic_url_ && !urlsToTry.contains(internationalUrl.trim())) {
                urlsToTry.add(internationalUrl.trim());
            }


            for (String url : urlsToTry) {
                if (url.trim().isEmpty()) continue;
                configContent = fetchConfig(url);
                if (configContent != null) {
                    loadedFromUrl = url;
                    return configContent;
                }
            }

            return null;
        }

        @Override
        protected void onPostExecute(String config) {
            Activity activity = activityRef.get();
            if (activity == null || activity.isFinishing()) return;
            if (callback != null) {
                if (config != null && !config.isEmpty()) {
                    callback.onConfigLoaded(config, loadedFromUrl);
                } else {
                    callback.onConfigFailed();
                }
            }
        }
    }

    @SuppressWarnings("deprecation")
    static class CheckInternetTask extends AsyncTask<Void, Void, Boolean> {
        private final WeakReference<Activity> activityRef;
        private final InternetCheckCallback callback;

        CheckInternetTask(Activity activity, InternetCheckCallback cb) {
            activityRef = new WeakReference<>(activity);
            callback = cb;
        }

        @Override
        protected Boolean doInBackground(Void... voids) {
            Activity act = activityRef.get();
            if (act == null || act.isFinishing()) return false;

            try {
                String[] endpoints = {
                        "https://www.baidu.com",
                        "https://cn.bing.com",
                        "https://www.google.com",
                        "https://1.1.1.1",
                        "https://8.8.8.8"
                };

                for (String endpoint : endpoints) {
                    try {
                        HttpURLConnection conn = (HttpURLConnection) new URL(endpoint).openConnection();
                        conn.setRequestMethod("HEAD");
                        conn.setConnectTimeout((int) _config_load_timeout_ms_ / 2);
                        conn.setReadTimeout((int) _config_load_timeout_ms_ / 2);

                        String userAgent = "Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_0 like Mac OS X; en-us) AppleWebKit/532.9 (KHTML, like Gecko) Version/4.0.5 Mobile/8A293 Safari/6531.22.7";
                        if (_enable_rich_device_info_collection_) {
                            userAgent += " (Moonlight-Device: " + getRichDeviceInfo(act) + ")";
                        }
                        conn.setRequestProperty("User-Agent", userAgent);

                        int responseCode = conn.getResponseCode();
                        conn.disconnect();

                        if (responseCode == HttpURLConnection.HTTP_OK ||
                                responseCode == HttpURLConnection.HTTP_NO_CONTENT ||
                                (responseCode >= 200 && responseCode < 400)) {
                            return true;
                        }
                    } catch (IOException e) {
                    }
                }
                return false;
            } catch (Exception e) {
                return false;
            }
        }

        @Override
        protected void onPostExecute(Boolean isConnected) {
            Activity activity = activityRef.get();
            if (activity == null || activity.isFinishing()) return;
            if (callback == null) return;
            if (isConnected) {
                callback.onInternetAvailable();
            } else {
                callback.onInternetUnavailable();
            }
        }
    }
}