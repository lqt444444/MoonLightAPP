package bbs.yuchen.icu;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

// Note: For image loading from a URL, you should add a library like Glide or Picasso.
// Example with Glide: implementation 'com.github.bumptech.glide:glide:4.12.0'
// import com.bumptech.glide.Glide;

public class SplashActivity extends Activity {

    private static final String TAG = "CloudInjectSplash";
    private String configResult = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // You would typically have a layout file for your splash screen.
        // For simplicity, we'll assume a basic layout with an ImageView and ProgressBar.
        // setContentView(R.layout.activity_splash);

        // For this example, we create a simple view programmatically.
        ProgressBar progressBar = new ProgressBar(this);
        setContentView(progressBar);

        // Start fetching the configuration from the server.
        fetchRemoteConfig();
    }

    private void fetchRemoteConfig() {
        new AsyncTask<Void, Void, String>() {
            @Override
            protected String doInBackground(Void... voids) {
                // This logic is moved from MainActivity
                String queryParams = "api_version=1.0"
                        + "&app_id=" + MainActivity.APP_ID
                        + "&app_version=2.3" // Replace with dynamic version name
                        + "&device_code=" + android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.ANDROID_ID)
                        + "&lang=zh&platform=2&region=CN&version_code=23"; // Replace with dynamic version code

                JSONObject response = performRequestWithFailover(MainActivity.CONFIG_PATH, queryParams);
                return (response != null) ? response.toString() : null;
            }

            @Override
            protected void onPostExecute(String jsonResult) {
                if (jsonResult == null) {
                    Toast.makeText(SplashActivity.this, "网络配置加载失败，请检查网络后重试", Toast.LENGTH_LONG).show();
                    // You might want to add a retry button or exit after a timeout.
                    new Handler(Looper.getMainLooper()).postDelayed(() -> finish(), 3000);
                    return;
                }

                configResult = jsonResult; // Store the result

                try {
                    JSONObject result = new JSONObject(jsonResult).optJSONObject("result");
                    if (result == null) {
                        navigateToMain(); // Invalid result, proceed anyway
                        return;
                    }

                    JSONObject splashConfig = result.optJSONObject("splash");
                    // If splash config exists and has a URL, show it.
                    if (splashConfig != null && splashConfig.has("url")) {
                        displaySplashScreen(splashConfig);
                    } else {
                        navigateToMain(); // No splash, go directly to main.
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    navigateToMain(); // Error parsing, go to main.
                }
            }
        }.execute();
    }

    private void displaySplashScreen(JSONObject splashConfig) {
        // Here you would inflate your splash layout which contains an ImageView
        // ImageView splashImageView = findViewById(R.id.splashImageView);
        ImageView splashImageView = new ImageView(this);
        splashImageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        setContentView(splashImageView);

        String imageUrl = splashConfig.optString("url");
        long duration = splashConfig.optInt("second", 3) * 1000L;

        // Use a library like Glide to load the image
        // Glide.with(this).load(imageUrl).into(splashImageView);

        // Placeholder for image loading
        Toast.makeText(this, "加载启动图中...", Toast.LENGTH_SHORT).show();


        final int actionType = splashConfig.optInt("actionType");
        final String actionExt = splashConfig.optString("actionExt");

        splashImageView.setOnClickListener(v -> {
            if(actionExt != null && !actionExt.isEmpty()) {
                 MainActivity.handleButtonAction(this, actionType, actionExt);
            }
        });

        // After the specified duration, navigate to MainActivity
        new Handler(Looper.getMainLooper()).postDelayed(this::navigateToMain, duration);
    }

    private void navigateToMain() {
        Intent intent = new Intent(SplashActivity.this, MainActivity.class);
        intent.putExtra("remote_config", configResult);
        startActivity(intent);
        finish(); // Close the splash activity
    }

    // This helper method is also moved from MainActivity
    // CHANGE: Was 'private', now 'public' to allow access from MainActivity.
    public static JSONObject performRequestWithFailover(String path, String queryParams) {
        final String[] DOMESTIC_HOSTS = {"360stop.org", "360mixup.com"};
        final String[] INTERNATIONAL_HOSTS = {"checksum.cc", "360stat.org"};
        List<String> hosts = new ArrayList<>(Arrays.asList(DOMESTIC_HOSTS));
        hosts.addAll(Arrays.asList(INTERNATIONAL_HOSTS));

        for (String host : hosts) {
            try {
                URL url = new URL("https://" + host + path + "?" + queryParams);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);
                conn.connect();

                if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    InputStream in = conn.getInputStream();
                    StringBuilder sb = new StringBuilder();
                    byte[] buffer = new byte[1024];
                    int len;
                    while ((len = in.read(buffer)) != -1) {
                        sb.append(new String(buffer, 0, len));
                    }
                    in.close();
                    return new JSONObject(sb.toString());
                }
            } catch (Exception e) {
                Log.e(TAG, "Error connecting to host " + host, e);
            }
        }
        return null;
    }
}