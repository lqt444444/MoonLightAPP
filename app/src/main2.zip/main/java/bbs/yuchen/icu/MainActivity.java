package bbs.yuchen.icu;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * 云注入模块 - v6.5 Feature Complete
 * 版本: 6.5
 * 功能说明:
 * 1. 启动图广告
 * 2. 应用绑定检测
 * 3. 版本更新
 * 4. 分享解锁
 * 5. 远程弹窗
 * 6. 公告与智能提醒
 * 7. 卡密注册/验证
 */
public class MainActivity extends Activity {

    public static final String APP_ID = "7373e57dbfdeb0a00000242d50cf1f95";
    public static final String PREF_NAME = "cloudinject_config";
    public static final String KEY_SECRET = "saved_secret";
    public static final String KEY_LAST_NOTICE_HASH = "last_notice_hash";
    public static final String KEY_SHARE_COUNT = "share_count"; // For Share to Unlock

    // API Paths
    public static final String CONFIG_PATH = "/feature/config";
    public static final String VERIFY_PATH = "/feature/pack/verify";

    private JSONObject configResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // A simple welcome text. Real UI should be inflated from a layout.
        LinearLayout layout = new LinearLayout(this);
        android.widget.TextView tv = new android.widget.TextView(this);
        tv.setText("欢迎使用！");
        tv.setPadding(50, 50, 50, 50);
        layout.addView(tv);
        setContentView(layout);

        // MainActivity no longer fetches the config. It receives it from SplashActivity.
        String configJsonString = getIntent().getStringExtra("remote_config");
        if (configJsonString == null) {
            Toast.makeText(this, "应用配置错误，无法启动", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        try {
            this.configResult = new JSONObject(configJsonString).optJSONObject("result");
            if (this.configResult == null) {
                // Config is empty but valid, app can run without features.
                return;
            }
            // Start the sequential check of all features.
            startFeatureChecks();
        } catch (Exception e) {
            Toast.makeText(this, "配置解析失败", Toast.LENGTH_LONG).show();
            e.printStackTrace();
            finish();
        }
    }

    /**
     * Orchestrates the sequential checking of each remote feature.
     * Each check function returns 'true' if it displays a blocking UI,
     * which halts the execution of subsequent checks.
     */
    private void startFeatureChecks() {
        if (checkAppBinding(configResult.optJSONObject("bind"))) return;
        if (checkVersionUpdate(configResult.optJSONObject("version"))) return;
        if (checkShareToUnlock(configResult.optJSONObject("share"))) return;
        if (checkOnlineDialog(configResult.optJSONObject("onlineDialog"))) return;
        if (checkNotice(configResult.optJSONObject("notice"))) return;
        
        // If all other checks pass, finally check for registration.
        checkRegistration(configResult.optJSONObject("register"));
    }

    // 1. App Binding Check
    private boolean checkAppBinding(JSONObject bindConfig) {
        if (bindConfig == null) return false;

        JSONArray rules = bindConfig.optJSONArray("data");
        if (rules == null) return false;

        PackageManager pm = getPackageManager();
        for (int i = 0; i < rules.length(); i++) {
            JSONObject rule = rules.optJSONObject(i);
            String packageName = rule.optString("packageName");
            if (isPackageInstalled(pm, packageName)) {
                showGenericDialog(this, rule, () -> {
                    // After dialog is dismissed, if it's not an exiting action, re-check everything.
                    if (rule.optInt("actionType") != 3) startFeatureChecks();
                });
                return true; // A binding was found, show dialog and stop further checks.
            }
        }
        return false;
    }

    private boolean isPackageInstalled(PackageManager pm, String packageName) {
        if (packageName == null || packageName.isEmpty()) return false;
        try {
            pm.getPackageInfo(packageName, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    // 2. Version Update Check
    private boolean checkVersionUpdate(JSONObject versionConfig) {
        if (versionConfig == null) return false;
        // The presence of the 'version' object implies an update is needed.
        showGenericDialog(this, versionConfig, () -> {
            if (versionConfig.optInt("forceType") == 1) {
                finish(); // Exit if it's a forced update and user cancels.
            } else {
                startFeatureChecks(); // Re-check if not forced.
            }
        });
        return true; // Update dialog shown, stop further checks.
    }

    // 3. Share to Unlock Check
    private boolean checkShareToUnlock(JSONObject shareConfig) {
        if (shareConfig == null) return false;

        SharedPreferences sp = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        int requiredCount = shareConfig.optInt("shareCount", 1);
        int currentCount = sp.getInt(KEY_SHARE_COUNT, 0);

        if (currentCount >= requiredCount) {
            return false; // Already unlocked.
        }

        // Prepare the dialog message
        String messageTemplate = shareConfig.optString("message", "需要分享 #{count} 次才能使用");
        String message = messageTemplate.replace("#{count}", String.valueOf(currentCount));
        
        try {
            // Create a mutable copy to replace the message
            JSONObject dialogConfig = new JSONObject(shareConfig.toString());
            dialogConfig.put("message", message);
            // Add a "Share" button, using the positive button slot.
            dialogConfig.put("positiveText", "立即分享");
            dialogConfig.put("actionType", 4); // ActionType 4 for sharing
            dialogConfig.put("ext", dialogConfig.optString("shareContent"));

            showGenericDialog(this, dialogConfig, this::finish); // Exit if user cancels
            return true; // Share dialog is shown, stop other checks.
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // 4. Remote Dialog Check ("清羽远程弹窗")
    private boolean checkOnlineDialog(JSONObject dialogConfig) {
        if (dialogConfig == null || dialogConfig.optString("content").isEmpty()) {
            return false;
        }
        // This feature has a simple structure, so we build the dialog directly.
        new AlertDialog.Builder(this)
                .setTitle("提示")
                .setMessage(dialogConfig.optString("content"))
                .setPositiveButton("确定", (d, w) -> startFeatureChecks()) // Continue chain on dismiss
                .setCancelable(false)
                .show();
        return true;
    }

    // 5. Notice Check (with Smart Reminder)
    private boolean checkNotice(JSONObject noticeConfig) {
        if (noticeConfig == null) return false;

        boolean isAutoTips = noticeConfig.optInt("autoTips", 0) == 1;
        int showType = noticeConfig.optInt("showType", 0);
        String message = noticeConfig.optString("message", "");

        SharedPreferences sp = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        int lastNoticeHash = sp.getInt(KEY_LAST_NOTICE_HASH, 0);
        int currentNoticeHash = message.hashCode();

        if (isAutoTips && showType == 1 && !message.isEmpty() && currentNoticeHash != lastNoticeHash) {
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
            sp.edit().putInt(KEY_LAST_NOTICE_HASH, currentNoticeHash).apply();
            return false; // Toast is not blocking, continue checks.
        } else {
            // Show the standard dialog which is blocking.
            final String savedSecret = sp.getString(KEY_SECRET, null);
            showNoticeDialog(this, noticeConfig, configResult.optJSONObject("register"), savedSecret);
            return true; // Dialog is blocking.
        }
    }

    // 6. Registration Check
    private void checkRegistration(JSONObject registerConfig) {
        if (registerConfig == null) { // No registration required
            // If we've reached here without needing registration, check for a saved secret to welcome back user.
            final String savedSecret = getSharedPreferences(PREF_NAME, MODE_PRIVATE).getString(KEY_SECRET, null);
            if(savedSecret != null){
                showSuccessDialog(this, "欢迎回来");
            }
            return;
        };

        final String savedSecret = getSharedPreferences(PREF_NAME, MODE_PRIVATE).getString(KEY_SECRET, null);
        if (savedSecret != null) {
            verifySavedSecret(this, savedSecret);
        } else {
            showRegisterDialog(this, registerConfig);
        }
    }

    // --- DIALOG AND ACTION HANDLERS ---

    /**
     * A generic dialog builder for features like AppBinding, VersionUpdate, Share.
     * @param activity The context
     * @param config The JSONObject for the dialog configuration
     * @param onCancelAction A runnable to execute if the dialog is canceled.
     */
    public static void showGenericDialog(final Activity activity, final JSONObject config, final Runnable onCancelAction) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle(config.optString("title", "提示"));
        builder.setMessage(config.optString("message"));

        // Positive Button
        String positiveText = config.optString("positiveText", "确定");
        if(!positiveText.isEmpty()){
             builder.setPositiveButton(positiveText, (dialog, which) -> 
                handleButtonAction(activity, config.optInt("actionType"), config.optString("ext", config.optString("positiveExt"))));
        }
       
        // Negative Button
        String cancelText = config.optString("cancelText");
        if (cancelText != null && !cancelText.isEmpty()) {
            builder.setNegativeButton(cancelText, (dialog, which) -> 
                handleButtonAction(activity, config.optInt("cancelActionType"), config.optString("cancelExt")));
        }

        // Neutral Button
        String neutralText = config.optString("neutralText");
        if (neutralText != null && !neutralText.isEmpty()) {
            builder.setNeutralButton(neutralText, (dialog, which) -> 
                handleButtonAction(activity, config.optInt("neutralActionType"), config.optString("neutralExt")));
        }
        
        builder.setCancelable(config.optInt("forceType", 0) == 0);
        builder.setOnCancelListener(dialog -> {
            if (onCancelAction != null) onCancelAction.run();
        });

        builder.show();
    }

    /**
     * Universal handler for button actions.
     * @param actionType 1=QQ, 2=Browser, 3=Exit, 4=Share, etc.
     * @param ext Extra data (URL, QQ group number, share content)
     */
    public static void handleButtonAction(Activity activity, int actionType, String ext) {
        try {
            switch (actionType) {
                case 1: // Join QQ Group
                    activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("mqqapi://card/show_pslcard?src_type=internal&version=1&uin=" + ext + "&card_type=group&source=qrcode")));
                    break;
                case 2: // Open Browser
                     activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(ext)));
                    break;
                case 3: // Exit App
                    activity.finish();
                    System.exit(0);
                    break;
                case 4: // Share
                    // After sharing, we should increment the count.
                    SharedPreferences sp = activity.getSharedPreferences(PREF_NAME, MODE_PRIVATE);
                    int currentCount = sp.getInt(KEY_SHARE_COUNT, 0);
                    sp.edit().putInt(KEY_SHARE_COUNT, currentCount + 1).apply();

                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.setType("text/plain");
                    shareIntent.putExtra(Intent.EXTRA_TEXT, ext);
                    activity.startActivity(Intent.createChooser(shareIntent, "分享"));
                    Toast.makeText(activity, "分享已记录，请重启应用查看效果", Toast.LENGTH_LONG).show();
                    activity.finish(); // Force restart to re-check share count.
                    break;
                 case 0: // No action
                 default:
                    // Do nothing
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(activity, "操作失败", Toast.LENGTH_SHORT).show();
        }
    }

    // --- Existing Dialogs (Notice, Register, etc.) ---
    // These methods are mostly unchanged but are included for completeness.

    public static void showNoticeDialog(final Activity activity, final JSONObject notice, final JSONObject register, final String savedSecret) {
        // This method can now be simplified by using showGenericDialog, but we keep it separate for clarity.
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle(notice.optString("title", "提示"));
        builder.setMessage(notice.optString("message", ""));

        builder.setPositiveButton(notice.optString("positiveText", "确定"), (d, w) -> {
            handleButtonAction(activity, notice.optInt("actionType"), notice.optString("ext"));
            // After handling notice, proceed to registration check
            ((MainActivity)activity).checkRegistration(register);
        });

        String cancelText = notice.optString("cancelText");
        if (cancelText != null && !cancelText.isEmpty()) {
            builder.setNegativeButton(cancelText, (d,w) -> {
                handleButtonAction(activity, notice.optInt("cancelActionType"), notice.optString("cancelExt"));
                if(notice.optInt("forceType") == 1) activity.finish();
            });
        }
        
        builder.setCancelable(notice.optInt("forceType", 0) == 0);
        builder.setOnCancelListener(dialog -> {
            if(notice.optInt("forceType") == 1) activity.finish();
        });
        
        builder.show();
    }

    public static void showRegisterDialog(final Activity activity, final JSONObject register) {
        // This dialog is unique and remains custom.
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle(register.optString("message", "卡密验证"));

        final EditText input = new EditText(activity);
        input.setHint("请输入卡密");
        LinearLayout layout = new LinearLayout(activity);
        layout.setPadding(48, 24, 48, 0);
        layout.addView(input, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        builder.setView(layout);
        
        builder.setPositiveButton(register.optString("useText", "确定"), null); // Set null listener to override later

        String cancelText = register.optString("cancelText");
        if (cancelText != null && !cancelText.isEmpty()) {
            builder.setNegativeButton(cancelText, (d,w) -> handleButtonAction(activity, register.optInt("cancelActionType"), register.optString("cancelExt")));
        }

        String neutralText = register.optString("neutralText");
        if (neutralText != null && !neutralText.isEmpty()) {
            builder.setNeutralButton(neutralText, (d,w) -> handleButtonAction(activity, register.optInt("neutralActionType"), register.optString("neutralExt")));
        }

        builder.setCancelable(false);
        final AlertDialog dialog = builder.create();

        dialog.setOnShowListener(di -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String secret = input.getText().toString().trim();
                if (!secret.isEmpty()) {
                    verifySecret(activity, secret, dialog);
                } else {
                    Toast.makeText(activity, "请输入卡密", Toast.LENGTH_SHORT).show();
                }
            });
        });
        dialog.show();
    }

    public static void verifySecret(final Activity activity, final String secret, final AlertDialog dialogToDismiss) {
        // This is an async network call.
        new AsyncTask<Void, Void, JSONObject>() {
             protected JSONObject doInBackground(Void... params) {
                final String deviceCode = Settings.Secure.getString(activity.getContentResolver(), Settings.Secure.ANDROID_ID);
                String queryParams = "api_version=1.0&app_id=" + APP_ID + "&app_version=2.3&device_code=" + deviceCode + "&lang=zh&platform=2&region=CN&version_code=23&secret=" + secret;
                return SplashActivity.performRequestWithFailover(VERIFY_PATH, queryParams);
             }
             protected void onPostExecute(JSONObject response) {
                if (response == null) {
                    Toast.makeText(activity, "网络异常", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (response.optInt("status", 0) == 1) {
                    SharedPreferences sp = activity.getSharedPreferences(PREF_NAME, MODE_PRIVATE);
                    sp.edit().putString(KEY_SECRET, secret).apply();
                    if (dialogToDismiss != null) dialogToDismiss.dismiss();
                    showSuccessDialog(activity, response.optJSONObject("result").optString("msg", "验证成功"));
                } else {
                    String msg = response.optJSONObject("result").optString("msg", "验证失败");
                    Toast.makeText(activity, msg, Toast.LENGTH_LONG).show();
                }
             }
         }.execute();
    }
    
    public static void verifySavedSecret(final Activity activity, final String secret) {
        new AsyncTask<Void, Void, JSONObject>() {
            protected JSONObject doInBackground(Void... params) {
               final String deviceCode = Settings.Secure.getString(activity.getContentResolver(), Settings.Secure.ANDROID_ID);
               String queryParams = "api_version=1.0&app_id=" + APP_ID + "&app_version=2.3&device_code=" + deviceCode + "&lang=zh&platform=2&region=CN&version_code=23&secret=" + secret;
               return SplashActivity.performRequestWithFailover(VERIFY_PATH, queryParams);
            }
            protected void onPostExecute(JSONObject response) {
               if (response == null) {
                   Toast.makeText(activity, "网络异常, 自动登录失败", Toast.LENGTH_SHORT).show();
                   ((MainActivity)activity).checkRegistration(((MainActivity)activity).configResult.optJSONObject("register"));
                   return;
               }
               if (response.optInt("status", 0) == 1) {
                   showSuccessDialog(activity, response.optJSONObject("result").optString("msg", "自动登录成功"));
               } else {
                   SharedPreferences sp = activity.getSharedPreferences(PREF_NAME, MODE_PRIVATE);
                   sp.edit().remove(KEY_SECRET).apply();
                   Toast.makeText(activity, "卡密已失效, 请重新验证", Toast.LENGTH_LONG).show();
                   showRegisterDialog(activity, ((MainActivity)activity).configResult.optJSONObject("register"));
               }
            }
        }.execute();
    }

    public static void showSuccessDialog(Activity activity, String msg) {
        new AlertDialog.Builder(activity)
            .setTitle("提示")
            .setMessage(msg)
            .setPositiveButton("确定", null)
            .show();
    }
}