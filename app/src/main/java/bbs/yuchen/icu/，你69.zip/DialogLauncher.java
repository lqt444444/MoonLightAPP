
package bbs.yuchen.icu;

import android.app.Activity;


public class DialogLauncher {

    public static void Thrym(final Activity activity) {
        // Example: Using a domestic URL and an international URL
        String domesticConfigUrl = "https://sharechain.qq.com/73966a9210eed1a494bad966f4c390ab"; // Your existing URL
        String internationalConfigUrl = "https://gitee.com/milk-meow-sauce_admin/test/issues/IC6VSZ"; // Example GitHub raw link for international

        // Keep your original Moonlight.init() logic
       // 初始化云注入模块
       // Moonlight.init(activity, domesticConfigUrl, internationalConfigUrl);
        Moonlightinjection.init(activity, domesticConfigUrl, internationalConfigUrl);
        }
}
 