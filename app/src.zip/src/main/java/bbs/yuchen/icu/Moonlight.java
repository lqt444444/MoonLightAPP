package bbs.yuchen.icu;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.animation.ObjectAnimator;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Moonlight {

    private static final String TAG = "Moonlight";
    
    // 添加配置URL变量和设置方法
    private static String configUrl = "https://sharechain.qq.com/8cc308a15a2d0b7747e0bd2a588ac82e";
    
    public static void setConfigUrl(String url) {
        configUrl = url;
    }

    // 动态内容，从网络配置获取
    private static String 动态内容 = "内容加载中...";
    // 强制更新的下载链接
    private static String 强制更新链接 = "";
    // TG频道链接
    private static String TG频道链接 = "https://t.me/your_channel";
    // QQ群号
    private static String QQ群号 = "";
    // 弹窗的标题
    private static String 弹窗标题 = "Moonlight";
    // 强制更新弹窗的内容
    private static String 强制更新内容 = "当前版本已过期，请更新到最新版本";
    // 更新日志内容
    private static String 更新日志 = "暂无更新日志";
    // 配置文件的版本号
    private static String 配置版本 = "1.0";
    // 包名和最低版本号的映射，用于强制更新检查
    private static Map<String, Integer> 包名版本配置 = new HashMap<>();
    // 是否需要强制更新的标志，由版本检查结果决定
    private static boolean 需要强制更新 = false;
    // 网络配置的总开关
    private static boolean 网络配置总开关 = true;
    // 是否显示动态内容的开关
    private static boolean 显示动态内容开关 = true;
    // 是否显示更新日志的开关
    private static boolean 显示更新日志开关 = true;
    // 是否重置"不再提示"设置的开关
    private static boolean 重置不再提示 = false;
    // 是否启用 Moonlight 图片旋转的开关
    private static boolean 启用Moonlight图旋转 = true;

    // 普通弹窗相关开关
    private static boolean 启用普通弹窗 = true;
    private static boolean 显示关闭弹窗按钮 = true;
    private static boolean 显示不再提示按钮 = true;
    private static boolean 显示QQ群按钮 = true;
    private static boolean 显示TG频道按钮 = true;
    private static boolean 启用外部点击消失 = true;

    // 默认颜色值
    private static final int 默认主色调 = 0xFFB0C4DE; // LightSteelBlue
    private static final int 默认文字颜色 = 0xFF191970; // MidnightBlue

    // 从网络配置获取的颜色值
    private static int 网络主色调 = 默认主色调;
    private static int 网络文字颜色 = 默认文字颜色;
    private static int 网络按钮颜色 = 默认主色调; // 新增：按钮颜色

    // 使用 WeakReference 跟踪当前显示弹窗的 Activity 实例
    private static WeakReference<Activity> sShowingActivityRef = null;

    /**
     * 显示 Moonlight 弹窗
     * 应在 Activity 的 onCreate 和 onResume 方法中调用。
     *
     * @param activity 要显示弹窗的 Activity
     */
    public static void 弹窗(final Activity activity) {
        // 检查 Activity 是否有效或正在结束
        if (activity == null || activity.isFinishing()) {
            Log.e(TAG, "Activity为空或正在结束，无法显示弹窗");
            return;
        }

        // 获取当前正在显示弹窗的 Activity 实例
        Activity showingActivity = sShowingActivityRef != null ? sShowingActivityRef.get() : null;

        // 如果有 Activity 正在显示弹窗，并且是同一个 Activity 实例，则忽略新的请求
        if (showingActivity != null && showingActivity == activity) {
            Log.d(TAG, "弹窗已在显示，忽略新请求 for this activity instance");
            return;
        }

        // 更新 WeakReference 为当前 Activity
        sShowingActivityRef = new WeakReference<>(activity);
        Log.d(TAG, "新的弹窗请求，更新显示弹窗的 Activity 引用");

        // 重置网络配置变量为默认值（除了需要强制更新）
        resetNetworkConfigsToDefaultExceptForcedUpdate();

        if (需要强制更新) {
            Log.d(TAG, "当前需要强制更新，直接显示强制更新弹窗");
            showForceUpdateDialog(activity);
            return;
        }

        if (重置不再提示) {
            SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(activity);
            prefs.edit().remove("0").remove("dialogVer").apply();
            Log.d(TAG, "已重置不再提示偏好设置");
        }

        if (网络配置总开关) {
            new LoadConfigFromQQTask(activity, new ConfigLoadCallback() {
                @Override
                public void onConfigLoaded() {
                    new CheckPackageAndVersionTask(activity, new VersionCheckCallback() {
                        @Override
                        public void onVersionValid() {
                            new CheckInternetTask(activity, new InternetCheckCallback() {
                                @Override
                                public void onInternetAvailable() {
                                    if (启用普通弹窗) {
                                        originalPopupLogic(activity);
                                    } else {
                                        Log.d(TAG, "普通弹窗已禁用，跳过显示");
                                        sShowingActivityRef = null;
                                    }
                                }

                                @Override
                                public void onInternetUnavailable() {
                                    sShowingActivityRef = null;
                                    Toast.makeText(activity, "未连接互联网", Toast.LENGTH_SHORT).show();
                                }
                            }).execute();
                        }

                        @Override
                        public void onVersionOutdated() {
                            需要强制更新 = true;
                            showForceUpdateDialog(activity);
                        }
                    }).execute();
                }

                @Override
                public void onConfigFailed() {
                    sShowingActivityRef = null;
                    Toast.makeText(activity, "使用默认配置", Toast.LENGTH_SHORT).show();
                    new CheckPackageAndVersionTask(activity, new VersionCheckCallback() {
                        @Override
                        public void onVersionValid() {
                            if (启用普通弹窗) {
                                originalPopupLogic(activity);
                            } else {
                                Log.d(TAG, "普通弹窗已禁用（配置加载失败），跳过显示");
                            }
                        }

                        @Override
                        public void onVersionOutdated() {
                            需要强制更新 = true;
                            showForceUpdateDialog(activity);
                        }
                    }).execute();
                }
            }).execute();
        } else {
            new CheckPackageAndVersionTask(activity, new VersionCheckCallback() {
                @Override
                public void onVersionValid() {
                    if (启用普通弹窗) {
                        originalPopupLogic(activity);
                    } else {
                        Log.d(TAG, "普通弹窗已禁用（网络配置总开关关闭），跳过显示");
                    }
                }

                @Override
                public void onVersionOutdated() {
                    需要强制更新 = true;
                    showForceUpdateDialog(activity);
                }
            }).execute();
        }
    }

    /**
     * 将所有网络配置相关的变量重置为默认值，除了 需要强制更新
     */
    private static void resetNetworkConfigsToDefaultExceptForcedUpdate() {
        动态内容 = "内容加载中...";
        强制更新链接 = "";
        TG频道链接 = "https://t.me/your_channel";
        QQ群号 = "";
        弹窗标题 = "Moonlight";
        强制更新内容 = "当前版本已过期，请更新到最新版本";
        更新日志 = "暂无更新日志";
        配置版本 = "1.0";
        包名版本配置 = new HashMap<>();
        网络配置总开关 = true;
        显示动态内容开关 = true;
        显示更新日志开关 = true;
        重置不再提示 = false;
        启用Moonlight图旋转 = true;
        启用普通弹窗 = true;
        显示关闭弹窗按钮 = true;
        显示不再提示按钮 = true;
        显示QQ群按钮 = true;
        显示TG频道按钮 = true;
        启用外部点击消失 = true;
        网络主色调 = 默认主色调;
        网络文字颜色 = 默认文字颜色;
        网络按钮颜色 = 默认主色调; // 重置按钮颜色
        Log.d(TAG, "所有网络配置变量已重置为默认值 (需要强制更新除外)");
    }

    /**
     * 将十六进制颜色字符串解析为整数颜色值
     */
    private static int parseColor(String colorString) {
        try {
            return Color.parseColor(colorString);
        } catch (IllegalArgumentException e) {
            Log.e(TAG, "无效的颜色字符串: " + colorString, e);
            return 默认文字颜色;
        }
    }

    /**
     * 计算稍暗的颜色用于描边
     */
    private static int darkenColor(int color) {
        float[] hsv = new float[3];
        Color.colorToHSV(color, hsv);
        hsv[2] *= 0.8f; // 降低亮度
        return Color.HSVToColor(hsv);
    }

    /**
     * 按钮背景样式 1：顶部圆角
     */
    private static Drawable buttonback1() {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(GradientDrawable.RECTANGLE);
        gradientDrawable.setCornerRadii(new float[]{70.0f, 70.0f, 70.0f, 70.0f, 0.0f, 0.0f, 0.0f, 0.0f});
        gradientDrawable.setColor(网络按钮颜色);
        gradientDrawable.setStroke(2, darkenColor(网络按钮颜色)); // 添加2像素描边
        return gradientDrawable;
    }

    /**
     * 按钮背景样式 2：无圆角
     */
    private static Drawable buttonback2() {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(GradientDrawable.RECTANGLE);
        gradientDrawable.setCornerRadii(new float[]{0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f});
        gradientDrawable.setColor(网络按钮颜色);
        gradientDrawable.setStroke(2, darkenColor(网络按钮颜色)); // 添加2像素描边
        return gradientDrawable;
    }

    /**
     * 按钮背景样式 4：底部圆角
     */
    private static Drawable buttonback4() {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(GradientDrawable.RECTANGLE);
        gradientDrawable.setCornerRadii(new float[]{0.0f, 0.0f, 0.0f, 0.0f, 70.0f, 70.0f, 70.0f, 70.0f});
        gradientDrawable.setColor(网络按钮颜色);
        gradientDrawable.setStroke(2, darkenColor(网络按钮颜色)); // 添加2像素描边
        return gradientDrawable;
    }

    /**
     * 异步任务：从网络加载配置信息
     */
    private static class LoadConfigFromQQTask extends AsyncTask<Void, Void, Boolean> {
        private WeakReference<Activity> activityWeakReference;
        private ConfigLoadCallback callback;

        LoadConfigFromQQTask(Activity activity, ConfigLoadCallback callback) {
            activityWeakReference = new WeakReference<>(activity);
            this.callback = callback;
        }

        @Override
        protected Boolean doInBackground(Void... voids) {
            Activity activity = activityWeakReference.get();
            if (activity == null || activity.isFinishing()) {
                Log.d(TAG, "LoadConfigFromQQTask doInBackground: Activity is null or finishing.");
                return false;
            }

            String config = null;
            try {
                // 使用设置的 configUrl
                URL url = new URL(configUrl);
                Log.d(TAG, "LoadConfigFromQQTask accessing URL: " + url.toString());
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(8000);
                connection.setReadTimeout(8000);
                connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36");

                InputStream inputStream = connection.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line).append("\n");
                }
                reader.close();
                connection.disconnect();

                config = response.toString();
                Log.d(TAG, "LoadConfigFromQQTask Raw Response:\n" + config);

                // Enhanced cleaning of the response
                config = config.replaceAll("\\\\\"", "\"")
                        .replaceAll("\\\\u003C", "<")
                        .replaceAll("\\\\u003E", ">")
                        .replaceAll("\\\\n", "\n")
                        .replaceAll("<br\\s*/>", "<br>")
                        .replaceAll("</div><div>", "<br>")
                        .replaceAll("</p><p>", "<br>")
                        .replaceAll("<[^>]+>", "") // Remove all HTML tags
                        .replaceAll(" ", " ")
                        .replaceAll("&", "&")
                        .replaceAll("\\\\", "");

                Log.d(TAG, "LoadConfigFromQQTask After cleaning:\n" + config);

                // Helper method to extract content between tags with a fallback
                Pattern contentPattern = Pattern.compile("【内容】(.*?)【/内容】", Pattern.DOTALL);
                Matcher contentMatcher = contentPattern.matcher(config);
                if (contentMatcher.find()) {
                    动态内容 = contentMatcher.group(1).trim();
                    Log.d(TAG, "Matched 【内容】: " + 动态内容);
                } else {
                    动态内容 = "欢迎使用本应用（内容未加载）";
                    Log.w(TAG, "【内容】 not found, using default");
                }

                Pattern updatePattern = Pattern.compile("【更新链接】(.*?)【/更新链接】", Pattern.DOTALL);
                Matcher updateMatcher = updatePattern.matcher(config);
                if (updateMatcher.find()) {
                    强制更新链接 = updateMatcher.group(1).trim();
                    Log.d(TAG, "Matched 【更新链接】: " + 强制更新链接);
                }

                Pattern tgPattern = Pattern.compile("【TG频道】(.*?)【/TG频道】", Pattern.DOTALL);
                Matcher tgMatcher = tgPattern.matcher(config);
                if (tgMatcher.find()) {
                    TG频道链接 = tgMatcher.group(1).trim();
                    Log.d(TAG, "Matched 【TG频道】: " + TG频道链接);
                    if (!TG频道链接.startsWith("https://") && !TG频道链接.startsWith("tg://")) {
                        if (TG频道链接.startsWith("@")) {
                            TG频道链接 = "https://t.me/" + TG频道链接.substring(1);
                        } else {
                            TG频道链接 = "https://t.me/" + TG频道链接;
                        }
                    }
                }

                Pattern qqPattern = Pattern.compile("【QQ群】(.*?)【/QQ群】", Pattern.DOTALL);
                Matcher qqMatcher = qqPattern.matcher(config);
                if (qqMatcher.find()) {
                    QQ群号 = qqMatcher.group(1).trim();
                    Log.d(TAG, "Matched 【QQ群】: " + QQ群号);
                }

                Pattern configPattern = Pattern.compile("【包名版本】(.*?)【/包名版本】", Pattern.DOTALL);
                Matcher configMatcher = configPattern.matcher(config);
                if (configMatcher.find()) {
                    String configStr = configMatcher.group(1).trim();
                    Log.d(TAG, "Matched 【包名版本】 raw: " + configStr);
                    包名版本配置.clear();
                    String[] pairs = configStr.split(",");
                    for (String pair : pairs) {
                        String[] kv = pair.split("=");
                        if (kv.length == 2) {
                            try {
                                包名版本配置.put(kv[0].trim(), Integer.parseInt(kv[1].trim()));
                                Log.d(TAG, "Parsed 包名版本: " + kv[0].trim() + "=" + kv[1].trim());
                            } catch (NumberFormatException e) {
                                Log.e(TAG, "无效的版本号格式: " + pair, e);
                            }
                        }
                    }
                }

                Pattern titlePattern = Pattern.compile("【弹窗标题】(.*?)【/弹窗标题】", Pattern.DOTALL);
                Matcher titleMatcher = titlePattern.matcher(config);
                if (titleMatcher.find()) {
                    弹窗标题 = titleMatcher.group(1).trim();
                    Log.d(TAG, "Matched 【弹窗标题】: " + 弹窗标题);
                }

                Pattern forceUpdateContentPattern = Pattern.compile("【强制更新内容】(.*?)【/强制更新内容】", Pattern.DOTALL);
                Matcher forceUpdateContentMatcher = forceUpdateContentPattern.matcher(config);
                if (forceUpdateContentMatcher.find()) {
                    强制更新内容 = forceUpdateContentMatcher.group(1).trim();
                    Log.d(TAG, "Matched 【强制更新内容】: " + 强制更新内容);
                }

                Pattern updateLogPattern = Pattern.compile("【更新日志】(.*?)【/更新日志】", Pattern.DOTALL);
                Matcher updateLogMatcher = updateLogPattern.matcher(config);
                if (updateLogMatcher.find()) {
                    更新日志 = updateLogMatcher.group(1).trim();
                    Log.d(TAG, "Matched 【更新日志】: " + 更新日志);
                }

                Pattern configVersionPattern = Pattern.compile("【配置版本】(.*?)【/配置版本】", Pattern.DOTALL);
                Matcher configVersionMatcher = configVersionPattern.matcher(config);
                if (configVersionMatcher.find()) {
                    配置版本 = configVersionMatcher.group(1).trim();
                    Log.d(TAG, "Matched 【配置版本】: " + 配置版本);
                }

                Pattern networkSwitchPattern = Pattern.compile("【网络配置总开关】(.*?)【/网络配置总开关】", Pattern.DOTALL);
                Matcher networkSwitchMatcher = networkSwitchPattern.matcher(config);
                if (networkSwitchMatcher.find()) {
                    网络配置总开关 = "开".equals(networkSwitchMatcher.group(1).trim());
                    Log.d(TAG, "Matched 【网络配置总开关】: " + (网络配置总开关 ? "开" : "关"));
                }

                Pattern contentDisplaySwitchPattern = Pattern.compile("【显示动态内容开关】(.*?)【/显示动态内容开关】", Pattern.DOTALL);
                Matcher contentDisplaySwitchMatcher = contentDisplaySwitchPattern.matcher(config);
                if (contentDisplaySwitchMatcher.find()) {
                    显示动态内容开关 = "开".equals(contentDisplaySwitchMatcher.group(1).trim());
                    Log.d(TAG, "Matched 【显示动态内容开关】: " + (显示动态内容开关 ? "开" : "关"));
                }

                Pattern updateLogDisplaySwitchPattern = Pattern.compile("【显示更新日志开关】(.*?)【/显示更新日志开关】", Pattern.DOTALL);
                Matcher updateLogDisplaySwitchMatcher = updateLogDisplaySwitchPattern.matcher(config);
                if (updateLogDisplaySwitchMatcher.find()) {
                    显示更新日志开关 = "开".equals(updateLogDisplaySwitchMatcher.group(1).trim());
                    Log.d(TAG, "Matched 【显示更新日志开关】: " + (显示更新日志开关 ? "开" : "关"));
                }

                Pattern resetDontShowPattern = Pattern.compile("【重置不再提示】(.*?)【/重置不再提示】", Pattern.DOTALL);
                Matcher resetDontShowMatcher = resetDontShowPattern.matcher(config);
                if (resetDontShowMatcher.find()) {
                    重置不再提示 = "开".equals(resetDontShowMatcher.group(1).trim());
                    Log.d(TAG, "Matched 【重置不再提示】: " + (重置不再提示 ? "开" : "关"));
                }

                Pattern rotateSwitchPattern = Pattern.compile("【启用图片旋转】(.*?)【/启用图片旋转】", Pattern.DOTALL);
                Matcher rotateSwitchMatcher = rotateSwitchPattern.matcher(config);
                if (rotateSwitchMatcher.find()) {
                    启用Moonlight图旋转 = "开".equals(rotateSwitchMatcher.group(1).trim());
                    Log.d(TAG, "Matched 【启用图片旋转】: " + (启用Moonlight图旋转 ? "开" : "关"));
                }

                Pattern enableRegularDialogPattern = Pattern.compile("【启用普通弹窗】(.*?)【/启用普通弹窗】", Pattern.DOTALL);
                Matcher enableRegularDialogMatcher = enableRegularDialogPattern.matcher(config);
                if (enableRegularDialogMatcher.find()) {
                    启用普通弹窗 = "开".equals(enableRegularDialogMatcher.group(1).trim());
                    Log.d(TAG, "Matched 【启用普通弹窗】: " + (启用普通弹窗 ? "开" : "关"));
                }

                Pattern showCloseButtonPattern = Pattern.compile("【显示关闭按钮】(.*?)【/显示关闭按钮】", Pattern.DOTALL);
                Matcher showCloseButtonMatcher = showCloseButtonPattern.matcher(config);
                if (showCloseButtonMatcher.find()) {
                    显示关闭弹窗按钮 = "开".equals(showCloseButtonMatcher.group(1).trim());
                    Log.d(TAG, "Matched 【显示关闭按钮】: " + (显示关闭弹窗按钮 ? "开" : "关"));
                }

                Pattern showDontShowAgainButtonPattern = Pattern.compile("【显示不再提示按钮】(.*?)【/显示不再提示按钮】", Pattern.DOTALL);
                Matcher showDontShowAgainButtonMatcher = showDontShowAgainButtonPattern.matcher(config);
                if (showDontShowAgainButtonMatcher.find()) {
                    显示不再提示按钮 = "开".equals(showDontShowAgainButtonMatcher.group(1).trim());
                    Log.d(TAG, "Matched 【显示不再提示按钮】: " + (显示不再提示按钮 ? "开" : "关"));
                }

                Pattern showQQButtonPattern = Pattern.compile("【显示QQ按钮】(.*?)【/显示QQ按钮】", Pattern.DOTALL);
                Matcher showQQButtonMatcher = showQQButtonPattern.matcher(config);
                if (showQQButtonMatcher.find()) {
                    显示QQ群按钮 = "开".equals(showQQButtonMatcher.group(1).trim());
                    Log.d(TAG, "Matched 【显示QQ按钮】: " + (显示QQ群按钮 ? "开" : "关"));
                }

                Pattern showTGButtonPattern = Pattern.compile("【显示TG按钮】(.*?)【/显示TG按钮】", Pattern.DOTALL);
                Matcher showTGButtonMatcher = showTGButtonPattern.matcher(config);
                if (showTGButtonMatcher.find()) {
                    显示TG频道按钮 = "开".equals(showTGButtonMatcher.group(1).trim());
                    Log.d(TAG, "Matched 【显示TG按钮】: " + (显示TG频道按钮 ? "开" : "关"));
                }

                Pattern enableDismissOutsidePattern = Pattern.compile("【启用外部点击消失】(.*?)【/启用外部点击消失】", Pattern.DOTALL);
                Matcher enableDismissOutsideMatcher = enableDismissOutsidePattern.matcher(config);
                if (enableDismissOutsideMatcher.find()) {
                    启用外部点击消失 = "开".equals(enableDismissOutsideMatcher.group(1).trim());
                    Log.d(TAG, "Matched 【启用外部点击消失】: " + (启用外部点击消失 ? "开" : "关"));
                }

                Pattern mainColorPattern = Pattern.compile("【主色调颜色】(.*?)【/主色调颜色】", Pattern.DOTALL);
                Matcher mainColorMatcher = mainColorPattern.matcher(config);
                if (mainColorMatcher.find()) {
                    String colorStr = mainColorMatcher.group(1).trim();
                    Log.d(TAG, "Matched 【主色调颜色】 raw: " + colorStr);
                    网络主色调 = parseColor(colorStr);
                    Log.d(TAG, "Parsed 主色调颜色: " + String.format("#%06X", (0xFFFFFF & 网络主色调)));
                }

                Pattern textColorPattern = Pattern.compile("【文字颜色】(.*?)【/文字颜色】", Pattern.DOTALL);
                Matcher textColorMatcher = textColorPattern.matcher(config);
                if (textColorMatcher.find()) {
                    String colorStr = textColorMatcher.group(1).trim();
                    Log.d(TAG, "Matched 【文字颜色】 raw: " + colorStr);
                    网络文字颜色 = parseColor(colorStr);
                    Log.d(TAG, "Parsed 文字颜色: " + String.format("#%06X", (0xFFFFFF & 网络文字颜色)));
                }

                Pattern buttonColorPattern = Pattern.compile("【按钮颜色】(.*?)【/按钮颜色】", Pattern.DOTALL);
                Matcher buttonColorMatcher = buttonColorPattern.matcher(config);
                if (buttonColorMatcher.find()) {
                    String colorStr = buttonColorMatcher.group(1).trim();
                    Log.d(TAG, "Matched 【按钮颜色】 raw: " + colorStr);
                    网络按钮颜色 = parseColor(colorStr);
                    Log.d(TAG, "Parsed 按钮颜色: " + String.format("#%06X", (0xFFFFFF & 网络按钮颜色)));
                } else {
                    网络按钮颜色 = 网络主色调; // 默认使用主色调
                    Log.d(TAG, "未找到【按钮颜色】，使用主色调: " + String.format("#%06X", (0xFFFFFF & 网络按钮颜色)));
                }

                return true;
            } catch (Exception e) {
                Log.e(TAG, "加载配置失败", e);
                e.printStackTrace();
                return false;
            }
        }

        @Override
        protected void onPostExecute(Boolean success) {
            Activity activity = activityWeakReference.get();
            if (activity == null || activity.isFinishing()) {
                return;
            }
            if (callback != null) {
                if (success) {
                    Log.d(TAG, "配置加载成功，执行回调");
                    callback.onConfigLoaded();
                } else {
                    Log.w(TAG, "配置加载失败，执行回调");
                    callback.onConfigFailed();
                }
            }
        }
    }

    /**
     * 异步任务：检查当前包的版本是否满足最低要求
     */
    private static class CheckPackageAndVersionTask extends AsyncTask<Void, Void, Boolean> {
        private WeakReference<Activity> activityWeakReference;
        private VersionCheckCallback callback;

        CheckPackageAndVersionTask(Activity activity, VersionCheckCallback callback) {
            activityWeakReference = new WeakReference<>(activity);
            this.callback = callback;
        }

        @Override
        protected Boolean doInBackground(Void... voids) {
            Activity activity = activityWeakReference.get();
            if (activity == null || activity.isFinishing()) {
                Log.d(TAG, "CheckPackageAndVersionTask doInBackground: Activity is null or finishing.");
                return false;
            }

            try {
                String packageName = activity.getPackageName();
                if (packageName == null || packageName.isEmpty()) {
                    Log.e(TAG, "包名为空或无效");
                    return false;
                }
                Log.d(TAG, "检查包名: " + packageName);
                if (包名版本配置.containsKey(packageName)) {
                    int minVersion = 包名版本配置.get(packageName);
                    PackageInfo pInfo = activity.getPackageManager().getPackageInfo(packageName, 0);
                    int currentVersion = pInfo.versionCode;
                    Log.d(TAG, "当前版本 Code: " + currentVersion + ", 最低要求版本 Code: " + minVersion);
                    return currentVersion >= minVersion;
                }
                Log.d(TAG, "包名不在配置中，视为版本有效");
                return true;
            } catch (PackageManager.NameNotFoundException e) {
                Log.e(TAG, "无法找到包信息", e);
                return false;
            } catch (Exception e) {
                Log.e(TAG, "检查包版本时发生未知错误", e);
                e.printStackTrace();
                return false;
            }
        }

        @Override
        protected void onPostExecute(Boolean isVersionValid) {
            Activity activity = activityWeakReference.get();
            if (activity == null || activity.isFinishing()) {
                return;
            }
            if (callback != null) {
                if (isVersionValid) {
                    需要强制更新 = false;
                    Log.d(TAG, "版本有效，设置需要强制更新为 false，执行回调 onVersionValid");
                    callback.onVersionValid();
                } else {
                    需要强制更新 = true;
                    Log.w(TAG, "版本过低，设置需要强制更新为 true，触发强制更新，执行回调 onVersionOutdated");
                    callback.onVersionOutdated();
                }
            }
        }
    }

    /**
     * 异步任务：检查网络连接是否可用
     */
    private static class CheckInternetTask extends AsyncTask<Void, Void, Boolean> {
        private WeakReference<Activity> activityWeakReference;
        private InternetCheckCallback callback;

        CheckInternetTask(Activity activity, InternetCheckCallback callback) {
            activityWeakReference = new WeakReference<>(activity);
            this.callback = callback;
        }

        @Override
        protected Boolean doInBackground(Void... voids) {
            Activity activity = activityWeakReference.get();
            if (activity == null || activity.isFinishing()) {
                Log.d(TAG, "CheckInternetTask doInBackground: Activity is null or finishing.");
                return false;
            }

            try {
                URL url = new URL("https://www.baidu.com");
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("HEAD");
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(5000);
                int responseCode = connection.getResponseCode();
                Log.d(TAG, "网络检查响应码: " + responseCode);
                connection.disconnect();
                return responseCode == 200;
            } catch (IOException e) {
                Log.e(TAG, "网络检查失败", e);
                e.printStackTrace();
                return false;
            }
        }

        @Override
        protected void onPostExecute(Boolean isConnected) {
            Activity activity = activityWeakReference.get();
            if (activity == null || activity.isFinishing()) {
                return;
            }
            if (callback != null) {
                if (isConnected) {
                    Log.d(TAG, "网络连接正常，执行回调 onInternetAvailable");
                    callback.onInternetAvailable();
                } else {
                    Log.w(TAG, "无网络连接，执行回调 onInternetUnavailable");
                    callback.onInternetUnavailable();
                }
            }
        }
    }

    /**
     * 显示强制更新弹窗
     */
    private static void showForceUpdateDialog(final Activity activity) {
        if (activity == null || activity.isFinishing()) {
            Log.e(TAG, "Activity为空或正在结束，无法显示强制更新弹窗");
            sShowingActivityRef = null;
            return;
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(activity, android.R.style.Theme_DeviceDefault_Dialog);
        Typeface defaultFromStyle = Typeface.defaultFromStyle(Typeface.BOLD);

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        layoutParams.gravity = Gravity.CENTER;
        layoutParams.setMargins(90, 0, 90, 10);

        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        layoutParams2.height = 80;
        layoutParams2.gravity = Gravity.CENTER;

        ScrollView scrollView = new ScrollView(activity);
        LinearLayout linearLayout = new LinearLayout(activity);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        scrollView.addView(linearLayout);

        final AlertDialog dialog = builder.create();
        dialog.setCancelable(false);
        dialog.setView(scrollView);
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                Log.d(TAG, "强制更新弹窗关闭");
                sShowingActivityRef = null;
            }
        });

        View viewTopSpacer = new View(activity);
        linearLayout.addView(viewTopSpacer);
        viewTopSpacer.setLayoutParams(layoutParams2);

        ImageView imageView = new ImageView(activity);
        linearLayout.addView(imageView);
        LinearLayout.LayoutParams imageParams = new LinearLayout.LayoutParams(250, 250);
        imageParams.gravity = Gravity.CENTER_HORIZONTAL;
        imageView.setLayoutParams(imageParams);
        try {
            InputStream is = activity.getAssets().open("Moonlight");
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;
            Bitmap decodeStream = BitmapFactory.decodeStream(is, null, options);
            is.close();

            if (decodeStream != null) {
                Bitmap createBitmap = Bitmap.createBitmap(decodeStream.getWidth(), decodeStream.getHeight(), Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(createBitmap);
                Paint paint = new Paint();
                paint.setAntiAlias(true);
                canvas.drawCircle(decodeStream.getWidth() / 2.0f, decodeStream.getHeight() / 2.0f,
                        Math.min(decodeStream.getWidth(), decodeStream.getHeight()) / 2.0f, paint);
                paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
                float f = 0;
                canvas.drawBitmap(decodeStream, f, f, paint);
                imageView.setImageBitmap(createBitmap);
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);

                if (启用Moonlight图旋转) {
                    ObjectAnimator ofFloat = ObjectAnimator.ofFloat(imageView, "rotation", 0.0f, 360.0f);
                    ofFloat.setDuration(5000);
                    ofFloat.setRepeatCount(-1);
                    ofFloat.setInterpolator(new LinearInterpolator());
                    ofFloat.start();
                    Log.d(TAG, "Moonlight图旋转已启用");
                } else {
                    imageView.setRotation(0);
                    Log.d(TAG, "Moonlight图旋转已禁用");
                }

                if (!decodeStream.isRecycled()) {
                    decodeStream.recycle();
                }
            }
        } catch (IOException e) {
            Log.e(TAG, "加载Moonlight图片失败", e);
        }

        TextView textViewTitle = new TextView(activity);
        linearLayout.addView(textViewTitle);
        textViewTitle.setGravity(Gravity.CENTER);
        textViewTitle.setText("版本更新");
        textViewTitle.setTypeface(defaultFromStyle);
        textViewTitle.setTextColor(网络文字颜色);
        textViewTitle.setTextSize(25);

        View viewSpacer1 = new View(activity);
        linearLayout.addView(viewSpacer1);
        viewSpacer1.setLayoutParams(layoutParams2);

        TextView textViewContent = new TextView(activity);
        linearLayout.addView(textViewContent);
        textViewContent.setTextSize(18);
        textViewContent.setText(强制更新内容);
        textViewContent.setTextColor(网络文字颜色);
        textViewContent.setPadding(100, 50, 100, 50);

        if (显示更新日志开关) {
            TextView updateLogView = new TextView(activity);
            linearLayout.addView(updateLogView);
            updateLogView.setTextSize(16);
            updateLogView.setText("更新日志：\n" + 更新日志);
            updateLogView.setTextColor(网络文字颜色);
            updateLogView.setPadding(100, 20, 100, 50);
        }

        // Add buttons vertically
        Button updateButton = new Button(activity);
        updateButton.setLayoutParams(layoutParams);
        linearLayout.addView(updateButton);
        updateButton.setText("立即更新");
        updateButton.setTextColor(网络文字颜色);
        updateButton.setTextSize(16);
        updateButton.setPadding(20, 10, 20, 10);
        updateButton.setBackground(buttonback1());
        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (强制更新链接 != null && !强制更新链接.isEmpty()) {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(强制更新链接));
                        activity.startActivity(intent);
                        Log.d(TAG, "Opening browser for update: " + 强制更新链接);
                    } else {
                        Toast.makeText(activity, "更新链接未配置", Toast.LENGTH_SHORT).show();
                        Log.w(TAG, "强制更新链接为空");
                    }
                } catch (Exception e) {
                    Toast.makeText(activity, "打开链接失败", Toast.LENGTH_SHORT).show();
                    Log.e(TAG, "Failed to open update link", e);
                }
            }
        });

        Button exitButton = new Button(activity);
        exitButton.setLayoutParams(layoutParams);
        linearLayout.addView(exitButton);
        exitButton.setText("退出应用");
        exitButton.setTextColor(网络文字颜色);
        exitButton.setTextSize(16);
        exitButton.setPadding(20, 10, 20, 10);
        exitButton.setBackground(buttonback4());
        exitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.finish();
                Log.d(TAG, "用户选择退出应用");
            }
        });

        View viewBottomSpacer = new View(activity);
        linearLayout.addView(viewBottomSpacer);
        viewBottomSpacer.setLayoutParams(layoutParams2);

        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(100.0f);
        gradientDrawable.setColor(网络主色调);
        dialog.getWindow().setBackgroundDrawable(gradientDrawable);

        DisplayMetrics displayMetrics = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int screenWidth = displayMetrics.widthPixels;

        WindowManager.LayoutParams windowAttributes = new WindowManager.LayoutParams();
        windowAttributes.copyFrom(dialog.getWindow().getAttributes());
        if (activity.getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            windowAttributes.width = (int) (screenWidth * 0.7);
        } else {
            windowAttributes.width = (int) (screenWidth * 0.9);
        }
        windowAttributes.height = WindowManager.LayoutParams.WRAP_CONTENT;
        windowAttributes.gravity = Gravity.CENTER;
        dialog.getWindow().setAttributes(windowAttributes);

        dialog.show();
    }

    /**
     * 执行非强制更新情况下的弹窗逻辑
     */
    private static void originalPopupLogic(final Activity activity) {
        if (activity == null || activity.isFinishing()) {
            Log.e(TAG, "Activity为空或正在结束，无法执行普通弹窗逻辑");
            sShowingActivityRef = null;
            return;
        }

        final SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(activity);
        try {
            PackageInfo pInfo = activity.getPackageManager().getPackageInfo(activity.getPackageName(), 0);
            String currentVersion = pInfo.versionName != null ? pInfo.versionName : "1.0";
            Log.d(TAG, "当前应用版本: " + currentVersion);

            String storedVersion = defaultSharedPreferences.getString("dialogVer", "default");

            if (defaultSharedPreferences.getBoolean("0", false) && !重置不再提示 && storedVersion.equals(配置版本)) {
                Log.d(TAG, "不再提示已启用且配置版本未变，跳过弹窗");
                sShowingActivityRef = null;
                return;
            }

            if (defaultSharedPreferences.getBoolean("0", false) && !storedVersion.equals(配置版本)) {
                Log.d(TAG, "不再提示已启用，但配置版本已更新，重新显示弹窗");
                defaultSharedPreferences.edit().remove("0").apply();
            }
        } catch (PackageManager.NameNotFoundException e) {
            Log.e(TAG, "无法获取应用版本信息", e);
        } catch (Exception e) {
            Log.e(TAG, "检查弹窗逻辑时发生未知错误", e);
        }

        createDialog(activity, defaultSharedPreferences);
    }

    /**
     * 创建并显示普通弹窗
     */
    private static void createDialog(final Activity activity, final SharedPreferences defaultSharedPreferences) {
        if (activity == null || activity.isFinishing()) {
            Log.e(TAG, "Activity为空或正在结束，无法创建弹窗");
            sShowingActivityRef = null;
            return;
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(activity, android.R.style.Theme_DeviceDefault_Dialog);
        Typeface defaultFromStyle = Typeface.defaultFromStyle(Typeface.BOLD);

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        layoutParams.gravity = Gravity.CENTER;
        layoutParams.setMargins(90, 0, 90, 10);

        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        layoutParams2.height = 80;
        layoutParams2.gravity = Gravity.CENTER;

        ScrollView scrollView = new ScrollView(activity);
        LinearLayout linearLayout = new LinearLayout(activity);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        scrollView.addView(linearLayout);

        final AlertDialog dialog = builder.create();
        dialog.setCancelable(启用外部点击消失);
        Log.d(TAG, "普通弹窗 setCancelable: " + 启用外部点击消失);

        dialog.setView(scrollView);
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                Log.d(TAG, "主弹窗关闭");
                sShowingActivityRef = null;
            }
        });

        View viewTopSpacer = new View(activity);
        linearLayout.addView(viewTopSpacer);
        viewTopSpacer.setLayoutParams(layoutParams2);

        ImageView imageView = new ImageView(activity);
        linearLayout.addView(imageView);
        LinearLayout.LayoutParams imageParams = new LinearLayout.LayoutParams(250, 250);
        imageParams.gravity = Gravity.CENTER_HORIZONTAL;
        imageView.setLayoutParams(imageParams);
        try {
            InputStream is = activity.getAssets().open("Moonlight");
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;
            Bitmap decodeStream = BitmapFactory.decodeStream(is, null, options);
            is.close();

            if (decodeStream != null) {
                Bitmap createBitmap = Bitmap.createBitmap(decodeStream.getWidth(), decodeStream.getHeight(), Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(createBitmap);
                Paint paint = new Paint();
                paint.setAntiAlias(true);
                canvas.drawCircle(decodeStream.getWidth() / 2.0f, decodeStream.getHeight() / 2.0f,
                        Math.min(decodeStream.getWidth(), decodeStream.getHeight()) / 2.0f, paint);
                paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
                float f = 0;
                canvas.drawBitmap(decodeStream, f, f, paint);
                imageView.setImageBitmap(createBitmap);
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);

                if (启用Moonlight图旋转) {
                    ObjectAnimator ofFloat = ObjectAnimator.ofFloat(imageView, "rotation", 0.0f, 360.0f);
                    ofFloat.setDuration(5000);
                    ofFloat.setRepeatCount(-1);
                    ofFloat.setInterpolator(new LinearInterpolator());
                    ofFloat.start();
                    Log.d(TAG, "Moonlight图旋转已启用");
                } else {
                    imageView.setRotation(0);
                    Log.d(TAG, "Moonlight图旋转已禁用");
                }

                if (!decodeStream.isRecycled()) {
                    decodeStream.recycle();
                }
            }
        } catch (IOException e) {
            Log.e(TAG, "加载Moonlight图片失败", e);
        }

        TextView textViewTitle = new TextView(activity);
        linearLayout.addView(textViewTitle);
        textViewTitle.setGravity(Gravity.CENTER);
        textViewTitle.setText(弹窗标题);
        textViewTitle.setTypeface(defaultFromStyle);
        textViewTitle.setTextColor(网络文字颜色);
        textViewTitle.setTextSize(25);

        View viewSpacer1 = new View(activity);
        linearLayout.addView(viewSpacer1);
        viewSpacer1.setLayoutParams(layoutParams2);

        TextView textViewContent = new TextView(activity);
        linearLayout.addView(textViewContent);
        textViewContent.setTextSize(18);
        textViewContent.setText(显示动态内容开关 ? 动态内容 : "欢迎使用本应用");
        textViewContent.setTextColor(网络文字颜色);
        textViewContent.setPadding(100, 50, 100, 50);

        // Add buttons vertically
        if (显示关闭弹窗按钮) {
            Button closeButton = new Button(activity);
            closeButton.setLayoutParams(layoutParams);
            linearLayout.addView(closeButton);
            closeButton.setText("关闭弹窗");
            closeButton.setTextColor(网络文字颜色);
            closeButton.setTextSize(16);
            closeButton.setPadding(20, 10, 20, 10);
            closeButton.setBackground(buttonback1());
            closeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });
        }

        if (显示TG频道按钮) {
            Button tgButton = new Button(activity);
            tgButton.setLayoutParams(layoutParams);
            linearLayout.addView(tgButton);
            tgButton.setText("加入TG频道");
            tgButton.setTextColor(网络文字颜色);
            tgButton.setTextSize(16);
            tgButton.setPadding(20, 10, 20, 10);
            tgButton.setBackground(buttonback2());
            tgButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        if (TG频道链接 != null && !TG频道链接.isEmpty()) {
                            if (TG频道链接.startsWith("https://t.me/")) {
                                String tgAppLink = TG频道链接.replace("https://t.me/", "tg://resolve?domain=");
                                Intent tgIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(tgAppLink));
                                try {
                                    activity.startActivity(tgIntent);
                                    return;
                                } catch (ActivityNotFoundException e) {
                                    Log.w(TAG, "Telegram应用未安装，尝试用浏览器打开", e);
                                }
                            }

                            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(TG频道链接));
                            activity.startActivity(browserIntent);
                        } else {
                            Toast.makeText(activity, "TG频道链接未配置", Toast.LENGTH_SHORT).show();
                            Log.w(TAG, "TG频道链接为空");
                        }
                    } catch (Exception e) {
                        Toast.makeText(activity, "打开TG失败，请手动安装Telegram", Toast.LENGTH_LONG).show();
                        Log.e(TAG, "打开TG链接失败", e);

                        if (TG频道链接 != null && !TG频道链接.isEmpty()) {
                            android.content.ClipboardManager clipboard =
                                    (android.content.ClipboardManager) activity.getSystemService(android.content.Context.CLIPBOARD_SERVICE);
                            android.content.ClipData clip = android.content.ClipData.newPlainText("TG链接", TG频道链接);
                            clipboard.setPrimaryClip(clip);
                            Toast.makeText(activity, "已复制TG链接到剪贴板", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            });
        }

        if (显示QQ群按钮) {
            Button qqButton = new Button(activity);
            qqButton.setLayoutParams(layoutParams);
            linearLayout.addView(qqButton);
            qqButton.setText("加入QQ群");
            qqButton.setTextColor(网络文字颜色);
            qqButton.setTextSize(16);
            qqButton.setPadding(20, 10, 20, 10);
            qqButton.setBackground(buttonback2());
            qqButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        if (QQ群号 != null && !QQ群号.isEmpty()) {
                            try {
                                Intent intent = new Intent(Intent.ACTION_VIEW,
                                        Uri.parse("mqqapi://card/show_pslcard?src_type=internal&version=1&uin=" + QQ群号 + "&card_type=group&source=qrcode"));
                                activity.startActivity(intent);
                                return;
                            } catch (ActivityNotFoundException e) {
                                Intent intent2 = new Intent(Intent.ACTION_VIEW,
                                        Uri.parse("https://jq.qq.com/?_wv=1027&k=" + QQ群号));
                                activity.startActivity(intent2);
                                return;
                            }
                        } else {
                            Toast.makeText(activity, "QQ群号未配置", Toast.LENGTH_SHORT).show();
                            Log.w(TAG, "QQ群号为空");
                        }
                    } catch (Exception e) {
                        Toast.makeText(activity, "打开QQ失败，请确保已安装QQ", Toast.LENGTH_SHORT).show();
                        Log.e(TAG, "打开QQ群失败", e);

                        if (QQ群号 != null && !QQ群号.isEmpty()) {
                            android.content.ClipboardManager clipboard =
                                    (android.content.ClipboardManager) activity.getSystemService(android.content.Context.CLIPBOARD_SERVICE);
                            android.content.ClipData clip = android.content.ClipData.newPlainText("QQ群号", QQ群号);
                            clipboard.setPrimaryClip(clip);
                            Toast.makeText(activity, "已复制QQ群号到剪贴板", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            });
        }

        if (显示不再提示按钮) {
            Button dontShowButton = new Button(activity);
            dontShowButton.setLayoutParams(layoutParams);
            linearLayout.addView(dontShowButton);
            dontShowButton.setText("不再提示");
            dontShowButton.setTextColor(网络文字颜色);
            dontShowButton.setTextSize(16);
            dontShowButton.setPadding(20, 10, 20, 10);
            dontShowButton.setBackground(buttonback4());
            dontShowButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                    AlertDialog.Builder dontShowBuilder = new AlertDialog.Builder(activity, android.R.style.Theme_DeviceDefault_Dialog);
                    dontShowBuilder.setMessage("是否不再提示此弹窗？")
                            .setPositiveButton("是", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    try {
                                        defaultSharedPreferences.edit()
                                                .putString("dialogVer", 配置版本)
                                                .putBoolean("0", true)
                                                .apply();
                                        Log.d(TAG, "不再提示设置成功，配置版本: " + 配置版本);
                                    } catch (Exception e) {
                                        Log.e(TAG, "设置不再提示失败", e);
                                        Toast.makeText(activity, "设置失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
                                    }
                                }
                            })
                            .setNegativeButton("否", null);
                    AlertDialog dontShowDialog = dontShowBuilder.create();
                    dontShowDialog.show();
                }
            });
        }

        View viewBottomSpacer = new View(activity);
        linearLayout.addView(viewBottomSpacer);
        viewBottomSpacer.setLayoutParams(layoutParams2);

        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(100.0f);
        gradientDrawable.setColor(网络主色调);
        dialog.getWindow().setBackgroundDrawable(gradientDrawable);

        DisplayMetrics displayMetrics = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int screenWidth = displayMetrics.widthPixels;
        int screenHeight = displayMetrics.heightPixels;

        scrollView.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                screenHeight > screenWidth ? (int) (screenHeight * 0.8f) : LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        WindowManager.LayoutParams windowAttributes = new WindowManager.LayoutParams();
        windowAttributes.copyFrom(dialog.getWindow().getAttributes());
        if (activity.getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            windowAttributes.width = (int) (screenWidth * 0.7);
        } else {
            windowAttributes.width = (int) (screenWidth * 0.9);
        }
        windowAttributes.height = WindowManager.LayoutParams.WRAP_CONTENT;
        windowAttributes.gravity = Gravity.CENTER;
        dialog.getWindow().setAttributes(windowAttributes);

        dialog.show();
    }

    // 配置加载回调接口
    private interface ConfigLoadCallback {
        void onConfigLoaded();
        void onConfigFailed();
    }

    // 版本检查回调接口
    private interface VersionCheckCallback {
        void onVersionValid();
        void onVersionOutdated();
    }

    // 网络检查回调接口
    private interface InternetCheckCallback {
        void onInternetAvailable();
        void onInternetUnavailable();
    }
}