package bbs.yuchen.icu;

import android.app.Activity;

public class DialogLauncher {
    public static void Thrym(Activity activity) {
        // 先设置配置 URL
        Moonlight.setConfigUrl("https://sharechain.qq.com/73966a9210eed1a494bad966f4c390ab");
        // 再显示弹窗
        Moonlight.弹窗(activity);
    }
}